import { User, InsertUser } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Pencil, Trash2, Plus, Search, Filter, Shield, AlertTriangle } from "lucide-react";
import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { insertUserSchema } from "@shared/schema";
import { roles, roleHierarchy, canManage } from "@shared/roles";
import { employeeTypes, employeeTypeLabels, EmployeeType } from "@shared/schema";

export default function UserManagement() {
  const { toast } = useToast();
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Search and filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [managerFilter, setManagerFilter] = useState<string>("all");

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Filter and search users
  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      // Search by name, email, or phone
      const searchMatch = searchQuery === "" || 
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.mobileNumber.includes(searchQuery);

      // Filter by role
      const roleMatch = roleFilter === "all" || user.role === roleFilter;

      // Filter by reporting manager
      const managerMatch = managerFilter === "all" || 
        user.reportingManagerId?.toString() === managerFilter;

      return searchMatch && roleMatch && managerMatch;
    });
  }, [users, searchQuery, roleFilter, managerFilter]);

  // Get unique roles for filter dropdown
  const availableRoles = useMemo(() => {
    const roleSet = new Set(users.map(user => user.role));
    return Array.from(roleSet).sort();
  }, [users]);

  // Get unique managers for filter dropdown
  const availableManagers = useMemo(() => {
    const managerMap = new Map();
    users.forEach(user => {
      if (user.reportingManagerId && user.reportingManagerId !== user.id) {
        const manager = users.find(u => u.id === user.reportingManagerId);
        if (manager) {
          managerMap.set(user.reportingManagerId.toString(), manager.username);
        }
      }
    });
    return Array.from(managerMap.entries()).sort((a, b) => a[1].localeCompare(b[1]));
  }, [users]);

  const addUserMutation = useMutation({
    mutationFn: async (data: InsertUser) => {
      // apiRequest already parses the JSON response
      return await apiRequest("POST", "/api/register", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: "Success",
        description: "User added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      return await apiRequest("DELETE", `/api/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertUser> }) => {
      // Remove empty password if not being updated
      if (data.password === "") {
        delete data.password;
      }

      console.log('Updating user with ID:', id);

      try {
        // The apiRequest function handles all the request logic including JSON parsing
        const result = await apiRequest("PATCH", `/api/users/${id}`, data);
        return result;
      } catch (error) {
        console.error('Error caught in updateUserMutation:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsEditDialogOpen(false);
      editForm.reset();
      toast({
        title: "Success",
        description: "User updated successfully",
      });
    },
    onError: (error: Error) => {
      console.error('Update user error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update user",
        variant: "destructive",
      });
    },
  });

  const editForm = useForm<Partial<InsertUser>>({
    resolver: zodResolver(insertUserSchema.partial()),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      role: undefined,
      employeeType: "PERMANENT" as const,
      mobileNumber: "",
      countryCode: "",
      reportingManagerId: undefined,
    },
  });

  const addForm = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      role: "Employee" as const,
      employeeType: "PERMANENT" as const,
      mobileNumber: "",
      countryCode: "+1",
      reportingManagerId: undefined,
    },
  });

  // Watch selected roles for both forms
  const editSelectedRole = editForm.watch("role");
  const addSelectedRole = addForm.watch("role");

  // Get potential managers for the selected role
  const getEligibleManagers = (selectedRole: string | undefined) => {
    if (!selectedRole) return [];

    // Group managers by their roles
    const managersByRole = users.reduce((acc, manager) => {
      if (manager.id !== editingUser?.id && canManage(manager.role, selectedRole)) {
        if (!acc[manager.role]) {
          acc[manager.role] = [];
        }
        acc[manager.role].push(manager);
      }
      return acc;
    }, {} as Record<string, User[]>);

    // Sort roles by hierarchy with error handling
    return Object.entries(managersByRole).sort(
      ([roleA], [roleB]) => {
        // Default hierarchy values if roles aren't found
        const hierarchyA = roleHierarchy[roleA] !== undefined ? roleHierarchy[roleA] : 999;
        const hierarchyB = roleHierarchy[roleB] !== undefined ? roleHierarchy[roleB] : 999;
        return hierarchyA - hierarchyB;
      }
    );
  };

  const { data: statutoryData } = useQuery<any>({
    queryKey: ['/api/users', editingUser?.id, 'statutory-applicability'],
    enabled: !!editingUser?.id && isEditDialogOpen,
  });

  const editEligibleManagers = getEligibleManagers(editSelectedRole);
  const addEligibleManagers = getEligibleManagers(addSelectedRole);

  function handleEdit(user: User) {
    setEditingUser(user);
    // Convert null to undefined for the form
    editForm.reset({
      username: user.username,
      email: user.email,
      role: user.role,
      employeeType: (user as any).employeeType || 'PERMANENT',
      mobileNumber: user.mobileNumber,
      countryCode: user.countryCode,
      reportingManagerId: user.reportingManagerId === null ? undefined : user.reportingManagerId,
    });
    setIsEditDialogOpen(true);
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>User Management</CardTitle>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </CardHeader>
      <CardContent>
        {/* Search and Filter Section */}
        <div className="mb-6 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {availableRoles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={managerFilter} onValueChange={setManagerFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by manager" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Managers</SelectItem>
                  {availableManagers.map(([id, name]) => (
                    <SelectItem key={id} value={id}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Results Summary */}
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>
              Showing {filteredUsers.length} of {users.length} users
            </span>
            {(searchQuery || roleFilter !== "all" || managerFilter !== "all") && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSearchQuery("");
                  setRoleFilter("all");
                  setManagerFilter("all");
                }}
              >
                Clear filters
              </Button>
            )}
          </div>
        </div>
        
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Username</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Employee Type</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Reporting Manager</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.id}</TableCell>
                <TableCell>{user.username}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{user.role}</Badge>
                </TableCell>
                <TableCell>
                  {(user as any).employeeType ? employeeTypeLabels[(user as any).employeeType as EmployeeType] || (user as any).employeeType : 'Permanent (Full-Time)'}
                </TableCell>
                <TableCell>{user.countryCode} {user.mobileNumber}</TableCell>
                <TableCell>
                  {user.reportingManagerId === user.id ?
                    'Self' :
                    users.find(u => u.id === user.reportingManagerId)?.username || 'N/A'
                  }
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(user)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete User</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete {user.username}? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteUserMutation.mutate(user.id)}
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* Edit User Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit User</DialogTitle>
            </DialogHeader>
            <Form {...editForm}>
              <form
                onSubmit={editForm.handleSubmit((data) => {
                  if (editingUser) {
                    updateUserMutation.mutate({
                      id: editingUser.id,
                      data
                    });
                  }
                })}
                className="space-y-4"
              >
                <FormField
                  control={editForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="countryCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country Code</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="mobileNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mobile Number</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={editForm.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a role" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {roles.map((role) => (
                            <SelectItem key={role} value={role}>
                              {role}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="employeeType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employee Type <span className="text-red-500">*</span></FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || 'PERMANENT'}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select employee type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {employeeTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {employeeTypeLabels[type]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Add password field */}
                <FormField
                  control={editForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>New Password (leave blank to keep current)</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {editSelectedRole !== "Superuser" && (
                  <FormField
                    control={editForm.control}
                    name="reportingManagerId"
                    rules={{ required: "Reporting Manager is required" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reporting Manager <span className="text-red-500">*</span></FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(Number(value))}
                          defaultValue={field.value ? field.value.toString() : undefined}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select reporting manager" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {getEligibleManagers(editSelectedRole).map(([role, managers]) => (
                              <SelectGroup key={role}>
                                <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">
                                  {role}s
                                </SelectLabel>
                                {managers.map((manager) => (
                                  <SelectItem key={manager.id} value={manager.id.toString()}>
                                    {manager.username}
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {statutoryData && (
                  <div className="rounded-lg border p-3 bg-muted/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-semibold">Compliance Applicability</span>
                      {statutoryData.status === 'UNRESOLVED' && (
                        <Badge variant="destructive" className="text-xs">Unresolved</Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { label: 'PF', value: statutoryData.isPFApplicable },
                        { label: 'ESIC', value: statutoryData.isESICApplicable },
                        { label: 'PT', value: statutoryData.isPTApplicable },
                        { label: 'TDS', value: statutoryData.isTDSApplicable },
                      ].map((item) => (
                        <div key={item.label} className="text-center">
                          <div className="text-xs text-muted-foreground">{item.label}</div>
                          <Badge variant={item.value === true ? 'default' : item.value === false ? 'secondary' : 'destructive'} className="text-xs">
                            {item.value === true ? 'Yes' : item.value === false ? 'No' : 'Unresolved'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                    {statutoryData.warnings?.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {statutoryData.warnings.map((w: string, i: number) => (
                          <div key={i} className="flex items-start gap-1 text-xs text-amber-600">
                            <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
                            <span>{w}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full"
                  disabled={updateUserMutation.isPending}
                >
                  Save Changes
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Add User Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
            </DialogHeader>
            <Form {...addForm}>
              <form
                onSubmit={addForm.handleSubmit((data) => {
                  addUserMutation.mutate(data);
                })}
                className="space-y-4"
              >
                <FormField
                  control={addForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={addForm.control}
                    name="countryCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country Code</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={addForm.control}
                    name="mobileNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mobile Number</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={addForm.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a role" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {roles.map((role) => (
                            <SelectItem key={role} value={role}>
                              {role}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="employeeType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employee Type <span className="text-red-500">*</span></FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value || 'PERMANENT'}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select employee type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {employeeTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {employeeTypeLabels[type]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {addSelectedRole !== "Superuser" && (
                  <FormField
                    control={addForm.control}
                    name="reportingManagerId"
                    rules={{ required: "Reporting Manager is required" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reporting Manager <span className="text-red-500">*</span></FormLabel>
                        <Select 
                          onValueChange={(value) => field.onChange(Number(value))}
                          defaultValue={field.value ? field.value.toString() : undefined}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select reporting manager" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {getEligibleManagers(addSelectedRole).map(([role, managers]) => (
                              <SelectGroup key={role}>
                                <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">
                                  {role}s
                                </SelectLabel>
                                {managers.map((manager) => (
                                  <SelectItem key={manager.id} value={manager.id.toString()}>
                                    {manager.username}
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={addForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={addUserMutation.isPending}
                >
                  Add User
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}