import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { SelectGroup, SelectLabel } from '@/components/ui/select';
import { roles, roleHierarchy, canManage } from '../../../shared/roles';
import { employeeTypes, employeeTypeLabels, type EmployeeType } from '@shared/schema';

// Simplified form schema with proper types
const editUserSchema = z.object({
  username: z.string().min(2, 'Username must be at least 2 characters'),
  firstName: z.string().optional(),
  middleName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email('Please enter a valid email'),
  mobileNumber: z.string().min(10, 'Please enter a valid mobile number'),
  countryCode: z.string().min(1, 'Country code is required'),
  role: z.enum(roles as [string, ...string[]]),
  salaryType: z.enum(['monthly', 'daily']).optional(),
  otApplicable: z.enum(['yes', 'no']).optional(),
  jobTitle: z.string().optional(),
  department: z.string().optional(),
  branch: z.string().optional(),
  employeeCode: z.string().optional(),
  phone: z.string().optional(),
  fax: z.string().optional(),
  linkedVendor: z.string().optional(),
  epfNo: z.string().optional(),
  esicNo: z.string().optional(),
  stdCode: z.string().optional(),
  panNumber: z.string().optional(),
  cardCode: z.string().optional(),
  cardName: z.string().optional(),
  loanCardCode: z.string().optional(),
  loanCardName: z.string().optional(),
  dateOfJoining: z.string().optional(),
  reportingManagerId: z.string().min(1, "Reporting Manager is required"),
  workLocationId: z.string().optional(), // Keep as string to avoid conversion issues
  userType: z.enum(['system_user', 'non_system_user']).optional(),
  password: z.string().optional(), // Optional for updates
  // Duty Schedule fields
  dutyTimeIn: z.string().optional(),
  dutyTimeOut: z.string().optional(),
  allowedLateMinutes: z.number().optional(),
  earlyExitMinutes: z.number().optional(),
  // Work Time Policy
  workTimePolicy: z.enum(['Fixed', 'Flexible']).optional(),
  minimumDailyHours: z.number().optional(),
  halfDayMinimumHours: z.number().optional(),
  weeklyOffDays: z.array(z.number()).optional(),
  employeeType: z.enum(employeeTypes).optional(),
});

type EditUserFormValues = z.infer<typeof editUserSchema>;

interface User {
  id: number;
  username: string;
  email: string;
  mobileNumber: string;
  countryCode: string;
  role: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  jobTitle?: string;
  department?: string;
  branch?: string;
  employeeCode?: string;
  phone?: string;
  fax?: string;
  linkedVendor?: string;
  epfNo?: string;
  esicNo?: string;
  stdCode?: string;
  panNumber?: string;
  cardCode?: string;
  cardName?: string;
  loanCardCode?: string;
  loanCardName?: string;
  dateOfJoining?: string;
  reportingManagerId?: number;
  workLocationId?: number;
  userType?: string;
  isActive: boolean;
  // Duty Schedule fields
  dutyTimeIn?: string;
  dutyTimeOut?: string;
  allowedLateMinutes?: number;
  earlyExitMinutes?: number;
  // Work Time Policy
  workTimePolicy?: 'Fixed' | 'Flexible';
  minimumDailyHours?: number;
  halfDayMinimumHours?: number;
  weeklyOffDays?: number[];
  employeeType?: string;
}

interface UserEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: User | null;
}

export function UserEditDialog({ open, onOpenChange, user }: UserEditDialogProps) {
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: allUsers = [] } = useQuery<any[]>({
    queryKey: ['/api/admin/users'],
    enabled: open,
  });

  // Get work locations
  const { data: workLocations = [] } = useQuery({
    queryKey: ['/api/work-locations/active'],
    enabled: open,
  });

  const form = useForm<EditUserFormValues>({
    resolver: zodResolver(editUserSchema),
    defaultValues: {
      username: '',
      firstName: '',
      middleName: '',
      lastName: '',
      email: '',
      mobileNumber: '',
      countryCode: '+91',
      role: 'Employee',
      salaryType: 'monthly',
      otApplicable: 'no',
      jobTitle: '',
      department: '',
      branch: '',
      employeeCode: '',
      phone: '',
      fax: '',
      linkedVendor: '',
      epfNo: '',
      esicNo: '',
      stdCode: '',
      panNumber: '',
      cardCode: '',
      cardName: '',
      loanCardCode: '',
      loanCardName: '',
      dateOfJoining: '',
      reportingManagerId: '',
      workLocationId: 'none',
      userType: 'system_user',
      password: '',
      // Duty Schedule defaults
      dutyTimeIn: '09:00',
      dutyTimeOut: '18:00',
      allowedLateMinutes: 15,
      earlyExitMinutes: 15,
      // Work Time Policy defaults
      workTimePolicy: 'Fixed',
      minimumDailyHours: 8,
      halfDayMinimumHours: 4,
      weeklyOffDays: [0, 6],
    },
  });

  const selectedRole = form.watch('role');

  const getEligibleManagers = (role: string | undefined) => {
    if (!role || !allUsers.length) return [];
    const managersByRole = allUsers.reduce((acc: Record<string, any[]>, manager: any) => {
      if (manager.id !== user?.id && canManage(manager.role, role)) {
        if (!acc[manager.role]) acc[manager.role] = [];
        acc[manager.role].push(manager);
      }
      return acc;
    }, {});
    return Object.entries(managersByRole).sort(
      ([roleA], [roleB]) => {
        const hierarchyA = (roleHierarchy as any)[roleA] !== undefined ? (roleHierarchy as any)[roleA] : 999;
        const hierarchyB = (roleHierarchy as any)[roleB] !== undefined ? (roleHierarchy as any)[roleB] : 999;
        return hierarchyA - hierarchyB;
      }
    );
  };

  // Reset form when user changes
  useEffect(() => {
    if (user && open) {
      form.reset({
        username: user.username || '',
        firstName: user.firstName || '',
        middleName: user.middleName || '',
        lastName: user.lastName || '',
        email: user.email || '',
        mobileNumber: user.mobileNumber || '',
        countryCode: user.countryCode || '+91',
        role: user.role || 'Employee',
        salaryType: (user as any).salaryType || 'monthly',
        otApplicable: (user as any).otApplicable || 'no',
        jobTitle: user.jobTitle || '',
        department: user.department || '',
        branch: user.branch || '',
        employeeCode: user.employeeCode || '',
        phone: user.phone || '',
        fax: user.fax || '',
        linkedVendor: user.linkedVendor || '',
        epfNo: user.epfNo || '',
        esicNo: user.esicNo || '',
        stdCode: user.stdCode || '',
        panNumber: (user as any).panNumber || '',
        cardCode: (user as any).cardCode || '',
        cardName: (user as any).cardName || '',
        loanCardCode: (user as any).loanCardCode || '',
        loanCardName: (user as any).loanCardName || '',
        dateOfJoining: (user as any).dateOfJoining || '',
        reportingManagerId: user.reportingManagerId ? user.reportingManagerId.toString() : '',
        workLocationId: user.workLocationId ? user.workLocationId.toString() : 'none',
        userType: (user.userType as 'system_user' | 'non_system_user') || 'system_user',
        employeeType: ((user as any).employeeType as EmployeeType) || 'PERMANENT',
        password: '',
        // Duty Schedule fields
        dutyTimeIn: user.dutyTimeIn || '09:00',
        dutyTimeOut: user.dutyTimeOut || '18:00',
        allowedLateMinutes: user.allowedLateMinutes ?? 15,
        earlyExitMinutes: user.earlyExitMinutes ?? 15,
        // Work Time Policy fields
        workTimePolicy: (user.workTimePolicy as 'Fixed' | 'Flexible') || 'Fixed',
        minimumDailyHours: user.minimumDailyHours ?? 8,
        halfDayMinimumHours: user.halfDayMinimumHours ?? 4,
        weeklyOffDays: (user as any).weeklyOffDays ?? [0, 6],
      });
    }
  }, [user, open, form]);

  const updateUserMutation = useMutation({
    mutationFn: async (data: EditUserFormValues) => {
      if (!user) throw new Error('No user selected');

      // Clean and prepare data for API
      const cleanedData: any = {
        username: data.username.trim(),
        firstName: data.firstName?.trim() || null,
        middleName: data.middleName?.trim() || null,
        lastName: data.lastName?.trim() || null,
        email: data.email.trim(),
        mobileNumber: data.mobileNumber.trim(),
        countryCode: data.countryCode.trim(),
        role: data.role,
        salaryType: data.salaryType || 'monthly',
        otApplicable: data.otApplicable || 'no',
        jobTitle: data.jobTitle?.trim() || null,
        department: data.department?.trim() || null,
        branch: data.branch?.trim() || null,
        employeeCode: data.employeeCode?.trim() || null,
        phone: data.phone?.trim() || null,
        fax: data.fax?.trim() || null,
        linkedVendor: data.linkedVendor?.trim() || null,
        epfNo: data.epfNo?.trim() || null,
        esicNo: data.esicNo?.trim() || null,
        stdCode: data.stdCode?.trim() || null,
        panNumber: data.panNumber?.trim() || null,
        cardCode: data.cardCode?.trim() || null,
        cardName: data.cardName?.trim() || null,
        loanCardCode: data.loanCardCode?.trim() || null,
        loanCardName: data.loanCardName?.trim() || null,
        dateOfJoining: data.dateOfJoining?.trim() || null,
        userType: data.userType || 'system_user',
        employeeType: data.employeeType || 'PERMANENT',
        // Convert string IDs to numbers, handle empty strings and "none" values properly
        reportingManagerId: parseInt(data.reportingManagerId),
        workLocationId: data.workLocationId && data.workLocationId !== '' && data.workLocationId !== 'none'
          ? parseInt(data.workLocationId) 
          : null,
        // Duty Schedule fields
        dutyTimeIn: data.dutyTimeIn || '09:00',
        dutyTimeOut: data.dutyTimeOut || '18:00',
        allowedLateMinutes: data.allowedLateMinutes ?? 15,
        earlyExitMinutes: data.earlyExitMinutes ?? 15,
        // Work Time Policy fields
        workTimePolicy: data.workTimePolicy || 'Fixed',
        minimumDailyHours: data.minimumDailyHours ?? 8,
        halfDayMinimumHours: data.halfDayMinimumHours ?? 4,
        weeklyOffDays: data.weeklyOffDays ?? [0, 6],
      };

      // Only include password if it's provided
      if (data.password && data.password.trim() !== '') {
        cleanedData.password = data.password.trim();
      }

      console.log('Updating user with ID:', user.id);

      return apiRequest('PUT', `/api/admin/users/${user.id}`, cleanedData);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'User updated successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      console.error('Update user error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to update user',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: EditUserFormValues) => {
    updateUserMutation.mutate(data);
  };

  if (!user) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit User</DialogTitle>
          <DialogDescription>
            Update user information for {user.username}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Basic Information */}
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Username *</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter username" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter first name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter last name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cardCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Card Code</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter SAP card code" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cardName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Card Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter SAP card name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="loanCardCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Card Code</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter SAP loan card code" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="loanCardName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Card Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter SAP loan card name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email *</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Enter email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="mobileNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter mobile number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {roles.map((role) => (
                          <SelectItem key={role} value={role}>
                            {role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="employeeType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || 'PERMANENT'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select employee type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {employeeTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {employeeTypeLabels[type]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="salaryType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Salary Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || 'monthly'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select salary type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="otApplicable"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>OT Applicable</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || 'no'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select OT applicable" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="no">No</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="userType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || 'system_user'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select user type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="system_user">System User</SelectItem>
                        <SelectItem value="non_system_user">Non-System User</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="text-xs text-muted-foreground">
                      System Users use attendance/leave/DWAR and go through the payroll run engine. Non-System Users have their salary processed manually.
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Accounts">Accounts</SelectItem>
                        <SelectItem value="Administration">Administration</SelectItem>
                        <SelectItem value="After Sales">After Sales</SelectItem>
                        <SelectItem value="Design">Design</SelectItem>
                        <SelectItem value="General">General</SelectItem>
                        <SelectItem value="Marketing">Marketing</SelectItem>
                        <SelectItem value="Production">Production</SelectItem>
                        <SelectItem value="Projects">Projects</SelectItem>
                        <SelectItem value="Purchase">Purchase</SelectItem>
                        <SelectItem value="Quality Control">Quality Control</SelectItem>
                        <SelectItem value="Stores">Stores</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="jobTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter job title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="employeeCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee Code</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter employee code" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="panNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>PAN Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. ABCDE1234F" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="epfNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>EPF Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. MH/BAN/0012345/000/0001234" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dateOfJoining"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date of Joining</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reportingManagerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reporting Manager <span className="text-red-500">*</span></FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select reporting manager" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getEligibleManagers(selectedRole).map(([role, managers]: [string, any[]]) => (
                          <SelectGroup key={role}>
                            <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">
                              {role}s
                            </SelectLabel>
                            {managers.map((manager: any) => (
                              <SelectItem key={manager.id} value={manager.id.toString()}>
                                {manager.firstName && manager.lastName
                                  ? `${manager.firstName} ${manager.lastName} (${manager.username})`
                                  : manager.username
                                }
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="workLocationId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Work Location</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select work location" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">No Location</SelectItem>
                        {workLocations?.map((location: any) => (
                          <SelectItem key={location.id} value={location.id.toString()}>
                            {location.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          type={showPassword ? "text" : "password"}
                          placeholder="Leave blank to keep current password"
                          {...field}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </FormControl>
                    <div className="text-xs text-muted-foreground">
                      Leave blank to keep current password
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Duty Schedule Section */}
            <div className="border-t pt-4 mt-4">
              <h3 className="text-sm font-semibold text-blue-600 dark:text-blue-400 mb-4">Duty Schedule</h3>
              
              {/* Work Time Policy */}
              <FormField
                control={form.control}
                name="workTimePolicy"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>Work Time Policy</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || 'Fixed'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select policy" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Fixed">Fixed - Uses duty time with late/early rules</SelectItem>
                        <SelectItem value="Flexible">Flexible - Uses minimum daily hours only</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Weekly Off Days */}
              <FormField
                control={form.control}
                name="weeklyOffDays"
                render={({ field }) => {
                  const days = [
                    { value: 0, label: 'Sun' },
                    { value: 1, label: 'Mon' },
                    { value: 2, label: 'Tue' },
                    { value: 3, label: 'Wed' },
                    { value: 4, label: 'Thu' },
                    { value: 5, label: 'Fri' },
                    { value: 6, label: 'Sat' },
                  ];
                  const selected = field.value || [0, 6];
                  const toggle = (dayVal: number) => {
                    const newVal = selected.includes(dayVal)
                      ? selected.filter((d: number) => d !== dayVal)
                      : [...selected, dayVal].sort();
                    field.onChange(newVal);
                  };
                  return (
                    <FormItem className="mb-4">
                      <FormLabel>Weekly Off Days</FormLabel>
                      <div className="flex gap-2 flex-wrap">
                        {days.map(day => (
                          <button
                            key={day.value}
                            type="button"
                            onClick={() => toggle(day.value)}
                            className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-colors ${
                              selected.includes(day.value)
                                ? 'bg-red-100 border-red-400 text-red-700'
                                : 'bg-gray-50 border-gray-200 text-gray-500 hover:bg-gray-100'
                            }`}
                          >
                            {day.label}
                          </button>
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {selected.length === 0 ? 'No weekly off (all 7 days working)' : `Off: ${selected.map((d: number) => ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d]).join(', ')}`}
                      </p>
                      <FormMessage />
                    </FormItem>
                  );
                }}
              />

              {/* Fixed Policy Fields */}
              {form.watch('workTimePolicy') !== 'Flexible' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="dutyTimeIn"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duty Time In</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field} 
                            value={field.value || '09:00'}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dutyTimeOut"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duty Time Out</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field}
                            value={field.value || '18:00'}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="allowedLateMinutes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Allowed Late Minutes</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={0}
                            max={120}
                            placeholder="15"
                            {...field}
                            value={field.value ?? 15}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground">Minutes allowed after duty time in</p>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="earlyExitMinutes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Early Exit Minutes</FormLabel>
                        <FormControl>
                          <Input 
                            type="number"
                            min={0}
                            max={120}
                            placeholder="15"
                            {...field}
                            value={field.value ?? 15}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground">Minutes allowed before duty time out</p>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Flexible Policy Fields */}
              {form.watch('workTimePolicy') === 'Flexible' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="minimumDailyHours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Daily Hours (Present)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1}
                            max={24}
                            step={0.5}
                            placeholder="8"
                            {...field}
                            value={field.value ?? 8}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 8)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground">Hours required for Present status</p>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="halfDayMinimumHours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Hours (Half Day)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number"
                            min={1}
                            max={24}
                            step={0.5}
                            placeholder="4"
                            {...field}
                            value={field.value ?? 4}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 4)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground">Hours required for Half Day (below = Absent)</p>
                      </FormItem>
                    )}
                  />
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={updateUserMutation.isPending}
              >
                {updateUserMutation.isPending ? 'Updating...' : 'Update User'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}