/**
 * DrawingVerificationCard
 *
 * Shows the SolidWorks extraction job status for a drawing control.
 * Provides upload UI to submit a .slddrw file and create a pending extraction job.
 *
 * Data source: GET /api/epc-drawing-controls/:id/slddrw-jobs
 * Upload:      POST /api/epc-drawing-controls/:id/upload-slddrw
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  ShieldCheck, ShieldAlert, Shield, RotateCcw, ChevronDown,
  AlertTriangle, Clock, Loader2,
  Server, Cpu, FileCheck2, Upload, RefreshCw, Factory, Braces,
} from 'lucide-react';
import { useRef, useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface Job {
  id: number;
  status: string;
  slddrwFilename: string | null;
  nodeId: string | null;
  machineName: string | null;
  agentVersion: string | null;
  claimedAt: string | null;
  completedAt: string | null;
  failedReason: string | null;
  retryCount: number;
  extractionResult: any;
  createdAt: string;
}

// Roles allowed to approve or release (mirrors RELEASE_GATE_CONFIG)
const ALLOWED_ROLES = ['superuser', 'general manager', 'senior manager'];

interface Props {
  drawingControlId: number;
  userRole: string;
  drawingControlStatus: string;
  manufacturingReleaseRequired: boolean;
  releasedForManufacturing: boolean;
  releasedForManufacturingAt: string | null;
  drawingNumber?: string | null;
  onStatusChange?: () => void;
}

export function DrawingVerificationCard({
  drawingControlId,
  userRole,
  drawingControlStatus,
  manufacturingReleaseRequired,
  releasedForManufacturing,
  releasedForManufacturingAt,
  drawingNumber,
  onStatusChange,
}: Props) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [jsonJobId, setJsonJobId] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());

  const { data: jobs = [], isLoading } = useQuery<Job[]>({
    queryKey: ['/api/epc-drawing-controls', drawingControlId, 'slddrw-jobs'],
    queryFn: () =>
      apiRequest('GET', `/api/epc-drawing-controls/${drawingControlId}/slddrw-jobs`) as Promise<Job[]>,
    refetchInterval: (data: any) => {
      const rows: Job[] = Array.isArray(data) ? data : (data?.state?.data ?? []);
      const latest = rows[0];
      if (latest && ['pending', 'processing'].includes(latest.status)) return 3000;
      return false;
    },
  });

  const retryMutation = useMutation({
    mutationFn: (jobId: number) =>
      apiRequest('POST', `/api/epc-slddrw-jobs/${jobId}/retry`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/epc-drawing-controls', drawingControlId, 'slddrw-jobs'] });
    },
  });

  // Live elapsed timer — ticks every second while a job is active
  useEffect(() => {
    const latest = jobs[0];
    if (!latest || !['pending', 'processing'].includes(latest.status)) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [jobs]);

  const approveMutation = useMutation({
    mutationFn: ({ acknowledgeWarnings }: { acknowledgeWarnings: boolean }) =>
      apiRequest('POST', `/api/epc-drawing-controls/${drawingControlId}/approve`, {
        acknowledge_warnings: acknowledgeWarnings,
      }),
    onSuccess: () => {
      toast({ title: 'Drawing approved', description: 'Drawing control has been approved.' });
      qc.invalidateQueries({ queryKey: ['/api/epc-drawing-controls', drawingControlId, 'slddrw-jobs'] });
      onStatusChange?.();
    },
    onError: (err: any) => {
      toast({ title: 'Approval failed', description: err?.message ?? 'Unknown error', variant: 'destructive' });
    },
  });

  const releaseMutation = useMutation({
    mutationFn: () =>
      apiRequest('POST', `/api/epc-drawing-controls/${drawingControlId}/release/manufacturing`),
    onSuccess: () => {
      toast({ title: 'Released for Manufacturing', description: 'Drawing has been released for manufacturing.' });
      qc.invalidateQueries({ queryKey: ['/api/epc-drawing-controls', drawingControlId, 'slddrw-jobs'] });
      onStatusChange?.();
    },
    onError: (err: any) => {
      toast({ title: 'Release failed', description: err?.message ?? 'Unknown error', variant: 'destructive' });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const fd = new FormData();
      fd.append('file', file);
      return apiRequest('POST', `/api/epc-drawing-controls/${drawingControlId}/upload-slddrw`, fd);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/epc-drawing-controls', drawingControlId, 'slddrw-jobs'] });
      toast({ title: 'Extraction job created', description: 'Waiting for Windows agent to pick up the job.' });
      if (fileInputRef.current) fileInputRef.current.value = '';
    },
    onError: (err: any) => {
      toast({ title: 'Upload failed', description: err?.message ?? 'Unknown error', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
    },
  });

  const {
    data: extractionJson,
    isFetching: isJsonLoading,
    error: jsonError,
  } = useQuery<any>({
    queryKey: ['/api/extraction-results', jsonJobId],
    queryFn: () => apiRequest('GET', `/api/extraction-results/${jsonJobId}`),
    enabled: jsonJobId !== null,
  });

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.slddrw')) {
      toast({ title: 'Invalid file', description: 'Only .slddrw files are accepted.', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    // Client-side filename gate — allow exact match OR drawing number as prefix (revision suffix OK)
    if (drawingNumber) {
      const basename = file.name.slice(0, file.name.length - '.slddrw'.length).toLowerCase();
      const dn = drawingNumber.toLowerCase();
      // Accept: exact match OR basename starts with drawing number followed by space/dash/underscore/Rev
      const exactMatch = basename === dn;
      const prefixMatch = basename.startsWith(dn) && (
        basename.length === dn.length ||
        /^[-_ ]/.test(basename.slice(dn.length))
      );
      if (!exactMatch && !prefixMatch) {
        toast({
          title: 'Filename mismatch',
          description: `Filename must start with Drawing Number. Expected: ${drawingNumber}.slddrw (revision suffix like -RevA or _RevB is allowed)`,
          variant: 'destructive',
        });
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }
    }
    uploadMutation.mutate(file);
  }

  const latest = jobs[0] ?? null;
  const _role = userRole.toLowerCase();
  const canApproveOrRelease = ALLOWED_ROLES.includes(_role);
  const isUploading = uploadMutation.isPending;
  const extractionWarnings = Array.isArray(latest?.extractionResult?.extraction_warnings)
    ? latest.extractionResult.extraction_warnings.filter((warning: any) => typeof warning === 'string')
    : [];

  // Section D verification status from extraction result
  const cpVerif = latest?.extractionResult?.customPropertyVerification;
  const sectionDStatus: string | null = cpVerif?.status ?? null;
  // Fields use `result` key (not `status`) — collect any that are hold or fail
  const sectionDBlockedFields: string[] = Array.isArray(cpVerif?.fields)
    ? cpVerif.fields
        .filter((f: any) => f.result === 'hold' || f.result === 'fail')
        .map((f: any) => f.property ?? f.field)
        .filter(Boolean)
    : [];
  const sectionDBlocked = sectionDStatus === 'hold' || sectionDStatus === 'fail';

  if (isLoading) {
    return (
      <_CardShell status="idle">
        <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Loading…
        </div>
      </_CardShell>
    );
  }

  if (!latest) {
    return (
      <_CardShell status="idle">
        <p className="text-[10px] text-muted-foreground italic mb-2">
          No extraction job yet. Upload a <span className="font-medium">.slddrw</span> file to trigger extraction.
        </p>
        <_UploadButton
          fileInputRef={fileInputRef}
          isUploading={isUploading}
          onChange={handleFileChange}
        />
      </_CardShell>
    );
  }

  return (
    <_CardShell status={latest.status}>
      {/* ── Header row ─────────────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5">
          <_JobStatusBadge status={latest.status} />
          {latest.slddrwFilename && (
            <span className="text-[10px] text-muted-foreground truncate max-w-[180px]">
              {latest.slddrwFilename}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {latest.status === 'failed' && canApproveOrRelease && (
            <Button
              variant="outline"
              size="sm"
              className="h-5 text-[9px] px-1.5 gap-1"
              disabled={retryMutation.isPending}
              onClick={() => retryMutation.mutate(latest.id)}
            >
              <RotateCcw className="h-2.5 w-2.5" />
              Retry
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            className="h-5 text-[9px] px-1.5 gap-1"
            disabled={!latest.extractionResult}
            onClick={() => setJsonJobId(latest.id)}
          >
            <Braces className="h-2.5 w-2.5" />
            View JSON
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-5 text-[9px] px-1.5 gap-0.5"
            onClick={() => setShowDetails(s => !s)}
          >
            <ChevronDown className={cn("h-2.5 w-2.5 transition-transform", showDetails && "rotate-180")} />
            {showDetails ? 'Less' : 'Details'}
          </Button>
        </div>
      </div>

      {/* ── Pending / processing state ──────────────────────────────── */}
      {['pending', 'processing'].includes(latest.status) && (() => {
        const startMs = latest.claimedAt
          ? new Date(latest.claimedAt).getTime()
          : new Date(latest.createdAt).getTime();
        const elapsed = Math.floor((now - startMs) / 1000);
        const elapsedStr = elapsed >= 60
          ? `${Math.floor(elapsed / 60)}m ${elapsed % 60}s`
          : `${elapsed}s`;
        return (
          <div className="mt-1 space-y-0.5">
            <div className="flex items-center gap-1.5 text-[10px] text-blue-600">
              <Loader2 className="h-3 w-3 animate-spin shrink-0" />
              {latest.status === 'pending'
                ? 'Waiting for Windows agent to pick up job…'
                : `Extracting on ${latest.machineName ?? latest.nodeId ?? 'agent'} — ${elapsedStr} elapsed`}
            </div>
            {latest.status === 'processing' && elapsed > 30 && (
              <div className="text-[9px] text-muted-foreground pl-4">
                SolidWorks startup typically takes 60–120s on first open
              </div>
            )}
          </div>
        );
      })()}

      {/* ── Failed state ────────────────────────────────────────────── */}
      {latest.status === 'failed' && latest.failedReason && (
        <div className="mt-1 text-[10px] text-red-600 bg-red-50 border border-red-200 rounded px-2 py-1">
          <span className="font-medium">Failure: </span>{latest.failedReason}
          {latest.retryCount > 0 && (
            <span className="text-[9px] text-muted-foreground ml-1">
              ({latest.retryCount} attempt{latest.retryCount > 1 ? 's' : ''})
            </span>
          )}
        </div>
      )}

      {latest.status === 'completed' && extractionWarnings.length > 0 && (
        <div className="mt-1 text-[9px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-1.5 py-1">
          <div className="flex items-center gap-1 font-medium">
            <AlertTriangle className="h-2.5 w-2.5 shrink-0" />
            Extraction warning
          </div>
          <div className="mt-0.5 line-clamp-2">
            {extractionWarnings[0]}
            {extractionWarnings.length > 1 ? ` (+${extractionWarnings.length - 1} more)` : ''}
          </div>
        </div>
      )}

      {/* ── Approve gate (only when not yet approved) ────────────────── */}
      {latest.status === 'completed' &&
       drawingControlStatus !== 'approved' &&
       drawingControlStatus !== 'released' &&
       canApproveOrRelease && (
        <div className="mt-2 pt-2 border-t border-border/40 space-y-1.5">
          {/* Section D hold / fail warning — with per-field breakdown */}
          {sectionDBlocked && (
            <div className={cn(
              "text-[10px] rounded px-2 py-1.5 border space-y-1",
              sectionDStatus === 'fail'
                ? "text-red-700 bg-red-50 border-red-200"
                : "text-amber-700 bg-amber-50 border-amber-200",
            )}>
              <div className="flex items-center gap-1.5">
                <ShieldAlert className={cn("h-3 w-3 shrink-0", sectionDStatus === 'fail' ? "text-red-600" : "text-amber-600")} />
                <span className="font-semibold">
                  {sectionDStatus === 'fail' ? 'Section D failed — approval blocked' : 'Section D on hold — approval blocked'}
                </span>
              </div>
              {/* Per-field breakdown */}
              {Array.isArray(cpVerif?.fields) && cpVerif.fields.some((f: any) => f.result !== 'pass') && (
                <table className="w-full text-[9.5px] border-collapse mt-0.5">
                  <thead>
                    <tr className={cn("border-b", sectionDStatus === 'fail' ? "border-red-200" : "border-amber-200")}>
                      <th className="text-left py-0.5 pr-2 font-semibold w-[110px]">Field</th>
                      <th className="text-left py-0.5 pr-2 font-semibold w-[90px]">Value</th>
                      <th className="text-left py-0.5 font-semibold">Reason</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(cpVerif.fields as any[])
                      .filter((f: any) => f.result !== 'pass')
                      .map((f: any) => (
                        <tr key={f.property} className="align-top">
                          <td className="py-0.5 pr-2 font-medium">{f.property}</td>
                          <td className="py-0.5 pr-2 font-mono">{f.value || <span className="italic opacity-60">empty</span>}</td>
                          <td className="py-0.5 opacity-80">
                            {f.result === 'hold'
                              ? 'Requires human sign-off (value set to "Agent")'
                              : f.reason || 'Does not meet requirements'}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
          <Button
            size="sm"
            className="h-6 text-[10px] px-2 w-full gap-1.5"
            variant={sectionDBlocked ? 'outline' : 'default'}
            disabled={approveMutation.isPending || sectionDBlocked}
            onClick={() => approveMutation.mutate({})}
          >
            {approveMutation.isPending
              ? <Loader2 className="h-2.5 w-2.5 animate-spin" />
              : <ShieldCheck className="h-2.5 w-2.5" />}
            {sectionDBlocked
              ? sectionDStatus === 'fail'
                ? 'Cannot Approve — Section D Failed'
                : 'Cannot Approve — Section D on Hold'
              : 'Approve Drawing'}
          </Button>
        </div>
      )}

      {/* ── Manufacturing release gate ────────────────────────────────── */}
      {manufacturingReleaseRequired && canApproveOrRelease && (
        <div className="mt-2 pt-2 border-t border-border/40">
          {releasedForManufacturing ? (
            <div className="flex items-center gap-1.5 text-[10px] text-green-700 bg-green-50 border border-green-200 rounded px-2 py-1.5">
              <Factory className="h-3 w-3 shrink-0" />
              <span>
                Released for Manufacturing
                {releasedForManufacturingAt && (
                  <span className="text-[9px] text-muted-foreground ml-1">
                    · {formatDistanceToNow(new Date(releasedForManufacturingAt), { addSuffix: true })}
                  </span>
                )}
              </span>
            </div>
          ) : drawingControlStatus === 'approved' ? (
            <Button
              size="sm"
              className="h-6 text-[10px] px-2 w-full gap-1.5"
              variant="default"
              disabled={releaseMutation.isPending}
              onClick={() => releaseMutation.mutate()}
            >
              {releaseMutation.isPending
                ? <Loader2 className="h-2.5 w-2.5 animate-spin" />
                : <Factory className="h-2.5 w-2.5" />}
              Release for Manufacturing
            </Button>
          ) : (
            <Button
              size="sm"
              className="h-6 text-[10px] px-2 w-full gap-1.5"
              variant="outline"
              disabled
            >
              <Factory className="h-2.5 w-2.5" />
              Release for Manufacturing — Awaiting Approval
            </Button>
          )}
        </div>
      )}

      {/* ── Upload new (for failed / completed) ─────────────────────── */}
      {(latest.status === 'failed' || latest.status === 'completed') && (
        <div className="mt-2 pt-2 border-t border-border/40">
          <_UploadButton
            fileInputRef={fileInputRef}
            isUploading={isUploading}
            onChange={handleFileChange}
            label="Upload New .slddrw"
            icon={<RefreshCw className="h-2.5 w-2.5" />}
          />
        </div>
      )}

      {/* ── Detail panel ────────────────────────────────────────────── */}
      {showDetails && (
        <div className="mt-2 pt-2 border-t border-border/50 space-y-1">
          <_DetailRow icon={<Clock className="h-2.5 w-2.5" />} label="Created">
            {_relTime(latest.createdAt)}
          </_DetailRow>
          {latest.nodeId && (
            <_DetailRow icon={<Server className="h-2.5 w-2.5" />} label="Node">
              {latest.nodeId}{latest.machineName ? ` (${latest.machineName})` : ''}
            </_DetailRow>
          )}
          {latest.agentVersion && (
            <_DetailRow icon={<Cpu className="h-2.5 w-2.5" />} label="Agent">
              v{latest.agentVersion}
            </_DetailRow>
          )}
          {latest.completedAt && (
            <_DetailRow icon={<FileCheck2 className="h-2.5 w-2.5" />} label="Completed">
              {_relTime(latest.completedAt)}
            </_DetailRow>
          )}
          {latest.extractionResult && (
            <_ExtractionSummary result={latest.extractionResult} />
          )}
          {jobs.length > 1 && (
            <p className="text-[9px] text-muted-foreground mt-1">
              {jobs.length - 1} earlier job{jobs.length > 2 ? 's' : ''}
            </p>
          )}
        </div>
      )}
      <Dialog open={jsonJobId !== null} onOpenChange={(open) => !open && setJsonJobId(null)}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="text-sm">Extraction JSON</DialogTitle>
            <DialogDescription className="text-xs">
              Job {jsonJobId}{extractionJson?.file_name ? ` · ${extractionJson.file_name}` : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-md border bg-slate-950 text-slate-50 overflow-auto max-h-[68vh]">
            {isJsonLoading ? (
              <div className="flex items-center gap-2 p-4 text-xs text-slate-300">
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Loading JSON…
              </div>
            ) : jsonError ? (
              <div className="p-4 text-xs text-red-300">
                Failed to load extraction JSON.
              </div>
            ) : (
              <pre className="p-4 text-[11px] leading-relaxed whitespace-pre-wrap break-words">
                {JSON.stringify(extractionJson, null, 2)}
              </pre>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </_CardShell>
  );
}

// ── Upload button ────────────────────────────────────────────────────────────

function _UploadButton({
  fileInputRef,
  isUploading,
  onChange,
  label = 'Upload .slddrw',
  icon,
}: {
  fileInputRef: React.RefObject<HTMLInputElement>;
  isUploading: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  label?: string;
  icon?: React.ReactNode;
}) {
  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept=".slddrw"
        className="hidden"
        onChange={onChange}
        disabled={isUploading}
      />
      <Button
        variant="outline"
        size="sm"
        className="h-6 text-[10px] px-2 gap-1.5 w-full"
        disabled={isUploading}
        onClick={() => fileInputRef.current?.click()}
      >
        {isUploading
          ? <Loader2 className="h-2.5 w-2.5 animate-spin" />
          : (icon ?? <Upload className="h-2.5 w-2.5" />)}
        {isUploading ? 'Uploading…' : label}
      </Button>
    </>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function _CardShell({
  status,
  children,
}: {
  status: string;
  children: React.ReactNode;
}) {
  const border = status === 'failed' ? 'border-red-200 bg-red-50/20' : 'border-dashed border-blue-200 bg-blue-50/30';

  return (
    <div className={cn("rounded-lg border shadow-sm", border)}>
      <div className="flex items-center gap-1.5 px-3 py-2 font-medium text-[11px] text-blue-700">
        <ShieldCheck className="h-3.5 w-3.5 text-blue-600" />
        Drawing Verification
      </div>
      <div className="px-3 pb-3 space-y-1">
        {children}
      </div>
    </div>
  );
}

function _JobStatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; variant: string }> = {
    pending:    { label: 'Queued',     variant: 'bg-blue-100 text-blue-700 border-blue-200' },
    processing: { label: 'Extracting', variant: 'bg-violet-100 text-violet-700 border-violet-200' },
    completed:  { label: 'Extracted',  variant: 'bg-green-100 text-green-700 border-green-200' },
    failed:     { label: 'Failed',     variant: 'bg-red-100 text-red-700 border-red-200' },
  };
  const cfg = map[status] ?? { label: status, variant: 'bg-muted text-muted-foreground' };
  return (
    <span className={cn("text-[9px] font-medium border rounded px-1.5 py-0.5", cfg.variant)}>
      {cfg.label}
    </span>
  );
}

function _ExtractionSummary({ result }: { result: any }) {
  if (!result) return null;
  const p = result.properties ?? {};
  const ddt = result.design_data_table ?? {};
  const warnings = Array.isArray(result.extraction_warnings) ? result.extraction_warnings : [];
  const sheets = result.sheets ?? [];
  const nozzles = result.nozzles ?? {};
  const errors = result.extraction_errors ?? {};
  const errorKeys = Object.keys(errors).filter(k => errors[k] != null);

  return (
    <div className="mt-1 space-y-0.5 pt-1 border-t border-border/30">
      <p className="text-[9px] font-medium text-muted-foreground uppercase tracking-wide mb-0.5">
        Extraction Summary
      </p>
      {p.drawing_number && (
        <_DetailRow icon={<FileCheck2 className="h-2.5 w-2.5" />} label="DWG No">
          {p.drawing_number} Rev {p.revision || '—'}
        </_DetailRow>
      )}
      <_DetailRow icon={<Shield className="h-2.5 w-2.5" />} label="Design Data">
        {ddt.source === 'notes'
          ? `Notes fallback (${ddt.fallback_text?.length ?? 0})`
          : ddt.found
            ? `${ddt.rows?.length ?? 0} rows`
            : ddt.status === 'missing'
              ? 'Missing'
              : 'Not found'}
      </_DetailRow>
      <_DetailRow icon={<Server className="h-2.5 w-2.5" />} label="Sheets">
        {sheets.length}
      </_DetailRow>
      {nozzles.found && (
        <_DetailRow icon={<Cpu className="h-2.5 w-2.5" />} label="Nozzles">
          {nozzles.nozzle_count}
        </_DetailRow>
      )}
      {errorKeys.length > 0 && (
        <div className="text-[9px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5">
          Soft errors: {errorKeys.join(', ')}
        </div>
      )}
      {warnings.length > 0 && (
        <div className="text-[9px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5">
          Warnings: {warnings.slice(0, 3).join(' · ')}
          {warnings.length > 3 ? ` · +${warnings.length - 3} more` : ''}
        </div>
      )}
    </div>
  );
}

function _DetailRow({
  icon, label, children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
      {icon}
      <span className="font-medium text-foreground/70">{label}:</span>
      <span>{children}</span>
    </div>
  );
}

function _relTime(iso: string) {
  try {
    return formatDistanceToNow(new Date(iso), { addSuffix: true });
  } catch {
    return iso;
  }
}
