import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { GmailMessage, InsertTask, User } from "@shared/schema";
import { roles, roleHierarchy } from "@shared/roles";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import type { CheckedState } from "@radix-ui/react-checkbox";
import {
  RotateCw,
  Mail,
  MailOpen,
  Star,
  Trash,
  Trash2,
  AlertCircle,
  Filter,
  Settings,
  ArrowLeft,
  ArrowRight,
  AlertTriangle,
  FolderCheck,
  ListTodo,
  Shield,
  Brain,
  Sparkles,
  MessageSquare,
  Copy,
  CheckCircle,
  Reply,
  ReplyAll,
  Forward,
} from "lucide-react";
import GcsDiagnostics from "@/components/gcs-diagnostics";
import { format } from "date-fns";

// Helper function to get priority badge style
const getPriorityBadgeStyle = (priority?: string | null) => {
  switch (priority) {
    case 'P0':
      return 'bg-red-100 text-red-700 border-red-300';
    case 'P1':
      return 'bg-orange-100 text-orange-700 border-orange-300';
    case 'P2':
      return 'bg-blue-100 text-blue-700 border-blue-300';
    case 'P3':
      return 'bg-gray-100 text-gray-700 border-gray-300';
    default:
      return 'bg-gray-100 text-gray-600 border-gray-200';
  }
};

const getPriorityLabel = (priority?: string | null) => {
  switch (priority) {
    case 'P0':
      return 'Critical';
    case 'P1':
      return 'High';
    case 'P2':
      return 'Normal';
    case 'P3':
      return 'Low';
    default:
      return 'Unknown';
  }
};

export default function GmailMessages() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedMessageId, setSelectedMessageId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPriority, setFilterPriority] = useState<string>("high"); // Default to P0+P1 (high priority)
  const [showFilters, setShowFilters] = useState(false);
  const [activeTab, setActiveTab] = useState("inbox");
  
  // AI Analysis states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [isGeneratingReply, setIsGeneratingReply] = useState(false);
  const [replyData, setReplyData] = useState<any>(null);
  const [selectedReplyStyle, setSelectedReplyStyle] = useState<'professional' | 'brief' | 'detailed'>('professional');
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showReplyGeneration, setShowReplyGeneration] = useState(false);

  // Bulk selection states
  const [selectedEmails, setSelectedEmails] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isBulkMarkingRead, setIsBulkMarkingRead] = useState(false);
  const [isBulkMarkingUnread, setIsBulkMarkingUnread] = useState(false);

  // Sync progress state
  const [syncProgress, setSyncProgress] = useState<any>(null);
  const progressIntervalRef = React.useRef<NodeJS.Timeout | null>(null);

  // Compose email states
  const [showComposeDialog, setShowComposeDialog] = useState(false);
  const [composeType, setComposeType] = useState<'reply' | 'replyAll' | 'forward'>('reply');
  const [composeTo, setComposeTo] = useState('');
  const [composeCc, setComposeCc] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Gmail connection status
  const { data: connectionStatus, isLoading: isLoadingStatus } = useQuery({
    queryKey: ["/api/gmail/status"],
    queryFn: async () => {
      return await apiRequest("GET", "/api/gmail/status");
    }
  });

  // Gmail settings
  const { data: settings, isLoading: isLoadingSettings } = useQuery({
    queryKey: ["/api/gmail/settings"],
    queryFn: async () => {
      return await apiRequest("GET", "/api/gmail/settings");
    },
    enabled: connectionStatus?.connected === true
  });
  
  // Get all users for assignment dropdown
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  // Group users by role for the task assignment dropdown - same format as task-list.tsx
  const groupedUsers = users ? ([...roles] as string[])
    .sort((a: string, b: string) => roleHierarchy[a] - roleHierarchy[b])
    .reduce((acc: Record<string, User[]>, role: string) => {
      const usersInRole = users.filter((u: User) => u.role === role);
      if (usersInRole.length > 0) {
        // Sort alphabetically within each group
        usersInRole.sort((a: User, b: User) => {
          const nameA = a.firstName && a.lastName ? `${a.firstName} ${a.lastName}` : a.username;
          const nameB = b.firstName && b.lastName ? `${b.firstName} ${b.lastName}` : b.username;
          return nameA.localeCompare(nameB);
        });
        acc[role] = usersInRole;
      }
      return acc;
    }, {} as Record<string, User[]>) : {};

  // Gmail messages
  const { data: messages, isLoading: isLoadingMessages, error: messagesError } = useQuery<GmailMessage[]>({
    queryKey: ["/api/gmail/messages", filterStatus, filterPriority, searchTerm],
    queryFn: async () => {
      try {
        console.log('Fetching messages with filters:', { filterStatus, filterPriority, searchTerm });
        const queryParams = new URLSearchParams();
        
        // Always exclude spam emails
        queryParams.set("excludeSpam", "true");
        
        if (filterStatus === "read") {
          queryParams.set("isRead", "true");
          console.log('Setting isRead=true in query params');
        }
        if (filterStatus === "unread") {
          queryParams.set("isRead", "false");
          console.log('Setting isRead=false in query params');
        }
        
        // Priority filtering
        if (filterPriority === "critical") queryParams.set("priority", "P0");
        else if (filterPriority === "high") queryParams.set("priority", "P0,P1");
        else if (filterPriority === "normal") queryParams.set("priority", "P2");
        else if (filterPriority === "low") queryParams.set("priority", "P3");
        
        if (searchTerm) {
          // Search across multiple fields
          if (searchTerm.includes("@")) {
            queryParams.set("from", searchTerm);
          } else {
            queryParams.set("subject", searchTerm);
          }
        }
        
        const queryString = queryParams.toString();
        console.log('Final query string:', queryString);
        const data = await apiRequest("GET", `/api/gmail/messages?${queryString}`);
        console.log('Messages fetched successfully:', data.length);
        
        // Add client-side filtering as a backup if the server filter didn't work
        if (filterStatus === "unread") {
          const readCount = data.filter((m: GmailMessage) => m.isRead).length;
          const unreadCount = data.filter((m: GmailMessage) => !m.isRead).length;
          console.log(`Results should be unread only. Got: ${unreadCount} unread, ${readCount} read messages`);
          
          // Apply client-side filter if we see read messages in the results
          if (readCount > 0) {
            console.log('Applying client-side filter for unread messages');
            return data.filter((m: GmailMessage) => !m.isRead);
          }
        } else if (filterStatus === "read") {
          // Also apply client-side filtering for read messages
          console.log('Applying client-side filter for read messages');
          return data.filter((m: GmailMessage) => m.isRead);
        }
        
        // Apply client-side search filtering
        if (searchTerm && data.length > 0) {
          console.log('Applying client-side search filter for:', searchTerm);
          const lowercaseSearch = searchTerm.toLowerCase();
          
          // Filter by subject or from email address
          return data.filter((m: GmailMessage) => {
            const subject = (m.subject || '').toLowerCase();
            const from = (m.from || '').toLowerCase();
            
            return subject.includes(lowercaseSearch) || 
                   from.includes(lowercaseSearch);
          });
        }
        
        return data;
      } catch (error) {
        console.error('Error fetching messages:', error);
        throw error;
      }
    },
    enabled: connectionStatus?.connected === true
  });

  // Selected message details
  const selectedMessage = selectedMessageId 
    ? messages?.find((m: GmailMessage) => m.id === selectedMessageId) 
    : null;

  // Mark message as read
  const markAsReadMutation = useMutation<GmailMessage, Error, { messageId: number, isRead: boolean }>({
    mutationFn: async ({ messageId, isRead }: { messageId: number, isRead: boolean }): Promise<GmailMessage> => {
      console.log(`Marking message ${messageId} as ${isRead ? 'read' : 'unread'}`);
      return await apiRequest("PATCH", `/api/gmail/messages/${messageId}/read`, { isRead }) as GmailMessage;
    },
    onSuccess: (data, variables) => {
      console.log(`Successfully marked message ${variables.messageId} as ${variables.isRead ? 'read' : 'unread'}`);
      // Update the messages in the cache directly to provide immediate UI feedback
      const previousMessages = queryClient.getQueryData<GmailMessage[]>(["/api/gmail/messages"]);
      if (previousMessages) {
        const updatedMessages = previousMessages.map(msg => 
          msg.id === variables.messageId ? { ...msg, isRead: variables.isRead } : msg
        );
        queryClient.setQueryData(["/api/gmail/messages"], updatedMessages);
      }
      
      // Then invalidate to get fresh data from server
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update read status.",
        variant: "destructive"
      });
    }
  });

  // Toggle message importance
  const toggleImportanceMutation = useMutation<GmailMessage, Error, { messageId: number, important: boolean }>({
    mutationFn: async ({ messageId, important }: { messageId: number, important: boolean }): Promise<GmailMessage> => {
      return await apiRequest("PATCH", `/api/gmail/messages/${messageId}/important`, {
        important
      }) as GmailMessage;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update message importance",
        variant: "destructive"
      });
    }
  });
  
  // Delete message
  const deleteMessageMutation = useMutation<void, Error, number>({
    mutationFn: async (messageId: number): Promise<void> => {
      await apiRequest("DELETE", `/api/gmail/messages/${messageId}`);
    },
    onSuccess: () => {
      setSelectedMessageId(null); // Return to message list after deletion
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
      toast({
        title: "Success",
        description: "Message deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete message",
        variant: "destructive"
      });
    }
  });
  
  // Handle delete message with confirmation
  const handleDeleteMessage = (messageId: number) => {
    setMessageToDelete(messageId);
    setIsDeleteDialogOpen(true);
  };
  
  // Confirm delete message
  const confirmDeleteMessage = () => {
    if (messageToDelete) {
      deleteMessageMutation.mutate(messageToDelete);
      setIsDeleteDialogOpen(false);
      setMessageToDelete(null);
    }
  };

  // Poll for sync progress
  const pollSyncProgress = async () => {
    try {
      const progress = await apiRequest("GET", "/api/gmail/sync/progress");
      setSyncProgress(progress);
      
      // Stop polling if sync is completed or errored
      if (progress.status === 'completed' || progress.status === 'error') {
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current);
          progressIntervalRef.current = null;
        }
        
        // Show completion/error toast
        if (progress.status === 'completed') {
          queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
          toast({
            title: "Sync Complete",
            description: `Successfully synced ${progress.synced} messages (${progress.errors} errors)`,
          });
        } else if (progress.status === 'error') {
          toast({
            title: "Sync Failed",
            description: progress.errorMessage || "An error occurred during sync",
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      console.error('Error polling sync progress:', error);
    }
  };

  // Sync Gmail messages
  const syncMutation = useMutation<any, Error, void>({
    mutationFn: async () => {
      console.log('Starting sync mutation');
      try {
        return await apiRequest("POST", "/api/gmail/sync");
      } catch (error) {
        console.error('Sync mutation error:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log('Sync started, beginning progress polling');
      // Start polling for progress
      const interval = setInterval(pollSyncProgress, 1000); // Poll every second
      progressIntervalRef.current = interval;
      pollSyncProgress(); // Poll immediately
    },
    onError: (error: Error) => {
      console.error('Sync mutation error in callback:', error);
      
      // Handle specific error cases
      let title = "Gmail Sync Failed";
      let description = error.message || "Failed to sync messages from Gmail. Please try again.";
      
      if (error.message && error.message.includes('Gmail API needs to be enabled')) {
        title = "Gmail API Not Enabled";
        // Keep the full error message as it contains the link to enable the API
      } else if (error.message && error.message.includes('already enabled it, please wait')) {
        title = "Gmail API Still Activating";
        description = "The Gmail API is enabled but still activating. Please wait 5-10 minutes for Google to fully activate it across their systems, then try again.";
      } else if (error.message && error.message.includes('authorization has expired')) {
        title = "Authorization Expired";
        description = "Your Gmail authorization has expired. Please disconnect and reconnect your Gmail account.";
      } else if (error.message && error.message.includes('Rate Limit Exceeded')) {
        title = "Rate Limit Exceeded";
        description = "Gmail API rate limit exceeded. Please try again later.";
      }
      
      toast({
        title: title,
        description: description,
        variant: "destructive"
      });
    }
  });

  // Connect to Gmail
  const [authCode, setAuthCode] = useState("");
  const [isSubmittingCode, setIsSubmittingCode] = useState(false);
  const [authUrl, setAuthUrl] = useState<string | null>(null);
  const [manualAuthError, setManualAuthError] = useState<string | null>(null); // Used for storing validation errors in the form
  
  // Task conversion modal state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskFormData, setTaskFormData] = useState<Partial<InsertTask>>({});
  const [editEmailData, setEditEmailData] = useState<{messageId?: number, subject?: string, body?: string, from?: string}>({});
  
  // Delete confirmation dialog state
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [messageToDelete, setMessageToDelete] = useState<number | null>(null);
  
  // Format to ISO date string in YYYY-MM-DD format
  const formatDateForTask = (date: Date): string => {
    return date.toISOString().split('T')[0];
  };
  
  // Create task from email mutation
  const createTaskMutation = useMutation<any, Error, InsertTask>({
    mutationFn: async (taskData: InsertTask) => {
      try {
        // Use our enhanced apiRequest that handles empty responses better
        return await apiRequest("POST", "/api/tasks", taskData);
      } catch (error) {
        console.error("Task creation error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Success",
        description: "Email converted to task successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create task from email",
        variant: "destructive"
      });
    }
  });
  
  // Convert email to task - open modal with pre-filled data
  const handleConvertToTask = (messageId: number) => {
    const message = messages?.find((m: GmailMessage) => m.id === messageId);
    if (!message) return;
    
    // Extract content from email
    const title = message.subject || 'Email task';
    
    // Create a clean description by stripping HTML and limiting length
    let description = '';
    if (message.body) {
      // Strip HTML tags, CSS, and scripts
      let cleanText = message.body;
      
      // Remove style tags and their content
      cleanText = cleanText.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
      
      // Remove script tags and their content
      cleanText = cleanText.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
      
      // Remove HTML comments (including CSS in comments)
      cleanText = cleanText.replace(/<!--[\s\S]*?-->/g, '');
      
      // Create a temporary div to extract text content
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = cleanText;
      
      // Get text content and clean it up
      let textContent = (tempDiv.textContent || tempDiv.innerText || '').trim();
      
      // Remove excessive whitespace and line breaks
      textContent = textContent.replace(/\s+/g, ' ').trim();
      
      // Limit to 500 characters for readability
      description = textContent.substring(0, 500);
      if (textContent.length > 500) {
        description += '...';
      }
    } else {
      description = message.snippet || '';
    }
    
    const fromEmail = message.from || '';
    
    const today = new Date();
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 7);
    
    // Set task form data with email content
    setTaskFormData({
      title: title,
      description: description,
      status: "pending",
      priority: "Medium",
      startDate: formatDateForTask(today),
      dueDate: formatDateForTask(nextWeek),
      finishDate: formatDateForTask(nextWeek), // Add finishDate for backend validation
      assignedTo: user?.id,
      createdBy: user?.id,
      category: "Email"
    });
    
    // Save original email data for reference
    setEditEmailData({
      messageId,
      subject: title,
      body: description,
      from: fromEmail
    });
    
    // Open the edit modal
    setIsTaskModalOpen(true);
  };
  
  // Submit the edited task form
  const handleTaskFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!taskFormData) return;
    
    // Make sure we have a dueDate for finishDate value
    const dueDate = taskFormData.dueDate || new Date().toISOString().split('T')[0];
    
    // Create the final task data
    const taskData: InsertTask = {
      ...taskFormData as InsertTask,
      createdAt: new Date().toISOString(),
      description: taskFormData.description || '',
      title: taskFormData.title || 'Email task',
      // Set finishDate equal to dueDate for backend validation
      finishDate: dueDate,
      // Ensure dueDate is set if it wasn't already
      dueDate: dueDate,
    };
    
    // Submit the task
    createTaskMutation.mutate(taskData);
    
    // Close the modal
    setIsTaskModalOpen(false);
  };
  
  // Manual auth mutation
  const manualAuthMutation = useMutation<any, Error, string>({
    mutationFn: async (code: string) => {
      return await apiRequest("POST", "/api/gmail/manual-auth", { code });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Gmail account connected successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/status"] });
      setAuthCode("");
    },
    onError: (error: Error) => {
      toast({
        title: "Authentication Failed",
        description: error.message || "Failed to authenticate with Google. Please try again with a new code.",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsSubmittingCode(false); 
    }
  });

  // AI Email Analysis functions
  const analyzeEmail = async (messageId: number) => {
    if (isAnalyzing) return;
    
    setIsAnalyzing(true);
    try {
      const response = await apiRequest("POST", `/api/gmail/messages/${messageId}/analyze`);
      setAnalysisData(response);
      setShowAnalysis(true);
      toast({
        title: "Analysis Complete",
        description: "Email has been analyzed successfully!",
      });
    } catch (error) {
      console.error("Email analysis error:", error);
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to analyze email",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateReply = async (messageId: number, context?: string) => {
    if (isGeneratingReply) return;
    
    setIsGeneratingReply(true);
    try {
      const response = await apiRequest("POST", `/api/gmail/messages/${messageId}/generate-reply`, {
        context: context || ""
      });
      setReplyData(response);
      setShowReplyGeneration(true);
      toast({
        title: "Reply Generated",
        description: "AI reply suggestions have been generated!",
      });
    } catch (error) {
      console.error("Reply generation error:", error);
      toast({
        title: "Reply Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate reply",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingReply(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Reply has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard",
        variant: "destructive"
      });
    }
  };

  // Email compose functions
  const handleReply = () => {
    if (!selectedMessage) return;
    
    setComposeType('reply');
    setComposeTo(selectedMessage.from);
    setComposeCc('');
    setComposeSubject(`Re: ${selectedMessage.subject}`);
    setComposeBody('');
    setShowComposeDialog(true);
  };

  const handleReplyAll = () => {
    if (!selectedMessage) return;
    
    setComposeType('replyAll');
    setComposeTo(selectedMessage.from);
    setComposeCc(selectedMessage.to !== user?.email ? selectedMessage.to : '');
    setComposeSubject(`Re: ${selectedMessage.subject}`);
    setComposeBody('');
    setShowComposeDialog(true);
  };

  const handleForward = () => {
    if (!selectedMessage) return;
    
    setComposeType('forward');
    setComposeTo('');
    setComposeCc('');
    setComposeSubject(`Fwd: ${selectedMessage.subject}`);
    setComposeBody(`\n\n---------- Forwarded message ---------\nFrom: ${selectedMessage.from}\nDate: ${selectedMessage.receivedAt}\nSubject: ${selectedMessage.subject}\nTo: ${selectedMessage.to}\n\n${selectedMessage.body || selectedMessage.snippet}`);
    setShowComposeDialog(true);
  };

  const handleSendEmail = async () => {
    if (!composeTo.trim()) {
      toast({
        title: "Error",
        description: "Please enter a recipient",
        variant: "destructive"
      });
      return;
    }

    setIsSending(true);
    try {
      await apiRequest("POST", "/api/gmail/send", {
        to: composeTo,
        cc: composeCc,
        subject: composeSubject,
        body: composeBody,
        inReplyTo: composeType !== 'forward' ? selectedMessage?.messageId : undefined
      });

      toast({
        title: "Email Sent",
        description: "Your email has been sent successfully!",
      });

      setShowComposeDialog(false);
      setComposeTo('');
      setComposeCc('');
      setComposeSubject('');
      setComposeBody('');
    } catch (error) {
      console.error("Send email error:", error);
      toast({
        title: "Send Failed",
        description: error instanceof Error ? error.message : "Failed to send email",
        variant: "destructive"
      });
    } finally {
      setIsSending(false);
    }
  };

  // Bulk selection functions
  const handleSelectEmail = (emailId: number, checked: boolean) => {
    const newSelected = new Set(selectedEmails);
    if (checked) {
      newSelected.add(emailId);
    } else {
      newSelected.delete(emailId);
    }
    setSelectedEmails(newSelected);
    
    // Update select all state based on current selection
    const allVisible = messages?.map(m => m.id) || [];
    setSelectAll(allVisible.every(id => newSelected.has(id)));
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(messages?.map(m => m.id) || []);
      setSelectedEmails(allIds);
    } else {
      setSelectedEmails(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkDelete = async () => {
    if (selectedEmails.size === 0) return;
    
    setIsDeleting(true);
    let successCount = 0;
    let errorCount = 0;
    
    try {
      // Delete emails one by one
      for (const emailId of Array.from(selectedEmails)) {
        try {
          await apiRequest("DELETE", `/api/gmail/messages/${emailId}`);
          successCount++;
        } catch (error) {
          console.error(`Failed to delete email ${emailId}:`, error);
          errorCount++;
        }
      }
      
      // Clear selection
      setSelectedEmails(new Set());
      setSelectAll(false);
      
      // Refresh messages list
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
      
      // Show result toast
      if (errorCount === 0) {
        toast({
          title: "Success",
          description: `${successCount} email(s) deleted successfully`,
        });
      } else {
        toast({
          title: "Partial Success",
          description: `${successCount} email(s) deleted, ${errorCount} failed`,
          variant: "default"
        });
      }
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Failed to delete selected emails",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleBulkMarkAsRead = async () => {
    if (selectedEmails.size === 0) return;
    
    setIsBulkMarkingRead(true);
    let successCount = 0;
    let errorCount = 0;
    
    try {
      // Mark emails as read one by one
      for (const emailId of Array.from(selectedEmails)) {
        try {
          await apiRequest("PATCH", `/api/gmail/messages/${emailId}/read`, { isRead: true });
          successCount++;
        } catch (error) {
          console.error(`Failed to mark email ${emailId} as read:`, error);
          errorCount++;
        }
      }
      
      // Clear selection
      setSelectedEmails(new Set());
      setSelectAll(false);
      
      // Refresh messages list
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
      
      // Show result toast
      if (errorCount === 0) {
        toast({
          title: "Success",
          description: `${successCount} email(s) marked as read`,
        });
      } else {
        toast({
          title: "Partial Success",
          description: `${successCount} email(s) marked as read, ${errorCount} failed`,
          variant: "default"
        });
      }
    } catch (error) {
      toast({
        title: "Action Failed",
        description: "Failed to mark selected emails as read",
        variant: "destructive"
      });
    } finally {
      setIsBulkMarkingRead(false);
    }
  };

  const handleBulkMarkAsUnread = async () => {
    if (selectedEmails.size === 0) return;
    
    setIsBulkMarkingUnread(true);
    let successCount = 0;
    let errorCount = 0;
    
    try {
      // Mark emails as unread one by one
      for (const emailId of Array.from(selectedEmails)) {
        try {
          await apiRequest("PATCH", `/api/gmail/messages/${emailId}/read`, { isRead: false });
          successCount++;
        } catch (error) {
          console.error(`Failed to mark email ${emailId} as unread:`, error);
          errorCount++;
        }
      }
      
      // Clear selection
      setSelectedEmails(new Set());
      setSelectAll(false);
      
      // Refresh messages list
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
      
      // Show result toast
      if (errorCount === 0) {
        toast({
          title: "Success",
          description: `${successCount} email(s) marked as unread`,
        });
      } else {
        toast({
          title: "Partial Success",
          description: `${successCount} email(s) marked as unread, ${errorCount} failed`,
          variant: "default"
        });
      }
    } catch (error) {
      toast({
        title: "Action Failed",
        description: "Failed to mark selected emails as unread",
        variant: "destructive"
      });
    } finally {
      setIsBulkMarkingUnread(false);
    }
  };
  
  const connectToGmail = async () => {
    try {
      console.log("Initiating Gmail connection...");
      
      const response = await fetch("/api/gmail/auth-url", {
        method: "GET",
        credentials: "include",
      });
      
      const data = await response.json();
      console.log("Auth URL response:", data);
      
      if (data.url) {
        setAuthUrl(data.url);
        localStorage.setItem('gmailAuthAttempt', new Date().toISOString());
        
        const width = 600;
        const height = 700;
        const left = (window.screen.width - width) / 2;
        const top = (window.screen.height - height) / 2;
        
        const authWindow = window.open(
          data.url,
          'GmailAuth',
          `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no,location=yes,status=no,scrollbars=yes`
        );
        
        if (!authWindow) {
          toast({
            title: "Pop-up Blocked",
            description: "Please allow pop-ups for this site and try again.",
            variant: "destructive"
          });
          return;
        }
        
        toast({
          title: "Authorization Window Opened",
          description: "Complete the authorization in the popup window.",
        });
        
        const pollTimer = setInterval(() => {
          if (authWindow.closed) {
            clearInterval(pollTimer);
            console.log("OAuth popup closed, refreshing connection status...");
            setTimeout(() => {
              queryClient.invalidateQueries({ queryKey: ["/api/gmail/status"] });
              queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] });
            }, 1000);
          }
        }, 500);
      } else if (data.error) {
        console.error("OAuth configuration error:", data);
        toast({
          title: "OAuth Configuration Error",
          description: data.message || "Google OAuth is not properly configured on the server.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Gmail connection error:", error);
      if (error instanceof Error) {
        console.error("Error details:", error.message, error.stack);
      }
      
      toast({
        title: "Gmail Connection Error",
        description: error instanceof Error 
          ? `Error: ${error.message}` 
          : "Failed to generate authentication URL. Please try again later.",
        variant: "destructive"
      });
    }
  };
  
  // Extract clean code from a URL or raw code string
  const extractAuthCode = (input: string): string => {
    if (!input) return '';
    
    console.log('Processing auth code input, length:', input.length);
    input = input.trim();
    
    // Handle direct Google auth codes (they typically start with "4/0A" for OAuth 2.0)
    if (/^4\/0A[a-zA-Z0-9_-]+$/.test(input)) {
      console.log('Detected direct Google OAuth code format');
      return input;
    }
    
    // Handle full URLs with code parameter
    if (input.includes('https://') && input.includes('code=')) {
      try {
        console.log('Detected full URL with code parameter');
        const match = input.match(/[?&]code=([^&]+)/);
        if (match && match[1]) {
          console.log('Extracted code from URL parameter');
          return match[1];
        }
      } catch (err) {
        console.error('Error extracting code from URL:', err);
      }
    }
    // Handle code parameter fragment (code=xxxx)
    else if (input.startsWith('code=')) {
      try {
        console.log('Detected code parameter fragment');
        const parts = input.split('=');
        if (parts.length > 1) {
          return parts[1];
        }
      } catch (err) {
        console.error('Error extracting code from fragment:', err);
      }
    }
    // Handle JSON-like objects that might be copied from DevTools
    else if (input.includes('"code":')) {
      try {
        console.log('Detected JSON-like string with code property');
        const match = input.match(/"code"\s*:\s*"([^"]+)"/);
        if (match && match[1]) {
          console.log('Extracted code from JSON');
          return match[1];
        }
      } catch (err) {
        console.error('Error extracting code from JSON:', err);
      }
    }
    // Handle just the code extracted from a URL (if it matches the Google pattern)
    else if (/^[a-zA-Z0-9_-]+$/.test(input) && input.length >= 20) {
      console.log('Input appears to be a raw authorization code');
      return input;
    }
    
    // If we couldn't parse it as a special format, return as is
    console.log('No special format detected, using as-is');
    return input;
  };
  
  // Handle manual auth submission
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Clear any previous errors
    setManualAuthError(null);
    
    if (!authCode.trim()) {
      setManualAuthError("Please enter the authorization code or complete URL");
      toast({
        title: "Error",
        description: "Please enter the authorization code",
        variant: "destructive",
      });
      return;
    }
    
    // For direct code input (when it doesn't contain 'code=' but looks like a Google auth code)
    const isDirect4StyleCode = /^4\/0A[a-zA-Z0-9_-]+$/.test(authCode.trim());
    
    if (!isDirect4StyleCode && !authCode.includes('code=')) {
      setManualAuthError("Invalid authorization code format. Please enter either the code (starts with '4/0A...') or the complete callback URL.");
      toast({
        title: "Invalid Format",
        description: "Unrecognized authorization code format",
        variant: "destructive",
      });
      return;
    }
    
    // Process the code to ensure it's in the right format
    const cleanCode = extractAuthCode(authCode);
    console.log('Submitting cleaned auth code (first 10 chars):', cleanCode.substring(0, 10) + '...');
    
    if (cleanCode.length < 20) {
      setManualAuthError("The authorization code appears to be too short. Google authorization codes are typically longer.");
      toast({
        title: "Invalid Code",
        description: "Authorization code appears invalid",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmittingCode(true);
    manualAuthMutation.mutate(cleanCode);
  };

  // Disconnect from Gmail
  const disconnectMutation = useMutation<any, Error, void>({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/gmail/disconnect");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/status"] });
      toast({
        title: "Success",
        description: "Disconnected from Gmail successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to disconnect from Gmail",
        variant: "destructive"
      });
    }
  });
  
  // Update Gmail settings
  const updateSettingsMutation = useMutation<any, Error, { autoSyncEnabled?: boolean, syncFrequencyMinutes?: number }>({
    mutationFn: async (updateData: { autoSyncEnabled?: boolean, syncFrequencyMinutes?: number }) => {
      return await apiRequest("PATCH", "/api/gmail/settings", updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gmail/settings"] });
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive"
      });
    }
  });

  // Format date for display in Indian Standard Time (IST)
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Unknown date";
    try {
      // Convert to IST by adding 5 hours and 30 minutes to UTC
      const date = new Date(dateString);
      const istOffset = 5.5 * 60 * 60 * 1000; // 5.5 hours in milliseconds
      const istDate = new Date(date.getTime() + istOffset);
      return format(istDate, "MMM d, yyyy h:mm a") + " IST";
    } catch (e) {
      return dateString;
    }
  };

  // Handle view message
  // Track timeout for marking messages as read
  const [readTimeout, setReadTimeout] = useState<NodeJS.Timeout | null>(null);
  
  // Clean up timeout when component unmounts
  useEffect(() => {
    return () => {
      if (readTimeout) {
        clearTimeout(readTimeout);
      }
    };
  }, [readTimeout]);

  // Clean up progress polling interval on unmount
  useEffect(() => {
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, []);

  const handleViewMessage = (messageId: number) => {
    console.log(`Opening message ${messageId}`);
    setSelectedMessageId(messageId);
    
    // Clear AI reply suggestions when opening a new email
    setReplyData(null);
    setShowReplyGeneration(false);
    setAnalysisData(null);
    setShowAnalysis(false);
  };

  // Handle back button
  const handleBack = () => {
    // Clear any existing timeout when navigating away
    if (readTimeout) {
      clearTimeout(readTimeout);
      setReadTimeout(null);
    }
    
    // Clear AI suggestions when going back to inbox
    setReplyData(null);
    setShowReplyGeneration(false);
    setAnalysisData(null);
    setShowAnalysis(false);
    
    // Reset the selected message
    setSelectedMessageId(null);
  };

  // Handle toggle importance
  const handleToggleImportance = (messageId: number, currentImportance: boolean | null) => {
    toggleImportanceMutation.mutate({
      messageId,
      important: !(currentImportance === true)
    });
  };

  if (isLoadingStatus) {
    return (
      <div className="flex items-center justify-center h-64">
        <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!connectionStatus?.connected) {
    return (
      <Card className="shadow-lg">
        <CardHeader className="text-center pb-0">
          <div className="mx-auto rounded-full bg-primary/10 p-4 w-16 h-16 flex items-center justify-center mb-3">
            <Mail className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-red-600 text-transparent bg-clip-text">
            Connect to Gmail
          </CardTitle>
          <CardDescription className="text-base max-w-md mx-auto mt-2">
            Connect your Gmail account to view and manage THERMOPAC emails directly in this dashboard.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-8 text-center">
          <div className="space-y-6 mx-auto max-w-md">
            {/* Manual Connect Mode */}
            <>
                <div className="text-left mb-6">
                  <h3 className="text-lg font-medium mb-2">Gmail Authentication</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Follow these steps carefully to connect your Gmail account:
                  </p>
                  <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-yellow-700 font-medium">
                          IMPORTANT: You must complete these steps in order and act quickly!
                        </p>
                        <p className="text-xs text-yellow-600 mt-1">
                          Authorization codes expire after just a few minutes.
                        </p>
                      </div>
                    </div>
                  </div>
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li><strong>Step 1:</strong> Click the "Open Google Authorization Page" button below - this will open a new tab.</li>
                    <li><strong>Step 2:</strong> In the new tab, sign in to your Google account and grant the requested permissions.</li>
                    <li><strong>Step 3:</strong> After approval, you'll be redirected to a page that might show an error - this is expected.</li>
                    <li><strong>Step 4:</strong> <span className="font-bold text-primary">Immediately copy the COMPLETE URL</span> from your browser's address bar. It should look like:</li>
                    <li className="ml-5 list-none text-xs mt-2 mb-2">
                      <div className="bg-muted p-2 rounded-md font-mono text-[11px] break-all">
                        https://thermopac-communication-thermopacllp.replit.app/auth/google/callback?code=4/0AbCD...EfGhI&scope=email+https://www.googleapis.com/auth/gmail.modify
                      </div>
                    </li>
                    <li><strong>Step 5:</strong> Return to this tab immediately and paste the entire URL in the field below.</li>
                    <li><strong>Step 6:</strong> Click "Connect Account" right away - don't wait!</li>
                  </ol>
                  
                  <div className="mt-4 bg-red-50 border-l-4 border-red-400 p-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertCircle className="h-5 w-5 text-red-500" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-red-700 font-medium">Common reasons for failure:</p>
                        <ul className="text-xs text-red-600 mt-1 list-disc list-inside">
                          <li>Waiting too long between authorization and pasting the code (they expire quickly)</li>
                          <li>Not copying the complete URL (must include everything with "code=" parameter)</li>
                          <li>Using an old URL from a previous authorization attempt</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 bg-blue-50 border-l-4 border-blue-500 p-4">
                    <p className="text-sm text-blue-700">
                      <strong>Note:</strong> You might see "This site can't be reached" or another error page after Google authorization - that's completely normal! Just copy the full URL from your browser's address bar.
                    </p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <Button 
                    onClick={connectToGmail} 
                    className="w-full mb-4"
                    variant="outline"
                  >
                    Open Google Authorization Page
                  </Button>
                  
                  {authUrl && (
                    <div className="text-xs text-left mt-2 overflow-hidden">
                      <p className="font-medium mb-1">Or copy this URL manually:</p>
                      <div className="bg-secondary p-2 rounded overflow-x-auto whitespace-normal break-all">
                        {authUrl}
                      </div>
                    </div>
                  )}
                </div>
                
                <form onSubmit={handleManualSubmit}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="authCode">Paste the Authorization Code or Complete URL</Label>
                      <Input
                        id="authCode"
                        value={authCode}
                        onChange={(e) => setAuthCode(e.target.value)}
                        placeholder="4/0AbCD...EfGhI or the full callback URL..."
                        className="font-mono text-xs"
                      />
                      <div className="text-xs text-muted-foreground mt-1">
                        <p className="mb-1">You can paste either:</p>
                        <ul className="list-disc list-inside space-y-1">
                          <li>Just the authorization code (starts with "4/0A...")</li>
                          <li>OR the complete URL from your browser after authorization</li>
                        </ul>
                      </div>
                      
                      {manualAuthError && (
                        <div className="mt-2 bg-red-50 border-l-4 border-red-400 p-3 text-red-800 text-xs">
                          <div className="flex">
                            <AlertCircle className="h-4 w-4 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                            <p>{manualAuthError}</p>
                          </div>
                        </div>
                      )}
                      
                      {manualAuthMutation.error && (
                        <div className="mt-2 bg-red-50 border-l-4 border-red-400 p-3 text-red-800 text-xs">
                          <div className="flex">
                            <AlertCircle className="h-4 w-4 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                            <p>Authentication failed: {(manualAuthMutation.error as any)?.message || "The authorization code was invalid or expired. Please try again with a fresh code."}</p>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex justify-end">
                      <Button 
                        type="submit" 
                        disabled={isSubmittingCode || manualAuthMutation.isPending || !authCode.trim()}
                        className="bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-700 hover:to-red-700"
                      >
                        {manualAuthMutation.isPending ? "Connecting..." : "Connect Account"}
                      </Button>
                    </div>
                  </div>
                </form>
              </>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate unread count
  const unreadCount = messages?.filter((m: GmailMessage) => !m.isRead).length || 0;
  const totalCount = messages?.length || 0;
  
  return (
    <div className="space-y-4">
      {/* Email Count Stats */}
      {messages && messages.length > 0 && !selectedMessageId && (
        <div className="flex justify-between bg-muted p-3 rounded-md text-sm">
          <div className="flex gap-4">
            <div>
              <span className="font-semibold">Total:</span> {totalCount}
            </div>
            <div>
              <span className="font-semibold text-amber-600">Unread:</span> {unreadCount}
            </div>
            <div>
              <span className="font-semibold text-green-600">Read:</span> {totalCount - unreadCount}
            </div>
          </div>
          <div className="text-muted-foreground">
            Last synced: {connectionStatus?.lastSyncTime ? formatDate(new Date(connectionStatus.lastSyncTime).toString()) : "Never"}
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2">
              <Trash className="h-5 w-5" /> Delete Email Message
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this email? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-3">
            {messageToDelete && messages ? (
              <div className="bg-muted p-3 rounded-md">
                <p className="font-semibold">Subject:</p>
                <p className="text-sm mb-2">{messages.find((m: GmailMessage) => m.id === messageToDelete)?.subject || 'No Subject'}</p>
                <p className="font-semibold">From:</p>
                <p className="text-sm">{messages.find((m: GmailMessage) => m.id === messageToDelete)?.from || 'Unknown Sender'}</p>
              </div>
            ) : null}
          </div>
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={confirmDeleteMessage}
              disabled={deleteMessageMutation.isPending}
              className="gap-2"
            >
              {deleteMessageMutation.isPending ? (
                <>
                  <RotateCw className="h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash className="h-4 w-4" />
                  Delete Email
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Task Creation Modal */}
      <Dialog open={isTaskModalOpen} onOpenChange={setIsTaskModalOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Task from Email</DialogTitle>
            <DialogDescription>
              Convert this email into a task. Edit any fields as needed before creating the task.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleTaskFormSubmit} className="space-y-4 pt-2">
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Task Title</Label>
                <Input 
                  id="title" 
                  value={taskFormData.title || ''} 
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTaskFormData({...taskFormData, title: e.target.value})}
                  placeholder="Enter task title"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Task Description</Label>
                <Textarea 
                  id="description" 
                  value={taskFormData.description || ''} 
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTaskFormData({...taskFormData, description: e.target.value})}
                  placeholder="Enter task description"
                  className="min-h-[100px]"
                />
                {editEmailData.from && (
                  <div className="text-xs text-muted-foreground mt-1">
                    <span className="font-medium">From: </span>{editEmailData.from}
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select 
                    value={taskFormData.priority || 'Medium'} 
                    onValueChange={(value) => setTaskFormData({...taskFormData, priority: value as 'Low' | 'Medium' | 'High'})}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={taskFormData.status || 'pending'} 
                    onValueChange={(value) => setTaskFormData({...taskFormData, status: value})}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input 
                    id="startDate" 
                    type="date" 
                    value={taskFormData.startDate || ''} 
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTaskFormData({...taskFormData, startDate: e.target.value})}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input 
                    id="dueDate" 
                    type="date" 
                    value={taskFormData.dueDate || ''} 
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTaskFormData({...taskFormData, dueDate: e.target.value})}
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="assignedTo">Assign To</Label>
                <Select 
                  value={taskFormData.assignedTo?.toString() || user?.id?.toString() || ''} 
                  onValueChange={(value) => setTaskFormData({...taskFormData, assignedTo: parseInt(value)})}
                >
                  <SelectTrigger id="assignedTo">
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(groupedUsers).map(([role, roleUsers]) => (
                      <SelectGroup key={role}>
                        <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">
                          {role}s
                        </SelectLabel>
                        {roleUsers.map((u) => (
                          <SelectItem key={u.id} value={u.id.toString()}>
                            {u.username}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsTaskModalOpen(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-700 hover:to-red-700"
                disabled={createTaskMutation.isPending}
              >
                {createTaskMutation.isPending ? 'Creating Task...' : 'Create Task'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Compose Email Dialog */}
      <Dialog open={showComposeDialog} onOpenChange={setShowComposeDialog}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {composeType === 'reply' && 'Reply to Email'}
              {composeType === 'replyAll' && 'Reply to All'}
              {composeType === 'forward' && 'Forward Email'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="compose-to">To</Label>
              <Input
                id="compose-to"
                value={composeTo}
                onChange={(e) => setComposeTo(e.target.value)}
                placeholder="recipient@example.com"
                data-testid="input-compose-to"
              />
            </div>
            
            {composeType === 'replyAll' && (
              <div>
                <Label htmlFor="compose-cc">Cc</Label>
                <Input
                  id="compose-cc"
                  value={composeCc}
                  onChange={(e) => setComposeCc(e.target.value)}
                  placeholder="cc@example.com"
                  data-testid="input-compose-cc"
                />
              </div>
            )}
            
            <div>
              <Label htmlFor="compose-subject">Subject</Label>
              <Input
                id="compose-subject"
                value={composeSubject}
                onChange={(e) => setComposeSubject(e.target.value)}
                placeholder="Email subject"
                data-testid="input-compose-subject"
              />
            </div>
            
            {/* AI Generate Reply Section - Only for Reply and Reply All */}
            {(composeType === 'reply' || composeType === 'replyAll') && (
              <div className="border rounded-lg p-4 bg-muted/30">
                <div className="flex items-center justify-between mb-3">
                  <Label className="text-sm font-semibold flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-blue-600" />
                    AI Reply Generator
                  </Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (selectedMessage) {
                        generateReply(selectedMessage.id);
                      }
                    }}
                    disabled={isGeneratingReply}
                    data-testid="button-generate-reply-in-dialog"
                  >
                    {isGeneratingReply ? (
                      <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <MessageSquare className="h-4 w-4 mr-2 text-green-600" />
                    )}
                    {isGeneratingReply ? 'Generating...' : 'Generate Reply'}
                  </Button>
                </div>
                
                {replyData && (
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant={selectedReplyStyle === 'professional' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedReplyStyle('professional')}
                        data-testid="button-style-professional"
                      >
                        Professional
                      </Button>
                      <Button
                        type="button"
                        variant={selectedReplyStyle === 'brief' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedReplyStyle('brief')}
                        data-testid="button-style-brief"
                      >
                        Brief
                      </Button>
                      <Button
                        type="button"
                        variant={selectedReplyStyle === 'detailed' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedReplyStyle('detailed')}
                        data-testid="button-style-detailed"
                      >
                        Detailed
                      </Button>
                    </div>
                    
                    <div className="bg-background border rounded p-3 text-sm whitespace-pre-wrap">
                      {replyData[selectedReplyStyle] || 'No reply available for this style.'}
                    </div>
                    
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() => setComposeBody(replyData[selectedReplyStyle] || '')}
                      className="w-full"
                      data-testid="button-use-reply"
                    >
                      Use This Reply
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            <div>
              <Label htmlFor="compose-body">Message</Label>
              <Textarea
                id="compose-body"
                value={composeBody}
                onChange={(e) => setComposeBody(e.target.value)}
                placeholder="Type your message here..."
                className="min-h-[200px]"
                data-testid="textarea-compose-body"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setShowComposeDialog(false)}
              data-testid="button-compose-cancel"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSendEmail}
              disabled={isSending}
              data-testid="button-compose-send"
            >
              {isSending ? 'Sending...' : 'Send'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Messages</h2>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending || syncProgress?.status === 'running'}
            >
              <RotateCw className={`h-4 w-4 mr-2 ${(syncMutation.isPending || syncProgress?.status === 'running') ? 'animate-spin' : ''}`} />
              Sync
            </Button>
            {syncProgress?.status === 'running' && syncProgress.total > 0 && (
              <span className="text-xs text-muted-foreground">
                {syncProgress.processed}/{syncProgress.total} ({Math.round((syncProgress.processed / syncProgress.total) * 100)}%)
              </span>
            )}
          </div>
          <Button variant="outline" size="sm" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/gmail/settings"] })}>
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {showFilters && (
        <Card className="mb-4">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="search">Search</Label>
                <Input
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by subject or sender..."
                />
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="read">Read</SelectItem>
                    <SelectItem value="unread">Unread</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select value={filterPriority} onValueChange={setFilterPriority}>
                  <SelectTrigger id="priority">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="critical">P0 - Critical</SelectItem>
                    <SelectItem value="high">P0 + P1 - High Priority (Default)</SelectItem>
                    <SelectItem value="normal">P2 - Normal</SelectItem>
                    <SelectItem value="low">P3 - Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="inbox">Inbox</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inbox" className="mt-4">
          {selectedMessageId ? (
            <Card className="mb-4">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <Button variant="ghost" size="sm" onClick={handleBack}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back
                    </Button>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (selectedMessage) {
                          handleToggleImportance(selectedMessage.id, selectedMessage.isImportant);
                        }
                      }}
                    >
                      <Star 
                        className={`h-4 w-4 ${selectedMessage?.isImportant ? 'fill-yellow-400 text-yellow-400' : ''}`} 
                      />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (selectedMessage) {
                          handleConvertToTask(selectedMessage.id);
                        }
                      }}
                    >
                      <FolderCheck className="h-4 w-4 mr-2 text-primary" />
                      Convert to Task
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (selectedMessage) {
                          analyzeEmail(selectedMessage.id);
                        }
                      }}
                      disabled={isAnalyzing}
                    >
                      {isAnalyzing ? (
                        <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Brain className="h-4 w-4 mr-2 text-blue-600" />
                      )}
                      {isAnalyzing ? 'Analyzing...' : 'AI Analyze'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (selectedMessage) {
                          generateReply(selectedMessage.id);
                        }
                      }}
                      disabled={isGeneratingReply}
                    >
                      {isGeneratingReply ? (
                        <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <MessageSquare className="h-4 w-4 mr-2 text-green-600" />
                      )}
                      {isGeneratingReply ? 'Generating...' : 'Generate Reply'}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (selectedMessage) {
                          handleDeleteMessage(selectedMessage.id);
                        }
                      }}
                    >
                      <Trash className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <CardTitle className="flex items-center gap-3">
                  {selectedMessage?.subject || 'No Subject'}
                  {(selectedMessage as any)?.priority && (
                    <Badge className={`text-xs px-2 py-1 border ${getPriorityBadgeStyle((selectedMessage as any).priority)}`}>
                      {(selectedMessage as any).priority} - {getPriorityLabel((selectedMessage as any).priority)}
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex justify-between text-sm text-muted-foreground mt-2">
                  <div>
                    <div><strong>From:</strong> {selectedMessage?.from}</div>
                    <div><strong>To:</strong> {selectedMessage?.to}</div>
                    {(selectedMessage as any)?.classificationReason && (
                      <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-800">
                        <strong>🤖 AI Classification:</strong> {(selectedMessage as any).classificationReason}
                      </div>
                    )}
                  </div>
                  <div>
                    {selectedMessage?.receivedAt && formatDate(selectedMessage.receivedAt.toString())}
                  </div>
                </div>
              </CardHeader>
              <Separator />
              <CardContent className="pt-6">
                <div 
                  className="prose max-w-none" 
                  dangerouslySetInnerHTML={{ __html: selectedMessage?.body || selectedMessage?.snippet || 'No content' }} 
                />
              </CardContent>
              
              {/* Email Action Buttons */}
              <CardContent className="pb-6">
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    size="lg"
                    className="rounded-full px-6"
                    onClick={handleReplyAll}
                    data-testid="button-reply-all"
                  >
                    <ReplyAll className="h-4 w-4 mr-2" />
                    Reply to all
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="rounded-full px-6"
                    onClick={handleReply}
                    data-testid="button-reply"
                  >
                    <Reply className="h-4 w-4 mr-2" />
                    Reply
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="rounded-full px-6"
                    onClick={handleForward}
                    data-testid="button-forward"
                  >
                    <Forward className="h-4 w-4 mr-2" />
                    Forward
                  </Button>
                </div>
              </CardContent>
              
              {/* AI Analysis Results */}
              {showAnalysis && analysisData && (
                <>
                  <Separator />
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="h-5 w-5 text-blue-600" />
                      <h3 className="text-lg font-semibold">AI Analysis</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowAnalysis(false)}
                        className="ml-auto"
                      >
                        ✕
                      </Button>
                    </div>
                    
                    <div className="space-y-4">
                      {/* Summary */}
                      <div>
                        <h4 className="font-medium text-sm text-muted-foreground mb-2">SUMMARY</h4>
                        <p className="text-sm">{analysisData.summary}</p>
                      </div>
                      
                      {/* Key Points */}
                      <div>
                        <h4 className="font-medium text-sm text-muted-foreground mb-2">KEY POINTS</h4>
                        <ul className="text-sm space-y-1">
                          {analysisData.keyPoints?.map((point: string, index: number) => (
                            <li key={index} className="flex items-start gap-2">
                              <span className="text-blue-600 mt-1">•</span>
                              <span>{point}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {/* Urgency and Category */}
                      <div className="flex gap-4">
                        <div>
                          <h4 className="font-medium text-sm text-muted-foreground mb-2">URGENCY</h4>
                          <Badge 
                            variant={analysisData.urgency === 'High' ? 'destructive' : 
                                    analysisData.urgency === 'Medium' ? 'default' : 'secondary'}
                          >
                            {analysisData.urgency}
                          </Badge>
                        </div>
                        <div>
                          <h4 className="font-medium text-sm text-muted-foreground mb-2">CATEGORY</h4>
                          <Badge variant="outline">{analysisData.category}</Badge>
                        </div>
                        <div>
                          <h4 className="font-medium text-sm text-muted-foreground mb-2">SENTIMENT</h4>
                          <Badge 
                            variant={analysisData.sentiment === 'Positive' ? 'default' : 
                                    analysisData.sentiment === 'Negative' ? 'destructive' : 'secondary'}
                          >
                            {analysisData.sentiment}
                          </Badge>
                        </div>
                      </div>
                      
                      {/* Action Items */}
                      {analysisData.actionItems && analysisData.actionItems.length > 0 && (
                        <div>
                          <h4 className="font-medium text-sm text-muted-foreground mb-2">ACTION ITEMS</h4>
                          <ul className="text-sm space-y-1">
                            {analysisData.actionItems.map((item: string, index: number) => (
                              <li key={index} className="flex items-start gap-2">
                                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </>
              )}
              
              {/* Reply Generation Results */}
              {showReplyGeneration && replyData && (
                <>
                  <Separator />
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <MessageSquare className="h-5 w-5 text-green-600" />
                      <h3 className="text-lg font-semibold">AI Reply Suggestions</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowReplyGeneration(false)}
                        className="ml-auto"
                      >
                        ✕
                      </Button>
                    </div>
                    
                    <div className="space-y-4">
                      {/* Reply Style Selector */}
                      <div>
                        <h4 className="font-medium text-sm text-muted-foreground mb-2">REPLY STYLE</h4>
                        <div className="flex gap-2">
                          <Button
                            variant={selectedReplyStyle === 'professional' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedReplyStyle('professional')}
                          >
                            Professional
                          </Button>
                          <Button
                            variant={selectedReplyStyle === 'brief' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedReplyStyle('brief')}
                          >
                            Brief
                          </Button>
                          <Button
                            variant={selectedReplyStyle === 'detailed' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedReplyStyle('detailed')}
                          >
                            Detailed
                          </Button>
                        </div>
                      </div>
                      
                      {/* Reply Content */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-sm text-muted-foreground">
                            {selectedReplyStyle.toUpperCase()} REPLY
                          </h4>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(replyData[selectedReplyStyle] || '')}
                          >
                            <Copy className="h-4 w-4 mr-2" />
                            Copy
                          </Button>
                        </div>
                        <div className="bg-muted p-4 rounded-lg text-sm whitespace-pre-wrap">
                          {replyData[selectedReplyStyle] || 'No reply available for this style.'}
                        </div>
                      </div>
                      
                      {replyData.context && (
                        <div>
                          <h4 className="font-medium text-sm text-muted-foreground mb-2">CONTEXT USED</h4>
                          <p className="text-xs text-muted-foreground">{replyData.context}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </>
              )}
            </Card>
          ) : (
            <div>
              {isLoadingMessages ? (
                <div className="flex items-center justify-center h-64">
                  <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : messagesError ? (
                <Card className="p-6 text-center">
                  <div className="bg-red-50 p-4 rounded-lg mb-4">
                    <Mail className="h-6 w-6 text-red-600 mx-auto mb-2" />
                    <p className="text-red-700 font-medium">Gmail Connection Error</p>
                    <p className="text-sm text-red-600 mt-1">
                      {messagesError instanceof Error 
                        ? messagesError.message.includes("failed to fetch") 
                          ? "Connection to Gmail failed. Your authentication may have expired." 
                          : messagesError.message.includes("401")
                            ? "Your Gmail authorization has expired."
                            : messagesError.message
                        : "Unknown error"}
                    </p>
                    <div className="mt-2 text-xs text-red-600">
                      {messagesError instanceof Error && (
                        messagesError.message.includes("401") 
                          ? <p>Please disconnect and reconnect your account using the buttons below.</p>
                          : messagesError.message.includes("redirect_uri_mismatch")
                            ? <p>There's a mismatch between the redirect URI configured in Google Cloud Console and this application.</p>
                            : null
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 justify-center">
                    <Button 
                      onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/gmail/messages"] })}
                      variant="outline"
                    >
                      Try Again
                    </Button>
                    <Button 
                      onClick={() => disconnectMutation.mutate()}
                      variant="outline"
                    >
                      Disconnect
                    </Button>
                  </div>
                  <div className="mt-4">
                    <p className="text-xs text-blue-600 mb-2">Note: All inbox emails will be synced and classified by AI</p>
                    <Button 
                      onClick={() => syncMutation.mutate()}
                      disabled={syncMutation.isPending}
                      className="w-full"
                    >
                      <RotateCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                      Sync Messages
                    </Button>
                  </div>
                </Card>
              ) : messages && messages.length > 0 ? (
                <div className="space-y-2">
                  {/* Bulk selection header */}
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        id="select-all"
                        checked={selectAll}
                        onCheckedChange={(checked) => handleSelectAll(checked as boolean)}
                        data-testid="checkbox-select-all"
                      />
                      <Label htmlFor="select-all" className="text-sm font-medium">
                        Select All ({messages.length} emails)
                      </Label>
                    </div>
                    {selectedEmails.size > 0 && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {selectedEmails.size} selected
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleBulkMarkAsUnread}
                          disabled={isBulkMarkingUnread}
                          data-testid="button-bulk-mark-unread"
                        >
                          {isBulkMarkingUnread ? (
                            <>
                              <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                              Marking...
                            </>
                          ) : (
                            <>
                              <Mail className="h-4 w-4 mr-2" />
                              Mark as Unread
                            </>
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleBulkMarkAsRead}
                          disabled={isBulkMarkingRead}
                          data-testid="button-bulk-mark-read"
                        >
                          {isBulkMarkingRead ? (
                            <>
                              <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                              Marking...
                            </>
                          ) : (
                            <>
                              <MailOpen className="h-4 w-4 mr-2" />
                              Mark as Read
                            </>
                          )}
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={handleBulkDelete}
                          disabled={isDeleting}
                          data-testid="button-bulk-delete"
                        >
                          {isDeleting ? (
                            <>
                              <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                              Deleting...
                            </>
                          ) : (
                            <>
                              <Trash className="h-4 w-4 mr-2" />
                              Delete Selected
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {messages.map((message: GmailMessage) => (
                    <Card 
                      key={message.id}
                      className={`group hover:bg-accent/50 cursor-pointer transition-colors ${!message.isRead ? 'border-l-4 border-l-primary' : ''} ${selectedEmails.has(message.id) ? 'ring-2 ring-primary' : ''}`}
                      onClick={() => handleViewMessage(message.id)}
                    >
                      <CardHeader className="p-4">
                        <div className="flex justify-between">
                          <div className="flex items-start space-x-2">
                            <Checkbox
                              checked={selectedEmails.has(message.id)}
                              onCheckedChange={(checked) => handleSelectEmail(message.id, checked as boolean)}
                              onClick={(e) => e.stopPropagation()}
                              className="mt-1"
                              data-testid={`checkbox-email-${message.id}`}
                            />
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              className="h-6 w-6 p-0 rounded-full mt-1 mr-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                console.log(`Button clicked for message ${message.id}, current isRead: ${message.isRead}`);
                                // Directly toggle the read status
                                markAsReadMutation.mutate({ 
                                  messageId: message.id, 
                                  isRead: !message.isRead 
                                });
                              }}
                            >
                              <div className="flex items-center justify-center">
                                {message.isRead ? (
                                  <div className="h-4 w-4 rounded border border-primary bg-primary"></div>
                                ) : (
                                  <div className="h-4 w-4 rounded border border-primary"></div>
                                )}
                              </div>
                            </Button>
                            {message.isRead ? (
                              <MailOpen className="h-5 w-5 text-muted-foreground mt-1" />
                            ) : (
                              <Mail className="h-5 w-5 text-primary mt-1" />
                            )}
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {message.from}
                                {(message as any).priority && (
                                  <Badge className={`text-xs px-2 py-0 border ${getPriorityBadgeStyle((message as any).priority)}`}>
                                    {(message as any).priority} - {getPriorityLabel((message as any).priority)}
                                  </Badge>
                                )}
                                {message.isImportant && (
                                  <Star className="h-4 w-4 inline-block fill-yellow-400 text-yellow-400" />
                                )}
                              </div>
                              <div className="font-bold">{message.subject || 'No Subject'}</div>
                              <div className="text-sm text-muted-foreground line-clamp-1">
                                {message.snippet || 'No preview available'}
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <div className="text-xs text-muted-foreground whitespace-nowrap">
                              {message.receivedAt && formatDate(message.receivedAt.toString())}
                            </div>
                            
                            {/* One-tap action shortcuts - only visible on hover */}
                            <div className="hidden group-hover:flex items-center gap-1 mt-2 transition-all duration-150">
                              {/* Delete shortcut */}
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 p-0 rounded-full hover:bg-red-100"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  e.preventDefault();
                                  console.log(`Delete button clicked for message ${message.id}`);
                                  setMessageToDelete(message.id);
                                  setIsDeleteDialogOpen(true);
                                }}
                                title="Delete email"
                              >
                                <Trash className="h-4 w-4 text-red-600" />
                              </Button>
                              
                              {/* Star/Unstar shortcut */}
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 p-0 rounded-full hover:bg-amber-100"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  e.preventDefault();
                                  console.log(`Star button clicked for message ${message.id}`);
                                  handleToggleImportance(message.id, message.isImportant);
                                }}
                                title={message.isImportant ? "Unstar email" : "Star email"}
                              >
                                {message.isImportant ? (
                                  <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
                                ) : (
                                  <Star className="h-4 w-4 text-amber-400" />
                                )}
                              </Button>
                              
                              {/* Convert to Task shortcut */}
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost" 
                                className="h-7 w-7 p-0 rounded-full hover:bg-blue-100"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  e.preventDefault();
                                  console.log(`Convert to task button clicked for message ${message.id}`);
                                  handleConvertToTask(message.id);
                                }}
                                title="Create task from email"
                              >
                                <FolderCheck className="h-4 w-4 text-blue-600" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-6 text-center">
                  <Mail className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium mb-2">No messages found</p>
                  <p className="text-sm text-muted-foreground mb-2">
                    {connectionStatus?.connected
                      ? "Your inbox is empty or no messages match your filters"
                      : "Connect your Gmail account to view messages"}
                  </p>
                  <p className="text-xs text-blue-600 mb-3">Note: All inbox emails will be synced and classified by AI</p>
                  <Button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending}>
                    <RotateCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                    Sync Messages
                  </Button>
                </Card>
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="settings" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Gmail Settings</CardTitle>
              <CardDescription>
                Configure your Gmail integration settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {settings ? (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Auto-sync important messages</h3>
                        <p className="text-sm text-muted-foreground">
                          Automatically sync messages marked as IMPORTANT from Gmail periodically
                        </p>
                      </div>
                      <Switch 
                        checked={settings.autoSyncEnabled || false}
                        onCheckedChange={(checked: boolean) => {
                          updateSettingsMutation.mutate({
                            autoSyncEnabled: checked
                          });
                        }}
                      />
                    </div>
                  </div>
                  
                  {settings.autoSyncEnabled && (
                    <div className="space-y-2">
                      <h3 className="font-medium">Sync frequency</h3>
                      <p className="text-sm text-muted-foreground">
                        How often to sync messages from Gmail
                      </p>
                      <Select 
                        value={settings.syncFrequencyMinutes.toString()}
                        onValueChange={(value) => {
                          updateSettingsMutation.mutate({
                            syncFrequencyMinutes: parseInt(value)
                          });
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">Every 5 minutes</SelectItem>
                          <SelectItem value="15">Every 15 minutes</SelectItem>
                          <SelectItem value="30">Every 30 minutes</SelectItem>
                          <SelectItem value="60">Every hour</SelectItem>
                          <SelectItem value="120">Every 2 hours</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <h3 className="font-medium">Connection Status</h3>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Connected
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Last synced: {settings?.lastSyncedAt ? formatDate(settings.lastSyncedAt.toString()) : "Never"}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Connected account: <span className="font-medium">{user?.email || settings?.gmailUserEmail || "Unknown"}</span>
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-medium">Account Actions</h3>
                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => syncMutation.mutate()}
                        disabled={syncMutation.isPending}
                        title="All inbox emails will be synced and classified by AI"
                      >
                        <RotateCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                        Sync Now
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => disconnectMutation.mutate()}
                      >
                        Disconnect Gmail
                      </Button>
                    </div>
                  </div>
                </>
              ) : isLoadingSettings ? (
                <div className="flex items-center justify-center h-32">
                  <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">
                    Could not load settings. Please try again.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/gmail/settings"] })}
                    className="mt-2"
                  >
                    Retry
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}