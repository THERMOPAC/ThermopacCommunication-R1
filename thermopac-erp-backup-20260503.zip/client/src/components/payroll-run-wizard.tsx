import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Play, CheckCircle2, AlertTriangle,
  RotateCcw, Loader2,
  FileCheck, Users, Calculator, Award, Receipt, ShieldCheck, Send, XCircle, RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface PayrollPeriod {
  id: number;
  periodName: string;
  startDate: string;
  endDate: string;
  payDate: string;
  status: string;
  currentRunNumber: number;
  finalizedRunNumber: number | null;
  isLocked: boolean;
  totalEmployees: number;
  totalGrossPay: string;
  totalDeductions: string;
  totalNetPay: string;
}

const STEP_CONFIG = [
  { key: 'attendance_snapshot', label: 'Attendance Snapshot', icon: Users, description: 'Freeze attendance data for the period' },
  { key: 'leave_consolidation', label: 'Leave Consolidation', icon: FileCheck, description: 'Apply paid/unpaid leave adjustments' },
  { key: 'salary_calculation', label: 'Salary Calculation', icon: Calculator, description: 'Calculate prorated salaries and allowances' },
  { key: 'bonus_calculation', label: 'Bonus Calculation', icon: Award, description: 'Apply KPI-based bonuses from DWAR' },
  { key: 'deduction_calculation', label: 'Deduction Calculation', icon: Receipt, description: 'Apply statutory and other deductions' },
  { key: 'tds_calculation', label: 'TDS / Income Tax', icon: Receipt, description: 'Compute monthly TDS based on projected annual tax' },
] as const;

const STATUS_COLORS: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-800',
  processing: 'bg-blue-100 text-blue-800',
  processed: 'bg-indigo-100 text-indigo-800',
  reviewed: 'bg-purple-100 text-purple-800',
  approved: 'bg-green-100 text-green-800',
  paid: 'bg-emerald-100 text-emerald-800',
  locked: 'bg-red-100 text-red-800',
};

export function PayrollRunWizard({ period }: { period: PayrollPeriod }) {
  const { toast } = useToast();
  const [runNumber, setRunNumber] = useState(period.currentRunNumber || 0);
  const [currentStep, setCurrentStep] = useState(0);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [resetReason, setResetReason] = useState('');
  const [includeNonSystem, setIncludeNonSystem] = useState(true);
  const [isRunningAll, setIsRunningAll] = useState(false);
  const [runAllProgress, setRunAllProgress] = useState('');

  const { data: runLog = [] } = useQuery<any[]>({
    queryKey: ['/api/payroll/run/log', period.id, runNumber],
    queryFn: async () => {
      return await apiRequest('GET', `/api/payroll/run/log/${period.id}?runNumber=${runNumber}`);
    },
    enabled: runNumber > 0,
  });

  const startRunMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/payroll/run/start', { periodId: period.id });
    },
    onSuccess: (data: any) => {
      setRunNumber(data.runNumber);
      setCurrentStep(0);
      toast({ title: 'Payroll run started', description: `Run #${data.runNumber} initiated` });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/run/log'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-periods'] });
    },
    onError: (err: any) => {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    },
  });

  const executeStepMutation = useMutation({
    mutationFn: async (step: string) => {
      return await apiRequest('POST', '/api/payroll/run/step', {
        periodId: period.id,
        runNumber,
        step,
        includeNonSystem,
      });
    },
    onSuccess: (data: any, step) => {
      const stepLabel = STEP_CONFIG.find(s => s.key === step)?.label || step;
      toast({
        title: `${stepLabel} completed`,
        description: `${data.employeesProcessed} processed, ${data.errorCount} errors`,
      });
      setCurrentStep(prev => Math.min(prev + 1, STEP_CONFIG.length - 1));
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/run/log'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-periods'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-records'] });
    },
    onError: (err: any) => {
      toast({ title: 'Step failed', description: err.message, variant: 'destructive' });
    },
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/payroll/run/reset', {
        periodId: period.id,
        reason: resetReason,
      });
    },
    onSuccess: (data: any) => {
      setRunNumber(data.newRunNumber);
      setCurrentStep(0);
      setShowResetDialog(false);
      setResetReason('');
      toast({ title: 'Run reset', description: `New run #${data.newRunNumber} ready` });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/run/log'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-periods'] });
    },
    onError: (err: any) => {
      toast({ title: 'Reset failed', description: err.message, variant: 'destructive' });
    },
  });

  const getStepStatus = (stepKey: string) => {
    const log = runLog.find((l: any) => l.step === stepKey && l.runNumber === runNumber);
    return log?.status || 'pending';
  };

  const getCompletedStepCount = () => {
    return STEP_CONFIG.filter(s => getStepStatus(s.key) === 'completed').length;
  };

  const runAllSteps = async () => {
    if (!runNumber) return;
    setIsRunningAll(true);
    try {
      for (let i = 0; i < STEP_CONFIG.length; i++) {
        const step = STEP_CONFIG[i];
        const status = getStepStatus(step.key);
        if (status === 'completed') continue;

        setRunAllProgress(`Running ${step.label}... (${i + 1}/${STEP_CONFIG.length})`);
        setCurrentStep(i);

        const result = await apiRequest('POST', '/api/payroll/run/step', {
          periodId: period.id,
          runNumber,
          step: step.key,
          includeNonSystem,
        });

        if (result.errorCount > 0 && !result.success) {
          toast({
            title: `${step.label} had errors`,
            description: `${result.employeesProcessed} processed, ${result.errorCount} errors. Pipeline paused.`,
            variant: 'destructive',
          });
          break;
        }

        toast({
          title: `${step.label} completed`,
          description: `${result.employeesProcessed} processed, ${result.errorCount} errors`,
        });
      }
      setRunAllProgress('');
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/run/log'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-periods'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-records'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/verify'] });
    } catch (err: any) {
      toast({ title: 'Pipeline error', description: err.message, variant: 'destructive' });
    } finally {
      setIsRunningAll(false);
      setRunAllProgress('');
    }
  };


  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-semibold">Payroll Run Engine</h3>
          <Badge className={STATUS_COLORS[period.status || 'draft']}>
            {(period.status || 'draft').toUpperCase()}
          </Badge>
          {runNumber > 0 && (
            <Badge variant="outline">Run #{runNumber}</Badge>
          )}
        </div>
        <div className="flex gap-2">
          {(!runNumber || period.status === 'draft') && (
            <Button
              onClick={() => startRunMutation.mutate()}
              disabled={startRunMutation.isPending}
              size="sm"
            >
              {startRunMutation.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Play className="h-4 w-4 mr-1" />}
              {runNumber > 0 ? 'New Run' : 'Start Run'}
            </Button>
          )}
          {runNumber > 0 && getCompletedStepCount() < STEP_CONFIG.length && period.status !== 'paid' && period.status !== 'locked' && (
            <Button
              onClick={runAllSteps}
              disabled={isRunningAll || executeStepMutation.isPending}
              size="sm"
              variant="default"
              className="bg-green-600 hover:bg-green-700"
            >
              {isRunningAll ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  {runAllProgress || 'Running...'}
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-1" />
                  Run All Steps
                </>
              )}
            </Button>
          )}
          {period.status !== 'paid' && period.status !== 'locked' && runNumber > 0 && (
            <Button variant="outline" size="sm" onClick={() => setShowResetDialog(true)} disabled={isRunningAll}>
              <RotateCcw className="h-4 w-4 mr-1" /> Reset
            </Button>
          )}
        </div>
      </div>

      <div className="space-y-3 mt-3">
          <div className="flex items-center gap-3 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <input
              type="checkbox"
              id="include-non-system"
              checked={includeNonSystem}
              onChange={e => setIncludeNonSystem(e.target.checked)}
              className="h-4 w-4 rounded border-gray-300"
            />
            <Label htmlFor="include-non-system" className="text-sm text-blue-800 cursor-pointer">
              Include Non-System Users (calendar-based attendance)
            </Label>
          </div>

          <PipelineView
            steps={STEP_CONFIG}
            getStepStatus={getStepStatus}
            currentStep={currentStep}
            onExecuteStep={(step) => executeStepMutation.mutate(step)}
            isExecuting={executeStepMutation.isPending || isRunningAll}
            runNumber={runNumber}
            periodStatus={period.status || 'draft'}
            periodId={period.id}
          />

      </div>

      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Payroll Run</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This will unlock all locks for this period and start a fresh run. The previous run data will be preserved for audit.
            </p>
            <div>
              <Label>Reason for Reset</Label>
              <Textarea
                value={resetReason}
                onChange={(e) => setResetReason(e.target.value)}
                placeholder="Explain why this run needs to be reset..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetDialog(false)}>Cancel</Button>
            <Button
              variant="destructive"
              onClick={() => resetMutation.mutate()}
              disabled={!resetReason.trim() || resetMutation.isPending}
            >
              {resetMutation.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
              Reset Run
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PipelineView({
  steps,
  getStepStatus,
  currentStep,
  onExecuteStep,
  isExecuting,
  runNumber,
  periodStatus,
  periodId,
}: {
  steps: typeof STEP_CONFIG;
  getStepStatus: (key: string) => string;
  currentStep: number;
  onExecuteStep: (step: string) => void;
  isExecuting: boolean;
  runNumber: number;
  periodStatus: string;
  periodId: number;
}) {
  const allStepsCompleted = steps.every(s => getStepStatus(s.key) === 'completed');

  const { data: verificationSummary } = useQuery<any>({
    queryKey: ['/api/payroll/verify', periodId, 'summary'],
    queryFn: async () => {
      return await apiRequest('GET', `/api/payroll/verify/${periodId}/summary`);
    },
    enabled: allStepsCompleted && runNumber > 0,
  });

  const verifyMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', `/api/payroll/verify/${periodId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/verify'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-records'] });
    },
  });

  const getVerifyStatus = () => {
    if (!allStepsCompleted) return 'pending';
    if (!verificationSummary) return 'pending';
    if (verificationSummary.total === 0) return 'pending';
    if (verificationSummary.failed > 0) return 'failed';
    return 'completed';
  };

  const verifyStatus = getVerifyStatus();

  if (runNumber === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          <Play className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>Click "Start Run" to begin the payroll processing pipeline.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {steps.map((step, idx) => {
        const status = getStepStatus(step.key);
        const Icon = step.icon;
        const isActive = idx === currentStep && status !== 'completed';
        const canRun = runNumber > 0 && (idx === 0 || getStepStatus(steps[idx - 1].key) === 'completed') && status !== 'completed' && periodStatus !== 'paid' && periodStatus !== 'locked';

        return (
          <div
            key={step.key}
            className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
              status === 'completed' ? 'bg-green-50 border-green-200' :
              status === 'failed' ? 'bg-red-50 border-red-200' :
              status === 'running' ? 'bg-blue-50 border-blue-200' :
              isActive ? 'bg-blue-50/50 border-blue-100' :
              'bg-gray-50 border-gray-100'
            }`}
          >
            <div className={`p-2 rounded-full ${
              status === 'completed' ? 'bg-green-100 text-green-700' :
              status === 'failed' ? 'bg-red-100 text-red-700' :
              status === 'running' ? 'bg-blue-100 text-blue-700' :
              'bg-gray-100 text-gray-500'
            }`}>
              {status === 'completed' ? <CheckCircle2 className="h-5 w-5" /> :
               status === 'failed' ? <XCircle className="h-5 w-5" /> :
               status === 'running' ? <Loader2 className="h-5 w-5 animate-spin" /> :
               <Icon className="h-5 w-5" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">{step.label}</div>
              <div className="text-xs text-muted-foreground">{step.description}</div>
            </div>
            {canRun && (
              <Button
                size="sm"
                variant={status === 'failed' ? 'destructive' : 'default'}
                onClick={() => onExecuteStep(step.key)}
                disabled={isExecuting}
              >
                {isExecuting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                <span className="ml-1">{status === 'failed' ? 'Retry' : 'Run'}</span>
              </Button>
            )}
            {status === 'completed' && (
              <Badge variant="outline" className="text-green-700 border-green-300">Done</Badge>
            )}
          </div>
        );
      })}

      <div
        className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
          verifyStatus === 'completed' ? 'bg-green-50 border-green-200' :
          verifyStatus === 'failed' ? 'bg-amber-50 border-amber-200' :
          'bg-gray-50 border-gray-100'
        }`}
      >
        <div className={`p-2 rounded-full ${
          verifyStatus === 'completed' ? 'bg-green-100 text-green-700' :
          verifyStatus === 'failed' ? 'bg-amber-100 text-amber-700' :
          'bg-gray-100 text-gray-500'
        }`}>
          {verifyStatus === 'completed' ? <CheckCircle2 className="h-5 w-5" /> :
           verifyStatus === 'failed' ? <AlertTriangle className="h-5 w-5" /> :
           verifyMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> :
           <ShieldCheck className="h-5 w-5" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-medium text-sm">Verify All Calculations</div>
          <div className="text-xs text-muted-foreground">
            {verifyStatus === 'completed' && verificationSummary
              ? `All ${verificationSummary.passed} records verified — no errors`
              : verifyStatus === 'failed' && verificationSummary
              ? `${verificationSummary.passed} passed, ${verificationSummary.failed} failed of ${verificationSummary.total} records`
              : 'Independently verify all salary calculations against source data'}
          </div>
        </div>
        {verifyMutation.isPending && (
          <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
        )}
        {verifyStatus === 'completed' && (
          <Badge variant="outline" className="text-green-700 border-green-300">Passed</Badge>
        )}
        {verifyStatus === 'failed' && (
          <Badge variant="outline" className="text-amber-700 border-amber-300">Issues Found</Badge>
        )}
      </div>

      <SapTransferStep
        periodId={periodId}
        periodStatus={periodStatus}
        verifyStatus={verifyStatus}
      />
    </div>
  );
}

function SapTransferStep({ periodId, periodStatus, verifyStatus }: { periodId: number; periodStatus: string; verifyStatus: string }) {
  const { toast } = useToast();
  const [batchResult, setBatchResult] = useState<any>(null);
  const [showBatchResult, setShowBatchResult] = useState(false);
  const [transferProgress, setTransferProgress] = useState('');

  const isReady = verifyStatus === 'completed';
  const isLocked = periodStatus === 'paid' || periodStatus === 'locked';

  const { data: preview, refetch: refetchPreview } = useQuery<any>({
    queryKey: ['/api/payroll/sap-transfer', periodId, 'preview'],
    queryFn: async () => {
      return await apiRequest('GET', `/api/payroll/sap-transfer/${periodId}/preview`);
    },
    enabled: isReady,
  });

  const batchTransferMutation = useMutation({
    mutationFn: async (recordIds: number[]) => {
      const results: any[] = [];
      for (let i = 0; i < recordIds.length; i++) {
        setTransferProgress(`Posting ${i + 1} of ${recordIds.length}...`);
        try {
          const r = await apiRequest('POST', `/api/admin/payroll/records/${recordIds[i]}/post-sap`);
          results.push({ recordId: recordIds[i], success: true, ...r });
        } catch (e: any) {
          results.push({ recordId: recordIds[i], success: false, error: e.message });
        }
      }
      return results;
    },
    onSuccess: (results) => {
      const posted = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;
      setBatchResult(results);
      setShowBatchResult(true);
      setTransferProgress('');
      toast({
        title: 'SAP Transfer Complete',
        description: `${posted} posted, ${failed} failed of ${results.length} records`,
        variant: failed > 0 ? 'destructive' : 'default',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/payroll-records'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payroll/sap-transfer'] });
      refetchPreview();
    },
    onError: () => setTransferProgress(''),
  });

  const getSapStatus = () => {
    if (!isReady) return 'pending';
    if (batchTransferMutation.isPending) return 'running';
    if (!preview) return 'pending';
    const postedCount = preview.posted || 0;
    if (postedCount > 0 && postedCount >= preview.totalRecords) return 'completed';
    if (preview.eligible > 0) return 'ready';
    if (preview.blocked > 0) return 'blocked';
    if (postedCount > 0 && preview.eligible === 0) return 'completed';
    return 'pending';
  };

  const sapStatus = getSapStatus();

  const handleManualTransfer = () => {
    if (preview?.eligibleRecords?.length > 0) {
      const ids = preview.eligibleRecords.map((r: any) => r.recordId);
      batchTransferMutation.mutate(ids);
    }
  };

  return (
    <>
      <div
        className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
          sapStatus === 'completed' ? 'bg-green-50 border-green-200' :
          sapStatus === 'blocked' ? 'bg-red-50 border-red-200' :
          sapStatus === 'running' ? 'bg-blue-50 border-blue-200' :
          'bg-gray-50 border-gray-100'
        }`}
      >
        <div className={`p-2 rounded-full ${
          sapStatus === 'completed' ? 'bg-green-100 text-green-700' :
          sapStatus === 'blocked' ? 'bg-red-100 text-red-700' :
          sapStatus === 'running' ? 'bg-blue-100 text-blue-700' :
          'bg-gray-100 text-gray-500'
        }`}>
          {sapStatus === 'completed' ? <CheckCircle2 className="h-5 w-5" /> :
           sapStatus === 'blocked' ? <XCircle className="h-5 w-5" /> :
           sapStatus === 'running' ? <Loader2 className="h-5 w-5 animate-spin" /> :
           <Send className="h-5 w-5" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-medium text-sm">SAP Transfer</div>
          <div className="text-xs text-muted-foreground">
            {sapStatus === 'completed'
              ? `${preview?.posted || preview?.totalRecords || 0} of ${preview?.totalRecords || 0} records transferred to SAP`
              : sapStatus === 'running'
              ? transferProgress || 'Posting journal entries to SAP B1...'
              : sapStatus === 'blocked' && preview
              ? `${preview.blocked} blocked${preview.posted > 0 ? `, ${preview.posted} already posted` : ''} — fix issues before transfer`
              : sapStatus === 'ready' && preview
              ? `${preview.eligible} ready to post${preview.posted > 0 ? `, ${preview.posted} already posted` : ''}`
              : 'Post verified salary journal entries to SAP B1'}
          </div>
        </div>
        <div className="flex gap-2">
          {sapStatus === 'completed' && (
            <Badge variant="outline" className="text-green-700 border-green-300">Done</Badge>
          )}
          {sapStatus === 'ready' && !isLocked && (
            <Button
              size="sm"
              onClick={handleManualTransfer}
              disabled={batchTransferMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              <Send className="h-4 w-4 mr-1" /> Transfer to SAP
            </Button>
          )}
          {sapStatus === 'blocked' && !isLocked && (
            <Button
              size="sm"
              variant="outline"
              className="text-orange-600"
              onClick={() => {
                refetchPreview();
              }}
            >
              <RefreshCw className="h-4 w-4 mr-1" /> Retry
            </Button>
          )}
          {sapStatus === 'running' && (
            <Badge variant="outline" className="text-blue-700 border-blue-300">
              <Loader2 className="h-3 w-3 mr-1 animate-spin" /> Posting
            </Badge>
          )}
        </div>
      </div>

      <Dialog open={showBatchResult} onOpenChange={setShowBatchResult}>
        <DialogContent className="max-w-3xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>SAP Transfer Results</DialogTitle>
          </DialogHeader>
          <div className="overflow-auto max-h-[65vh]">
            {batchResult && (
              <div className="space-y-2">
                <div className="flex gap-4 mb-3">
                  <Badge className="bg-green-600">{batchResult.filter((r: any) => r.success).length} Posted</Badge>
                  {batchResult.filter((r: any) => !r.success).length > 0 && (
                    <Badge variant="destructive">{batchResult.filter((r: any) => !r.success).length} Failed</Badge>
                  )}
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-2">Record</th>
                        <th className="text-center p-2">Status</th>
                        <th className="text-left p-2">Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {batchResult.map((r: any) => (
                        <tr key={r.recordId} className="border-t">
                          <td className="p-2">#{r.recordId}</td>
                          <td className="p-2 text-center">
                            {r.success
                              ? <Badge className="bg-green-600 text-xs">Posted</Badge>
                              : <Badge variant="destructive" className="text-xs">Failed</Badge>}
                          </td>
                          <td className="p-2 text-xs">
                            {r.success
                              ? `JE #${r.sapJeNumber || 'N/A'} (DocEntry: ${r.sapDocEntry || 'N/A'})`
                              : r.error}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBatchResult(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

