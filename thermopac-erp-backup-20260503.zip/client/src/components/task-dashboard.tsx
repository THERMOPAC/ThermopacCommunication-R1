import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { Task, User } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TaskList from "@/components/task-list-new";
// Due date filter import removed
import { 
  Select, 
  SelectContent, 
  SelectGroup,
  SelectItem, 
  SelectLabel,
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { roles, roleHierarchy } from "@shared/roles";
import { 
  Calendar,
  CheckCircle,
  Clock,
  AlertCircle,
  Filter,
  ChevronDown,
  SortAsc,
  SortDesc,
  RefreshCw,
  Users,
  CalendarDays
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function TaskDashboard() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("my");
  const [urlParams, setUrlParams] = useState<URLSearchParams | null>(null);

  // Parse URL parameters on component mount and force refresh
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setUrlParams(params);
    
    // Force a fresh fetch of tasks when component mounts
    handleRefreshTasks();
  }, []);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [priorityFilter, setPriorityFilter] = useState<string | null>(null);
  const [assignedByFilter, setAssignedByFilter] = useState<string | null>(null);
  const [assignedToFilter, setAssignedToFilter] = useState<string | null>(null);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [sortBy, setSortBy] = useState<"dueDate" | "priority" | "title">("dueDate");

  const { data: tasks = [], refetch: refetchTasks, isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: subordinates = [] } = useQuery<User[]>({
    queryKey: ["/api/subordinates"],
  });

  const { data: allUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const agentDisplayNames: Record<string, string> = {
    'communicator': 'Communications Agent',
    'communications': 'Communications Agent',
    'project_controller': 'Project Control Agent',
    'project_control': 'Project Control Agent',
    'predictive_project_controller': 'Predictive Project Control Agent',
    'finance_controller': 'Finance Control Agent',
    'finance_control': 'Finance Control Agent',
    'executive_mis': 'Executive MIS Agent',
    'production_manager': 'Production Management Agent',
    'production_management': 'Production Management Agent',
    'quality_controller': 'Quality Management Agent',
    'quality_management': 'Quality Management Agent',
    'sales_marketer': 'Sales & Marketing Agent',
    'sales_marketing': 'Sales & Marketing Agent',
  };

  const getCreatorDisplayName = useCallback((task: Task) => {
    if (task.sourceAgent) {
      return agentDisplayNames[task.sourceAgent] || task.sourceAgent;
    }
    const u = allUsers.find(usr => usr.id === task.createdBy);
    return u ? u.username : 'Unknown';
  }, [allUsers]);

  const getCreatorKey = useCallback((task: Task) => {
    return task.sourceAgent ? `agent:${task.sourceAgent}` : `user:${task.createdBy || 0}`;
  }, []);

  const uniqueAssigners = useMemo(() => {
    const map = new Map<string, string>();
    tasks.forEach(task => {
      const key = getCreatorKey(task);
      if (!map.has(key)) {
        map.set(key, getCreatorDisplayName(task));
      }
    });
    return Array.from(map.entries()).sort((a, b) => a[1].localeCompare(b[1]));
  }, [tasks, getCreatorKey, getCreatorDisplayName]);

  const uniqueAssignees = useMemo(() => {
    const ids = new Set<number>();
    tasks.forEach(task => { if (task.assignedTo) ids.add(task.assignedTo); });
    return Array.from(ids)
      .map(id => { const u = allUsers.find(usr => usr.id === id); return u ? { id, name: u.username } : { id, name: `User ${id}` }; })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [tasks, allUsers]);

  const sortedRoles = useMemo(
    () => [...roles].sort((a, b) => roleHierarchy[a] - roleHierarchy[b]),
    []
  );

  const groupedAssigners = useMemo(() => {
    const agents: Array<[string, string]> = [];
    const byRole: Record<string, Array<[string, string]>> = {};
    uniqueAssigners.forEach(([key, name]) => {
      if (key.startsWith("agent:")) {
        agents.push([key, name]);
      } else {
        const userId = Number(key.replace("user:", ""));
        const u = allUsers.find(usr => usr.id === userId);
        const role = u?.role || "Employee";
        if (!byRole[role]) byRole[role] = [];
        byRole[role].push([key, name]);
      }
    });
    return { agents, byRole };
  }, [uniqueAssigners, allUsers]);

  const groupedAssignees = useMemo(() => {
    const byRole: Record<string, Array<{ id: number; name: string }>> = {};
    uniqueAssignees.forEach(item => {
      const u = allUsers.find(usr => usr.id === item.id);
      const role = u?.role || "Employee";
      if (!byRole[role]) byRole[role] = [];
      byRole[role].push(item);
    });
    return byRole;
  }, [uniqueAssignees, allUsers]);

  // Fetch commitment tasks for the current user
  const { data: commitmentTasksData, refetch: refetchCommitmentTasks, isLoading: isLoadingCommitmentTasks } = useQuery({
    queryKey: ["/api/meetings/commitments/user-tasks"],
    select: (data: any) => data?.commitmentTasks || []
  });

  // Function to manually refresh tasks
  const handleRefreshTasks = async () => {
    console.log("Manually refreshing tasks and commitment tasks...");
    await queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    await queryClient.invalidateQueries({ queryKey: ["/api/meetings/commitments/user-tasks"] });
    await refetchTasks();
    await refetchCommitmentTasks();
  };

  // Debug logging to understand the data flow
  useEffect(() => {
    console.log("=== Task Dashboard Debug Info ===");
    console.log("Current user:", user);
    console.log("Total tasks loaded:", tasks.length);
    console.log("My tasks (assigned to me):", tasks.filter(task => task.assignedTo === user?.id));
    console.log("Looking for task 1395:", tasks.find(task => task.id === 1395));
    console.log("All tasks:", tasks.map(t => ({ id: t.id, title: t.title, assignedTo: t.assignedTo, createdBy: t.createdBy })));
  }, [tasks, user]);

  // Filter tasks based on selected filters
  const filterTasks = (tasks: Task[]) => {
    let filteredTasks = [...tasks];
    
    // Filter by tab
    if (activeTab === "my") {
      filteredTasks = filteredTasks.filter(task => task.assignedTo === user?.id);
    } else if (activeTab === "pending") {
      filteredTasks = filteredTasks.filter(task => task.status === "pending");
    } else if (activeTab === "completed") {
      filteredTasks = filteredTasks.filter(task => task.status === "completed");
    } else if (activeTab === "overdue") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filteredTasks = filteredTasks.filter(task => {
        // Check either dueDate or finishDate for overdue tasks
        const dueDate = task.dueDate ? new Date(task.dueDate) : null;
        const finishDate = task.finishDate ? new Date(task.finishDate) : null;
        
        // If either date exists and is before today, the task is overdue
        const isDueOverdue = dueDate && dueDate < today;
        const isFinishOverdue = finishDate && finishDate < today;
        
        return task.status === "pending" && (isDueOverdue || isFinishOverdue);
      });
    }
    
    if (statusFilter) {
      filteredTasks = filteredTasks.filter(task => task.status === statusFilter);
    }

    if (priorityFilter) {
      filteredTasks = filteredTasks.filter(task => task.priority === priorityFilter);
    }

    if (assignedByFilter) {
      filteredTasks = filteredTasks.filter(task => getCreatorKey(task) === assignedByFilter);
    }

    if (assignedToFilter) {
      filteredTasks = filteredTasks.filter(task => String(task.assignedTo) === assignedToFilter);
    }
    
    // Sort tasks
    filteredTasks.sort((a, b) => {
      if (sortBy === "dueDate") {
        // Use either dueDate or finishDate for sorting, prioritizing finishDate
        const dateA = a.finishDate ? new Date(a.finishDate) : (a.dueDate ? new Date(a.dueDate) : new Date(0));
        const dateB = b.finishDate ? new Date(b.finishDate) : (b.dueDate ? new Date(b.dueDate) : new Date(0));
        return sortOrder === "asc" ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
      } else if (sortBy === "priority") {
        const priorityValues = { "Low": 1, "Medium": 2, "High": 3 };
        const priorityA = priorityValues[a.priority as keyof typeof priorityValues] || 0;
        const priorityB = priorityValues[b.priority as keyof typeof priorityValues] || 0;
        return sortOrder === "asc" ? priorityA - priorityB : priorityB - priorityA;
      } else {
        // Sort by title
        return sortOrder === "asc" 
          ? a.title.localeCompare(b.title) 
          : b.title.localeCompare(a.title);
      }
    });
    
    return filteredTasks;
  };

  const filteredTasks = filterTasks(tasks);

  // Count tasks by status
  const myTasksCount = tasks.filter(task => task.assignedTo === user?.id).length;
  const pendingCount = tasks.filter(task => task.status === "pending").length;
  const completedCount = tasks.filter(task => task.status === "completed").length;
  
  // Count overdue tasks
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Add debugging logs
  console.log('Current date (today):', today.toISOString());
  console.log('Tasks with finish dates:', tasks.filter(t => t.finishDate).map(t => ({
    id: t.id,
    title: t.title,
    dueDate: t.dueDate,
    finishDate: t.finishDate,
    status: t.status
  })));
  
  // The problem might be that we're checking dueDate but tasks actually use finishDate
  // Let's check both fields to find overdue tasks
  const overdueCount = tasks.filter(task => {
    const dueDate = task.dueDate ? new Date(task.dueDate) : null;
    const finishDate = task.finishDate ? new Date(task.finishDate) : null;
    
    // Check if either dueDate or finishDate is before today
    const isDueOverdue = dueDate && dueDate < today;
    const isFinishOverdue = finishDate && finishDate < today;
    
    return task.status === "pending" && (isDueOverdue || isFinishOverdue);
  }).length;

  // Tasks stats
  const tasksByPriority = {
    "High": tasks.filter(t => t.priority === "High").length,
    "Medium": tasks.filter(t => t.priority === "Medium").length,
    "Low": tasks.filter(t => t.priority === "Low").length,
  };

  // Helper to get proper icon for the priority
  const getPriorityIcon = (priority: string) => {
    switch(priority) {
      case "High":
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case "Medium":
        return <Clock className="h-4 w-4 text-amber-500" />;
      case "Low":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <CheckCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Task Management</h1>
        
        <div className="flex items-center gap-2">
          {/* Refresh button */}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefreshTasks}
            disabled={isLoadingTasks}
            className="flex items-center gap-1"
          >
            <RefreshCw className={`h-4 w-4 ${isLoadingTasks ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          {/* Sort dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                {sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
                Sort by: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
                <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Sort Options</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSortBy("dueDate")}>
                <Calendar className="h-4 w-4 mr-2" />
                Due Date
                {sortBy === "dueDate" && (sortOrder === "asc" ? <SortAsc className="h-4 w-4 ml-2" /> : <SortDesc className="h-4 w-4 ml-2" />)}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("priority")}>
                <AlertCircle className="h-4 w-4 mr-2" />
                Priority
                {sortBy === "priority" && (sortOrder === "asc" ? <SortAsc className="h-4 w-4 ml-2" /> : <SortDesc className="h-4 w-4 ml-2" />)}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("title")}>
                <span className="mr-2">A-Z</span>
                Title
                {sortBy === "title" && (sortOrder === "asc" ? <SortAsc className="h-4 w-4 ml-2" /> : <SortDesc className="h-4 w-4 ml-2" />)}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}>
                {sortOrder === "asc" ? (
                  <>
                    <SortAsc className="h-4 w-4 mr-2" />
                    Ascending
                  </>
                ) : (
                  <>
                    <SortDesc className="h-4 w-4 mr-2" />
                    Descending
                  </>
                )}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Status filter */}
          <Select
            value={statusFilter || "all"}
            onValueChange={(value) => setStatusFilter(value === "all" ? null : value)}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 text-amber-500 mr-2" />
                  Pending
                </div>
              </SelectItem>
              <SelectItem value="in_progress">
                <div className="flex items-center">
                  <RefreshCw className="h-4 w-4 text-blue-500 mr-2" />
                  In Progress
                </div>
              </SelectItem>
              <SelectItem value="completed">
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Completed
                </div>
              </SelectItem>
              <SelectItem value="on_hold">
                <div className="flex items-center">
                  <AlertCircle className="h-4 w-4 text-orange-500 mr-2" />
                  On Hold
                </div>
              </SelectItem>
              <SelectItem value="canceled">
                <div className="flex items-center">
                  <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
                  Cancelled
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          {/* Priority filter */}
          <Select
            value={priorityFilter || "all"}
            onValueChange={(value) => setPriorityFilter(value === "all" ? null : value)}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="High">
                <div className="flex items-center">
                  <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
                  High
                </div>
              </SelectItem>
              <SelectItem value="Medium">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 text-amber-500 mr-2" />
                  Medium
                </div>
              </SelectItem>
              <SelectItem value="Low">
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Low
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={assignedByFilter || "all"}
            onValueChange={(value) => setAssignedByFilter(value === "all" ? null : value)}
          >
            <SelectTrigger className="w-[170px]">
              <SelectValue placeholder="Assigned By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Assigned By</SelectItem>
              {groupedAssigners.agents.length > 0 && (
                <SelectGroup>
                  <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">AI Agents</SelectLabel>
                  {groupedAssigners.agents.map(([key, name]) => (
                    <SelectItem key={key} value={key}>{name}</SelectItem>
                  ))}
                </SelectGroup>
              )}
              {sortedRoles.filter(role => groupedAssigners.byRole[role]?.length).map(role => (
                <SelectGroup key={role}>
                  <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">{role}s</SelectLabel>
                  {groupedAssigners.byRole[role].map(([key, name]) => (
                    <SelectItem key={key} value={key}>{name}</SelectItem>
                  ))}
                </SelectGroup>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={assignedToFilter || "all"}
            onValueChange={(value) => setAssignedToFilter(value === "all" ? null : value)}
          >
            <SelectTrigger className="w-[170px]">
              <SelectValue placeholder="Assigned To" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Assigned To</SelectItem>
              {sortedRoles.filter(role => groupedAssignees[role]?.length).map(role => (
                <SelectGroup key={role}>
                  <SelectLabel className="font-semibold text-blue-600 dark:text-blue-400">{role}s</SelectLabel>
                  {groupedAssignees[role].map(item => (
                    <SelectItem key={item.id} value={String(item.id)}>{item.name}</SelectItem>
                  ))}
                </SelectGroup>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Task stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-sm">
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Tasks</p>
              <p className="text-2xl font-bold">{tasks.length}</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-full">
              <Calendar className="h-5 w-5 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold">{pendingCount}</p>
            </div>
            <div className="p-2 bg-amber-100 rounded-full">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Completed</p>
              <p className="text-2xl font-bold">{completedCount}</p>
            </div>
            <div className="p-2 bg-green-100 rounded-full">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Overdue</p>
              <p className="text-2xl font-bold">{overdueCount}</p>
            </div>
            <div className="p-2 bg-red-100 rounded-full">
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Task filters by status */}
      <Tabs defaultValue="my" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="my" className="flex items-center justify-center gap-2">
            My Tasks
            <Badge variant="secondary">{myTasksCount}</Badge>
          </TabsTrigger>
          <TabsTrigger value="commitments" className="flex items-center justify-center gap-2">
            Commitments
            <Badge variant="secondary">{commitmentTasksData?.length || 0}</Badge>
          </TabsTrigger>
          <TabsTrigger value="all" className="flex items-center justify-center gap-2">
            All Tasks
            <Badge variant="secondary">{tasks.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="pending" className="flex items-center justify-center gap-2">
            Pending
            <Badge variant="secondary">{pendingCount}</Badge>
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center justify-center gap-2">
            Completed
            <Badge variant="secondary">{completedCount}</Badge>
          </TabsTrigger>
          <TabsTrigger value="overdue" className="flex items-center justify-center gap-2">
            Overdue
            <Badge variant="secondary" className={overdueCount > 0 ? "bg-red-500 text-white" : ""}>
              {overdueCount}
            </Badge>
          </TabsTrigger>
        </TabsList>
        
        <div className="mt-4">
          {activeTab === "commitments" ? (
            <CommitmentTasksList 
              commitmentTasks={commitmentTasksData || []}
              isLoading={isLoadingCommitmentTasks}
            />
          ) : filteredTasks.length > 0 ? (
            <TaskList 
              tasks={filteredTasks} 
              subordinates={subordinates} 
              initialShowCompleted={true}
              urlParams={urlParams}
            />
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="flex flex-col items-center gap-2">
                  <Filter className="h-10 w-10 text-muted-foreground opacity-30" />
                  <h3 className="text-lg font-medium">No tasks found</h3>
                  <p className="text-sm text-muted-foreground">
                    Try adjusting your filters to find what you're looking for.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </Tabs>
      
      {/* Task Breakdown */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Task Breakdown by Priority</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(tasksByPriority).map(([priority, count]) => (
              <div key={priority} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getPriorityIcon(priority)}
                    <span>{priority} Priority</span>
                  </div>
                  <span className="font-medium">{count}</span>
                </div>
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${
                      priority === "High" ? "bg-red-500" : 
                      priority === "Medium" ? "bg-amber-500" : "bg-green-500"
                    }`}
                    style={{ width: `${(count / tasks.length) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Commitment Tasks List Component
interface CommitmentTasksListProps {
  commitmentTasks: any[];
  isLoading: boolean;
}

function CommitmentTasksList({ commitmentTasks, isLoading }: CommitmentTasksListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const completeTaskMutation = useMutation({
    mutationFn: async (taskId: number) => {
      return apiRequest('POST', `/api/meetings/commitments/tasks/${taskId}/complete`);
    },
    onSuccess: () => {
      toast({
        title: "Task Completed",
        description: "Commitment task marked as completed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/meetings/commitments/user-tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to complete task",
        variant: "destructive",
      });
    }
  });

  const handleCompleteTask = (taskId: number) => {
    completeTaskMutation.mutate(taskId);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw className="h-8 w-8 text-muted-foreground animate-spin" />
            <h3 className="text-lg font-medium">Loading commitment tasks...</h3>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!commitmentTasks || commitmentTasks.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="flex flex-col items-center gap-2">
            <Users className="h-10 w-10 text-muted-foreground opacity-30" />
            <h3 className="text-lg font-medium">No commitment tasks found</h3>
            <p className="text-sm text-muted-foreground">
              Tasks from meeting commitments assigned to you will appear here.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">My Commitment Tasks</h3>
        <Badge variant="outline">{commitmentTasks.length} tasks</Badge>
      </div>
      
      {commitmentTasks.map((item) => {
        const task = item.task;
        const commitment = item.commitment;
        const meeting = item.meeting;
        
        const isCompleted = task.status === 'completed';
        const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && !isCompleted;
        
        return (
          <Card key={task.id} className={`${isCompleted ? 'opacity-70' : ''}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1 space-y-3">
                  <div>
                    <h4 className="font-semibold text-lg flex items-center gap-2">
                      {task.title}
                      {isCompleted && <CheckCircle className="h-5 w-5 text-green-500" />}
                      {isOverdue && <AlertCircle className="h-5 w-5 text-red-500" />}
                    </h4>
                    {task.description && (
                      <p className="text-muted-foreground mt-1">{task.description}</p>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 font-mono text-xs">
                      ID: {commitment.id}
                    </Badge>
                    <Badge variant={task.priority === 'High' ? 'destructive' : task.priority === 'Medium' ? 'default' : 'secondary'}>
                      {task.priority} Priority
                    </Badge>
                    <Badge variant={isCompleted ? 'default' : 'outline'}>
                      {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                    </Badge>
                    {commitment.status && (
                      <Badge variant="outline" className="bg-blue-50">
                        Commitment: {commitment.status}
                      </Badge>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    {meeting && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CalendarDays className="h-4 w-4" />
                        <span>From meeting: <strong>{meeting.title}</strong></span>
                        {meeting.meetingDate && (
                          <span>({new Date(meeting.meetingDate).toLocaleDateString()})</span>
                        )}
                      </div>
                    )}
                    
                    {task.dueDate && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                        {isOverdue && <span className="text-red-500 font-medium">(Overdue)</span>}
                      </div>
                    )}
                    
                    {commitment.dueDate && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>Commitment due: {new Date(commitment.dueDate).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                {!isCompleted && (
                  <Button
                    onClick={() => handleCompleteTask(task.id)}
                    disabled={completeTaskMutation.isPending}
                    className="ml-4"
                  >
                    {completeTaskMutation.isPending ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Completing...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Complete
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}