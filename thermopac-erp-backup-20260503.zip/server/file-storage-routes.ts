import express, { Request, Response, Router } from 'express';
import multer from 'multer';
import { gcsStorage } from './utils/gcs-storage';
import { bucketName } from './utils/storage-config';
import { checkGcsPermissions } from './utils/gcs-permissions-check';
import { db } from './db';
import * as schema from '@shared/schema';
import { gcsDirectories, projectDocuments, directoryTemplates, masterItems, legacyFileAccessLog } from '@shared/schema';
import { eq, and, like, sql } from 'drizzle-orm';
import path from 'path';
import { checkProjectMembership } from './utils/permission-utils';

const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024,
  }
});

function ensureAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: 'You must be logged in to access this resource' });
}

const MANAGER_PLUS_ROLES = ['Manager', 'Senior Manager', 'General Manager', 'Superuser'];

async function resolveProjectFromCode(projectCodeStr: string): Promise<{ id: number; code: string | null } | null> {
  const result = await db.execute(
    sql`SELECT id, code FROM projects WHERE code = ${projectCodeStr} LIMIT 1`
  );
  if (result.rows.length === 0) return null;
  const row = result.rows[0] as any;
  return { id: row.id, code: row.code };
}

async function enforceFileAccessControl(
  req: Request,
  res: Response,
  pathStr: string,
  action: string
): Promise<boolean> {
  const user = (req as any).user;
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return false;
  }

  if (pathStr.startsWith('THERMOPAC_INVENTORY/') || pathStr.startsWith('THERMOPAC_INVENTORY')) {
    if (!MANAGER_PLUS_ROLES.includes(user.role)) {
      console.warn(`[FILE_ACCESS_DENIED] userId=${user.id} role=${user.role} path=${pathStr} action=${action} reason=inventory_requires_manager`);
      await db.insert(legacyFileAccessLog).values({
        legacyPath: pathStr,
        pathFamily: 'PATH-03',
        accessedBy: user.id,
        action: 'access_denied',
        migratedToEpc: false,
      });
      res.status(403).json({ error: 'Inventory files require Manager or higher role' });
      return false;
    }
    await db.insert(legacyFileAccessLog).values({
      legacyPath: pathStr,
      pathFamily: 'PATH-03',
      accessedBy: user.id,
      action,
      migratedToEpc: false,
    });
    return true;
  }

  let projectCode: string | null = null;
  let pathFamily = 'PATH-02';

  if (pathStr.startsWith('THERMOPAC_PROJECTS/')) {
    const parts = pathStr.split('/');
    if (parts.length >= 3) {
      projectCode = parts[2];
    }
  } else if (!pathStr.startsWith('THERMOPAC_INVENTORY')) {
    const parts = pathStr.split('/');
    if (parts.length >= 2) {
      projectCode = parts[1];
    }
  }

  if (projectCode) {
    const project = await resolveProjectFromCode(projectCode);
    if (project) {
      const { isMember } = await checkProjectMembership(user.id, user.role, project.id);
      if (!isMember) {
        console.warn(`[FILE_ACCESS_DENIED] userId=${user.id} role=${user.role} projectCode=${projectCode} projectId=${project.id} path=${pathStr} action=${action}`);
        await db.insert(legacyFileAccessLog).values({
          legacyPath: pathStr,
          pathFamily,
          projectId: project.id,
          accessedBy: user.id,
          action: 'access_denied',
          migratedToEpc: false,
        });
        res.status(403).json({
          error: 'Project access denied',
          code: 'PROJECT_ACCESS_DENIED',
        });
        return false;
      }
      await db.insert(legacyFileAccessLog).values({
        legacyPath: pathStr,
        pathFamily,
        projectId: project.id,
        accessedBy: user.id,
        action,
        migratedToEpc: false,
      });
      return true;
    }
  }

  await db.insert(legacyFileAccessLog).values({
    legacyPath: pathStr,
    pathFamily: 'UNKNOWN',
    accessedBy: user.id,
    action,
    migratedToEpc: false,
  });
  return true;
}

/**
 * Setup file storage routes
 */
export function setupFileStorageRoutes(app: Router) {
  /**
   * Test endpoint for checking GCS connectivity and permissions
   */
  app.get('/api/storage/test-gcs', async (req: Request, res: Response) => {
    try {
      console.log('Testing GCS connectivity and permissions');
      const result = await checkGcsPermissions();
      
      console.log('GCS check result:', result);
      
      res.json({
        success: result.success,
        message: 'GCS connection test completed',
        result
      });
    } catch (error) {
      console.error('Error testing GCS connection:', error);
      res.status(500).json({
        success: false,
        message: 'Error testing GCS connection',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  /**
   * Get all available directory templates
   * Used by the frontend to show available templates when creating directories
   */
  app.get('/api/storage/templates', ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const templates = await db
        .select()
        .from(directoryTemplates)
        .orderBy(directoryTemplates.department, directoryTemplates.subDirectory);
      
      // Group templates by department for easier frontend handling
      const templatesByDepartment = templates.reduce((acc: any, template) => {
        if (!acc[template.department]) {
          acc[template.department] = [];
        }
        
        if (template.subDirectory) {
          acc[template.department].push(template);
        }
        
        return acc;
      }, {});
      
      res.json(templatesByDepartment);
    } catch (error) {
      console.error('Error fetching directory templates:', error);
      res.status(500).json({ error: 'Failed to fetch directory templates' });
    }
  });
  /**
   * Get project directory structure
   * Returns the directory tree for a project based on financial year and project code
   * Combines standard templates with project-specific custom directories
   */
  app.get('/api/storage/directories/:financialYear/:projectCode', ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const { financialYear, projectCode } = req.params;
      
      const dirListPath = `THERMOPAC_PROJECTS/${financialYear}/${projectCode}`;
      const allowed = await enforceFileAccessControl(req, res, dirListPath, 'list_directories');
      if (!allowed) return;
      
      const templates = await db
        .select()
        .from(directoryTemplates);
      
      // 2. Get custom directories specific to this project from gcs_directories table
      const customDirectories = await db
        .select()
        .from(gcsDirectories)
        .where(
          and(
            eq(gcsDirectories.financialYear, financialYear),
            eq(gcsDirectories.projectCode, projectCode)
          )
        );
      
      console.log(`Found ${templates.length} directory templates and ${customDirectories.length} custom directories`);
      
      // 3. Create a combined directory list with both template-based and custom directories
      const combinedDirectories = [];
      
      // Add template-based directories with the project-specific path
      for (const template of templates) {
        // Build the virtual GCS path for this template in the project context
        let fullPath = path.join(financialYear, projectCode, template.department);
        if (template.subDirectory) {
          fullPath = path.join(fullPath, template.subDirectory);
        }
        fullPath = fullPath.replace(/\\/g, '/'); // Normalize path separators
        
        // Check if an actual custom directory exists for this path
        const customExists = customDirectories.some(dir => dir.fullPath === fullPath);
        
        // If a custom directory already exists, skip the template version
        if (!customExists) {
          combinedDirectories.push({
            id: 0, // Virtual ID for templates that don't exist in GCS yet
            financialYear,
            projectCode,
            department: template.department,
            subDirectory: template.subDirectory,
            fullPath,
            createdBy: req.user?.id || 0,
            createdAt: new Date(),
            updatedAt: new Date(),
            isPublic: template.isPublic,
            isTemplate: true // Mark as template-based
          });
        }
      }
      
      // Add all custom directories (they take precedence over templates)
      combinedDirectories.push(...customDirectories.map(dir => ({
        ...dir,
        isTemplate: false // Mark as custom/actual directory
      })));
      
      // Sort directories by department and then by subDirectory for consistent display
      combinedDirectories.sort((a, b) => {
        if (a.department !== b.department) {
          return a.department.localeCompare(b.department);
        }
        // If subdirectory is null, it should come before any named subdirectory
        if (!a.subDirectory && b.subDirectory) return -1;
        if (a.subDirectory && !b.subDirectory) return 1;
        if (!a.subDirectory && !b.subDirectory) return 0;
        return a.subDirectory!.localeCompare(b.subDirectory!);
      });
      
      res.status(200).json(combinedDirectories);
    } catch (error) {
      console.error('Error fetching directories:', error);
      res.status(500).json({ error: 'Failed to fetch directory structure' });
    }
  });

  /**
   * Create a new directory in GCS
   * Creates a directory in the specified path
   * Only creates physical directories for custom paths not in templates
   */
  app.post('/api/storage/directories', ensureAuthenticated, async (req: Request, res: Response) => {
    return res.status(403).json({
      error: 'Legacy File Storage is now read-only. All new documents must be uploaded through Document Control (TPEL structure).',
      code: 'LEGACY_STORAGE_LOCKED'
    });
    try {
      const { financialYear, projectCode, department, subDirectory } = req.body;
      
      if (!financialYear || !projectCode || !department) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }
      
      const dirAccessPath = `THERMOPAC_PROJECTS/${financialYear}/${projectCode}`;
      const allowed = await enforceFileAccessControl(req, res, dirAccessPath, 'create_directory');
      if (!allowed) return;
      
      let fullPath = path.join('THERMOPAC_PROJECTS', financialYear, projectCode, department);
      if (subDirectory) {
        fullPath = path.join(fullPath, subDirectory);
      }
      fullPath = fullPath.replace(/\\/g, '/'); // Normalize path separators
      
      // Check if this directory already exists in our database
      const existingDir = await db
        .select()
        .from(gcsDirectories)
        .where(eq(gcsDirectories.fullPath, fullPath));
      
      if (existingDir.length > 0) {
        return res.status(200).json(existingDir[0]);
      }
      
      // Check if this path matches a template (department + subdirectory)
      const templates = await db
        .select()
        .from(directoryTemplates)
        .where(
          and(
            eq(directoryTemplates.department, department),
            subDirectory 
              ? eq(directoryTemplates.subDirectory, subDirectory) 
              : eq(directoryTemplates.subDirectory, null as any)
          )
        );
      
      const isTemplateDirectory = templates.length > 0;
      
      // Only create the physical directory for custom directories not already in templates
      if (!isTemplateDirectory) {
        // Always create the physical directory in GCS
        const success = await gcsStorage.ensureDirectoryStructure(fullPath);
        if (!success) {
          return res.status(500).json({ error: 'Failed to create directory in GCS' });
        }
      }
      
      // For template directories, we still record the project-specific instance in the database,
      // but we don't need to create the actual GCS directory yet (will be created on first file upload)
      const [newDirectory] = await db
        .insert(gcsDirectories)
        .values({
          financialYear,
          projectCode,
          department,
          subDirectory,
          fullPath,
          createdBy: req.user?.id || 0, // Default to 0 if user id is not available
          isPublic: isTemplateDirectory ? templates[0].isPublic : false,
          updatedAt: new Date()
        })
        .returning();
      
      res.status(201).json(newDirectory);
    } catch (error) {
      console.error('Error creating directory:', error);
      res.status(500).json({ error: 'Failed to create directory' });
    }
  });

  /**
   * List files in a directory
   * Returns all files in the specified directory path
   */
  app.get('/api/storage/files', ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const { path, recursive } = req.query;
      
      if (!path) {
        return res.status(400).json({ error: 'Path parameter is required' });
      }
      
      const isRecursive = recursive === 'true' || recursive === '1';
      
      console.log(`Listing files in path: ${path} (recursive: ${isRecursive})`);
      
      const pathStr = path as string;
      const allowed = await enforceFileAccessControl(req, res, pathStr, 'list');
      if (!allowed) return;
      
      const isDrawingPath = 
        pathStr.includes('drawings') || 
        (pathStr.includes('THERMOPAC_INVENTORY') && /\d+/.test(pathStr)) ||
        /^4\d{3}/.test(pathStr) || // Starts with 4 followed by 3+ digits (drawing numbers pattern)
        /^\d{10,}/.test(pathStr);  // Drawing number pattern (10+ digits)
      
      if (isDrawingPath) {
        console.log(`This appears to be a drawing-related path: ${pathStr}, will search recursively`);
      }
      
      // Determine if this is a THERMOPAC_INVENTORY or THERMOPAC_PROJECTS path
      let fullPath = pathStr;
      
      // Don't add THERMOPAC_PROJECTS prefix if it's already a THERMOPAC_INVENTORY path
      if (pathStr.startsWith('THERMOPAC_INVENTORY/')) {
        console.log(`Using inventory path directly: ${pathStr}`);
        fullPath = pathStr;
      } 
      // Don't add prefix if it already has either THERMOPAC_PROJECTS or THERMOPAC_INVENTORY
      else if (!pathStr.startsWith('THERMOPAC_PROJECTS/') && !pathStr.startsWith('THERMOPAC_INVENTORY/')) {
        fullPath = `THERMOPAC_PROJECTS/${pathStr}`;
        console.log(`Modified path to include projects prefix: ${fullPath}`);
      }
      
      // Add more detailed logging
      const pathParts = fullPath.split('/');
      console.log(`Path components: ${JSON.stringify(pathParts)}`);
      
      // Ensure path doesn't have double slashes (common when combining paths)
      fullPath = fullPath.replace(/\/+/g, '/');
      console.log(`Normalized path (removed double slashes): ${fullPath}`);
      
      // Use the real GCS implementation - use recursive mode for drawing paths or when explicitly requested
      const files = await gcsStorage.listFiles(fullPath, isRecursive || isDrawingPath);
      console.log(`Found ${files.length} files in ${fullPath}`);
      
      // For drawing paths, if no files found with explicit path, try searching the parent directory
      if (isDrawingPath && files.length === 0 && fullPath.includes('/')) {
        // Go up one level in the path hierarchy
        const parentPath = fullPath.split('/').slice(0, -1).join('/');
        console.log(`No files found. Trying parent directory: ${parentPath}`);
        
        const parentFiles = await gcsStorage.listFiles(parentPath, true);
        console.log(`Found ${parentFiles.length} files in parent directory`);
        
        // Only return files that are related to the requested drawing path
        // This filters the results to include only relevant files
        const filteredFiles = parentFiles.filter(file => {
          const fileName = file.name || '';
          const filePath = file.path || '';
          
          // Extract drawing number from path using multiple patterns
          // Check for direct drawing number pattern (10+ digits)
          const drawingMatch = fullPath.match(/\d{10,}/);
          // Also check for directory structure patterns
          const drawingDirMatch = fullPath.match(/\/([^\/]+)\/drawings\//);
          // Also check for older patterns like /drawings/{drawingNo}/
          const oldDrawingDirMatch = fullPath.match(/\/drawings\/([^\/]+)\//);
          
          if (drawingMatch) {
            // Direct drawing number match (e.g., 4823002002001000)
            const drawingNo = drawingMatch[0];
            console.log(`Looking for drawing: ${drawingNo} in file: ${filePath}`);
            return filePath.includes(drawingNo);
          } else if (drawingDirMatch) {
            // Drawing directory structure match (e.g., /4823002002001000/drawings/)
            const drawingNo = drawingDirMatch[1];
            console.log(`Looking for drawing directory: ${drawingNo} in file: ${filePath}`);
            return filePath.includes(drawingNo);
          } else if (oldDrawingDirMatch) {
            // Old drawing directory structure match (e.g., /drawings/4823002002001000/)
            const drawingNo = oldDrawingDirMatch[1];
            console.log(`Looking for old drawing directory: ${drawingNo} in file: ${filePath}`);
            return filePath.includes(drawingNo);
          }
          return false;
        });
        
        if (filteredFiles.length > 0) {
          console.log(`Returning ${filteredFiles.length} relevant files from parent directory`);
          return res.status(200).json(filteredFiles);
        }
      }
      
      res.status(200).json(files);
    } catch (error) {
      console.error('Error listing files:', error);
      res.status(500).json({ error: 'Failed to list files' });
    }
  });

  /**
   * Generate upload URL for a file
   * Creates a signed URL for direct browser-to-GCS upload
   */
  app.post('/api/storage/upload-url', ensureAuthenticated, async (req: Request, res: Response) => {
    return res.status(403).json({
      error: 'Legacy File Storage is now read-only. All new documents must be uploaded through Document Control (TPEL structure).',
      code: 'LEGACY_STORAGE_LOCKED'
    });
    try {
      const { 
        financialYear, 
        projectCode, 
        department, 
        subDirectory, 
        fileName, 
        contentType 
      } = req.body;
      
      if (!financialYear || !projectCode || !department || !fileName || !contentType) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }
      
      const urlAccessPath = financialYear === 'THERMOPAC_INVENTORY'
        ? `THERMOPAC_INVENTORY/${projectCode}`
        : `THERMOPAC_PROJECTS/${financialYear}/${projectCode}`;
      const allowed = await enforceFileAccessControl(req, res, urlAccessPath, 'upload_url');
      if (!allowed) return;
      
      const storagePath = gcsStorage.buildStoragePath({
        financialYear,
        projectCode,
        department,
        subDirectory,
        fileName,
        contentType
      });
      
      // Generate a real signed URL
      const signedUrl = await gcsStorage.generateUploadSignedUrl({
        financialYear,
        projectCode,
        department,
        subDirectory,
        fileName,
        contentType
      });
      
      if (!signedUrl) {
        return res.status(500).json({ error: 'Failed to generate upload URL' });
      }
      
      res.status(200).json({ 
        signedUrl, 
        storagePath,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000) // 15 minutes
      });
    } catch (error) {
      console.error('Error generating upload URL:', error);
      res.status(500).json({ error: 'Failed to generate upload URL' });
    }
  });

  /**
   * Generate download URL for a file
   * Creates a signed URL for secure file download
   */
  app.get('/api/storage/download-url', ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const { filePath, expirationMinutes } = req.query;
      
      if (!filePath) {
        return res.status(400).json({ error: 'File path is required' });
      }
      
      const allowed = await enforceFileAccessControl(req, res, filePath as string, 'download');
      if (!allowed) return;
      
      const signedUrl = await gcsStorage.generateDownloadSignedUrl({
        filePath: filePath as string,
        expirationMinutes: expirationMinutes ? parseInt(expirationMinutes as string) : undefined
      });
      
      if (!signedUrl) {
        return res.status(404).json({ error: 'File not found or URL generation failed' });
      }
      
      res.status(200).json({ 
        downloadUrl: signedUrl,
        expiresAt: new Date(Date.now() + (parseInt(expirationMinutes as string) || 15) * 60 * 1000)
      });
    } catch (error) {
      console.error('Error generating download URL:', error);
      res.status(500).json({ error: 'Failed to generate download URL' });
    }
  });

  /**
   * Delete a file from GCS
   */
  app.delete('/api/storage/files', ensureAuthenticated, async (req: Request, res: Response) => {
    return res.status(403).json({
      error: 'Legacy File Storage is now read-only. File deletion must be managed through Document Control.',
      code: 'LEGACY_STORAGE_LOCKED'
    });
    try {
      const { filePath } = req.body;
      
      if (!filePath) {
        return res.status(400).json({ error: 'File path is required' });
      }
      
      const allowed = await enforceFileAccessControl(req, res, filePath, 'delete');
      if (!allowed) return;
      
      const success = await gcsStorage.deleteFile(filePath);
      
      if (!success) {
        return res.status(404).json({ error: 'File not found or deletion failed' });
      }
      
      // Always update database records regardless of environment
      await db
        .update(projectDocuments)
        .set({ storagePath: null, storageUrl: null, storageUrlExpiry: null })
        .where(eq(projectDocuments.storagePath, filePath));
      
      res.status(200).json({ message: 'File deleted successfully' });
    } catch (error) {
      console.error('Error deleting file:', error);
      res.status(500).json({ error: 'Failed to delete file' });
    }
  });

  /**
   * Upload a file directly to the server and then to GCS
   * For cases where direct browser-to-GCS upload isn't feasible
   */
  app.post('/api/storage/upload', ensureAuthenticated, upload.single('file'), async (req: Request, res: Response) => {
    return res.status(403).json({
      error: 'Legacy File Storage is now read-only. All new documents must be uploaded through Document Control (TPEL structure).',
      code: 'LEGACY_STORAGE_LOCKED'
    });
    try {
      // Add extensive debugging for production troubleshooting
      console.log('🔍 File upload initiated by user:', req.user?.username || 'Unknown');
      console.log('📁 File upload request body:', JSON.stringify(req.body, null, 2));
      console.log('📄 File details:', req.file ? 
        JSON.stringify({
          filename: req.file.originalname,
          size: req.file.size,
          mimetype: req.file.mimetype
        }, null, 2) : 'No file');
      
      // Check credentials for GCS
      console.log('☁️ GCS credentials check:', {
        projectId: process.env.GOOGLE_CLOUD_PROJECT_ID ? 'Present' : 'Missing',
        credentials: process.env.GOOGLE_CLOUD_CREDENTIALS ? 'Present' : 'Missing',
        bucketName: process.env.GOOGLE_CLOUD_BUCKET || 'thermopac_storage'
      });
      
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }
      
      const { 
        financialYear, 
        projectCode, 
        department, 
        subDirectory, 
        projectId,
        phaseId,
        description,
        type,
        isPublic
      } = req.body;
      
      if (financialYear && projectCode) {
        const uploadPath = financialYear === 'THERMOPAC_INVENTORY' 
          ? `THERMOPAC_INVENTORY/${projectCode}`
          : `THERMOPAC_PROJECTS/${financialYear}/${projectCode}`;
        const allowed = await enforceFileAccessControl(req, res, uploadPath, 'upload');
        if (!allowed) return;
      }
      
      const errors = [];
      if (!financialYear) errors.push('financialYear is required');
      if (!projectCode) errors.push('projectCode is required');
      if (!department && department !== '') errors.push('department field is required (can be empty string)');
      if (!projectId) errors.push('projectId is required');
      
      if (errors.length > 0) {
        console.log('❌ File upload validation errors:', errors);
        return res.status(400).json({ 
          error: 'Missing required parameters', 
          details: errors,
          received: { financialYear, projectCode, department, projectId }
        });
      }
      
      // Calculate the storage path
      const fileName = req.file.originalname;
      console.log(`File upload: Processing file ${fileName}`);
      console.log(`File upload: Parameters - FY: ${financialYear}, Project: ${projectCode}, Dept: ${department}, SubDir: ${subDirectory || 'none'}`);
      
      // Check for drawing revision pattern in filename (e.g., 4823002002001000_R0.PDF)
      const uploadRevisionMatch = fileName.match(/(.+)_R(\d+)\.(.+)/);
      if (uploadRevisionMatch && department === 'drawings') {
        const [, drawingNo, revisionStr] = uploadRevisionMatch;
        const revisionNum = parseInt(revisionStr, 10);
        
        // Check if this is a master item drawing by looking up the drawingNo in the database
        try {
          const foundItems = await db
            .select()
            .from(masterItems)
            .where(eq(masterItems.drawingNo, drawingNo));
          
          // If this is a master item, check the latest revision
          if (foundItems && foundItems.length > 0) {
            const masterItem = foundItems[0];
            const latestRevision = masterItem.latestRevision || 0;
            
            // If the upload revision is the same as the latest, throw an error
            if (revisionNum === latestRevision) {
              return res.status(409).json({ 
                error: `Drawing with revision ${revisionNum} already exists. Please use revision ${latestRevision + 1} or higher.`,
                suggestedRevision: latestRevision + 1,
                existingRevision: latestRevision
              });
            }
            
            // If the upload revision is higher, we'll update the master item later
          }
        } catch (err) {
          console.error('Error checking master item:', err);
          // Continue with the upload even if the check fails
        }
        
        // Double-check with GCS to make sure no file with this revision exists
        try {
          const existingFiles = await gcsStorage.listFiles(
            `${financialYear}/${projectCode}`,
            true
          );
          
          const existingRevisions = existingFiles.filter(file => {
            // Only check files with the same drawing number pattern
            const fileRevMatch = file.name.match(/(.+)_R(\d+)\.(.+)/);
            if (fileRevMatch) {
              const [, fileDrawingNo, fileRevStr] = fileRevMatch;
              return fileDrawingNo === drawingNo && parseInt(fileRevStr, 10) === revisionNum;
            }
            return false;
          });
          
          if (existingRevisions.length > 0) {
            return res.status(409).json({ 
              error: `Drawing with revision ${revisionNum} already exists. Please use a higher revision number.`,
              existingFile: existingRevisions[0].name
            });
          }
        } catch (err) {
          console.error('Error checking for existing revisions:', err);
          // Continue with the upload even if the check fails
        }
      }
      
      const storagePath = gcsStorage.buildStoragePath({
        financialYear,
        projectCode,
        department,
        subDirectory,
        fileName,
        contentType: req.file.mimetype
      });
      
      console.log(`File upload: Generated storage path: ${storagePath}`);
      
      // Ensure the directory structure exists in GCS
      const dirPath = path.dirname(storagePath);
      
      // First, check for an existing directory record in the database
      const dirComponents = dirPath.split('/');
      
      // Handle root folder prefix (THERMOPAC_PROJECTS or THERMOPAC_INVENTORY)
      const validPrefixes = ['THERMOPAC_PROJECTS', 'THERMOPAC_INVENTORY'];
      if (dirComponents.length >= 3 && validPrefixes.includes(dirComponents[0])) {
        const isInventory = dirComponents[0] === 'THERMOPAC_INVENTORY';
        
        // For inventory items, the structure is different
        // THERMOPAC_INVENTORY/drawingNo/department/... vs THERMOPAC_PROJECTS/financialYear/projectCode/department/...
        let financialYear, projectCode, department;
        let subDirectory = null;
        
        if (isInventory) {
          // For inventory items, we use THERMOPAC_INVENTORY as financialYear
          financialYear = 'THERMOPAC_INVENTORY';
          projectCode = dirComponents[1];
          department = dirComponents[2];
          
          // Subdirectory is anything beyond the 3rd level for inventory items
          if (dirComponents.length > 3) {
            subDirectory = dirComponents.slice(3).join('/');
          }
        } else {
          // For projects, keep the original structure
          financialYear = dirComponents[1];
          projectCode = dirComponents[2];
          department = dirComponents[3];
          
          // Subdirectory is anything beyond the 4th level for projects
          if (dirComponents.length > 4) {
            subDirectory = dirComponents.slice(4).join('/');
          }
        }
        
        // Look for an existing directory
        const existingDirs = await db
          .select()
          .from(gcsDirectories)
          .where(
            and(
              eq(gcsDirectories.financialYear, financialYear),
              eq(gcsDirectories.projectCode, projectCode),
              eq(gcsDirectories.department, department),
              subDirectory ? eq(gcsDirectories.subDirectory, subDirectory) : eq(gcsDirectories.subDirectory, null as any)
            )
          );
        
        // If no directory record exists, create one (which happens if we're uploading to a template directory)
        if (existingDirs.length === 0) {
          try {
            console.log(`Creating directory record for ${dirPath}`);
            
            // Check if it matches a template
            const templates = await db
              .select()
              .from(directoryTemplates)
              .where(
                and(
                  eq(directoryTemplates.department, department),
                  subDirectory 
                    ? eq(directoryTemplates.subDirectory, subDirectory) 
                    : eq(directoryTemplates.subDirectory, null as any)
                )
              );
            
            // Create the directory record
            await db
              .insert(gcsDirectories)
              .values({
                financialYear,
                projectCode,
                department,
                subDirectory,
                fullPath: dirPath,
                createdBy: req.user?.id || 0,
                isPublic: templates.length > 0 ? templates[0].isPublic : false,
                updatedAt: new Date()
              });
          } catch (error: any) {
            if (error.code === '23505' && error.constraint === 'gcs_directories_full_path_key') {
              // Duplicate directory record - this is fine, we can continue with the upload
              console.log(`Directory record already exists for ${dirPath}, continuing with upload`);
            } else {
              // Other error - re-throw
              throw error;
            }
          }
        }
      }
      
      let document;
      
      // Ensure the physical directory exists in GCS
      await gcsStorage.ensureDirectoryStructure(dirPath);
      
      console.log('Using direct upload method instead of streams for more reliable uploads');
      
      // Validate input
      if (!req.file) {
        throw new Error('No file provided for upload');
      }
      
      if (!req.file.buffer || req.file.buffer.length === 0) {
        throw new Error('File buffer is empty or undefined');
      }
      
      console.log(`Processing upload for file: ${fileName}, size: ${req.file.size} bytes, type: ${req.file.mimetype}`);
      
      // Upload with our enhanced upload function that has better error handling
      console.log(`Uploading file to ${storagePath} using uploadFileWithDiagnostics method`);
      
      // Import the enhanced upload function
      const { uploadFileWithDiagnostics } = require('./utils/gcs-enhanced-upload');
      
      // Use the enhanced upload function for better diagnostics
      const uploadResponse = await uploadFileWithDiagnostics(storagePath, req.file.buffer, req.file.mimetype);
      
      if (!uploadResponse.successful) {
        console.error('File upload failed:', JSON.stringify({
          error: uploadResponse.error,
          path: uploadResponse.path,
          environment: uploadResponse.environment,
          bucketDetails: uploadResponse.bucketDetails
        }, null, 2));
        
        // Import the bucketName from storage-config
        const { bucketName } = require('./utils/storage-config');
        
        // Determine if this is a typo or misconfiguration in the bucket name
        let suggestedFix = '';
        if (uploadResponse.bucketDetails?.configuredName !== uploadResponse.bucketDetails?.envVar &&
            uploadResponse.bucketDetails?.envVar?.includes('thermopac_s')) {
          suggestedFix = ` The environment variable GOOGLE_CLOUD_BUCKET has a typo: "${uploadResponse.bucketDetails.envVar}". Using "${uploadResponse.bucketDetails.name}" instead.`;
        }
        
        // Prepare error message based on the error type
        let errorMessage = 'Failed to upload file';
        let errorDetails = '';
        let errorSuggestion = '';
        let shouldRetry = false;
        
        // Handle different error types
        if (uploadResponse.error?.code === 403) {
          errorMessage = 'Permission denied';
          errorDetails = `Access denied when uploading to ${storagePath}.${suggestedFix}`;
          errorSuggestion = 'Please verify GCS credentials and permissions.';
          shouldRetry = false;
        } else if (uploadResponse.error?.code === 404) {
          errorMessage = 'Bucket not found';
          errorDetails = `Bucket "${bucketName}" does not exist or is not accessible.${suggestedFix}`;
          errorSuggestion = 'Please verify the bucket name is correct in the environment configuration.';
          shouldRetry = false;
        } else if (uploadResponse.error?.message?.includes('cannot be authenticated')) {
          errorMessage = 'Authentication failed';
          errorDetails = `GCS credentials could not be authenticated.${suggestedFix}`;
          errorSuggestion = 'Please check your Google Cloud credentials.';
          shouldRetry = false;
        } else if (
          uploadResponse.error?.message?.includes('ECONNRESET') || 
          uploadResponse.error?.message?.includes('ETIMEDOUT') ||
          uploadResponse.error?.message?.includes('network error') ||
          uploadResponse.error?.message?.includes('timeout')
        ) {
          errorMessage = 'Network error';
          errorDetails = `A network error occurred while uploading the file: ${uploadResponse.error.message}`;
          errorSuggestion = 'This may be a temporary issue. Please try again.';
          shouldRetry = true;
        } else {
          errorMessage = 'Upload failed';
          errorDetails = uploadResponse.error?.message || 'Unknown error occurred during upload';
          errorSuggestion = 'Please try again or contact support if the issue persists.';
          shouldRetry = true;
        }
        
        // Enhanced error response with detailed information
        return res.status(500).json({
          error: errorMessage,
          details: errorDetails,
          suggestion: errorSuggestion,
          environment: process.env.NODE_ENV || 'development',
          shouldRetry,
          bucketInfo: suggestedFix ? { 
            current: uploadResponse.bucketDetails?.envVar,
            corrected: uploadResponse.bucketDetails?.name
          } : undefined,
          path: storagePath
        });
      }
      
      console.log('Upload successful, download URL:', uploadResponse.url);
      const downloadUrl = uploadResponse.url;
      
      // Update the master item's latest revision if this is a drawing file
      const fileRevisionMatch = fileName.match(/(.+)_R(\d+)\.(.+)/);
      if (fileRevisionMatch && department === 'drawings') {
        const [, drawingNo, revisionStr] = fileRevisionMatch;
        const revisionNum = parseInt(revisionStr, 10);
        
        try {
          // Find the master item by drawing number
          const masterItemsList = await db
            .select()
            .from(masterItems)
            .where(eq(masterItems.drawingNo, drawingNo));
          
          // If we found a matching master item, update its latestRevision if this revision is higher
          if (masterItemsList && masterItemsList.length > 0) {
            const masterItem = masterItemsList[0];
            const currentLatestRevision = masterItem.latestRevision || 0;
            
            // Only update if the new revision is higher
            if (revisionNum > currentLatestRevision) {
              console.log(`Updating master item ${masterItem.id} latest revision from ${currentLatestRevision} to ${revisionNum}`);
              
              await db
                .update(masterItems)
                .set({
                  latestRevision: revisionNum,
                  updatedAt: new Date()
                })
                .where(eq(masterItems.id, masterItem.id));
            }
          }
        } catch (error) {
          console.error('Error updating master item revision:', error);
          // Don't fail the upload if this update fails
        }
      }
      
      // Create a document record in the database
      try {
        const [doc] = await db
          .insert(projectDocuments)
          .values({
            projectId: parseInt(projectId),
            phaseId: phaseId ? parseInt(phaseId) : undefined,
            name: fileName,
            description: description || '',
            type: type || 'document',
            url: downloadUrl || '',
            uploadedBy: req.user?.id as number,
            size: req.file?.size || 0,
            format: path.extname(fileName).replace('.', ''),
            isPublic: isPublic === 'true',
            storagePath,
            storageUrl: downloadUrl || null,
            storageUrlExpiry: downloadUrl ? new Date(Date.now() + 60 * 60 * 1000) : null // 1 hour
          })
          .returning();
        
        document = doc;
      } catch (dbError) {
        console.error("Error inserting document record:", dbError);
        // Return a basic document object so the client still gets a success response
        // The file is already uploaded to GCS successfully at this point
        document = {
          id: 0,
          projectId: parseInt(projectId),
          name: fileName,
          description: description || '',
          storagePath,
          storageUrl: downloadUrl || null
        };
      }
      
      res.status(201).json(document);
    } catch (error: any) {
      console.error('Error uploading file:', error);
      
      if (error?.code === '23505' && error?.constraint === 'gcs_directories_full_path_key') {
        // This is a known error with duplicate directories - we can continue
        console.log('Duplicate directory error - this is expected for drawings. Trying to recover...');
        
        // The file might still have been uploaded successfully, so try to check
        try {
          // Get the parameters that were passed to the upload
          const uploadFinancialYear = req.body.financialYear as string;
          const uploadProjectCode = req.body.projectCode as string;
          const uploadDepartment = req.body.department as string;
          const uploadProjectId = req.body.projectId as string;
          const uploadFileName = req.file?.originalname || 'unknown-file.pdf';
          const uploadDescription = req.body.description as string || '';
          
          // Recreate the storage path
          const recalculatedPath = `${uploadFinancialYear}/${uploadProjectCode}/${uploadDepartment}/${uploadFileName}`;
          
          // Create a simplified document object for the response
          const tempDocument = {
            id: 0,
            projectId: parseInt(uploadProjectId || '0'),
            name: uploadFileName,
            description: uploadDescription,
            storagePath: recalculatedPath,
            storageUrl: null
          };
          
          res.status(201).json(tempDocument);
          return;
        } catch (innerError) {
          console.error('Recovery failed:', innerError);
        }
      }
      
      // Import the bucketName
      const { bucketName } = require('./utils/storage-config');
      
      // If we got here, we couldn't recover
      // Provide more specific error information based on error type
      if (error.code === 403) {
        console.error('GCS permission error - check IAM roles and bucket permissions');
        res.status(500).json({ 
          error: 'Permission denied while uploading file',
          details: 'The server does not have permission to write to the storage bucket',
          suggestion: 'Please contact support to verify Google Cloud Storage permissions',
          shouldRetry: false  // No point retrying permission issues
        });
      } else if (error.code === 404) {
        console.error(`GCS bucket not found - check bucket name configuration. Current bucket: ${bucketName}`);
        res.status(500).json({ 
          error: 'Storage bucket not found',
          details: `The configured storage bucket "${bucketName}" does not exist or is not accessible`,
          suggestion: 'Please contact support to verify Google Cloud Storage configuration',
          shouldRetry: false  // No point retrying with wrong bucket name
        });
      } else if (error.message && (
          error.message.includes('ENOTFOUND') || 
          error.message.includes('ENETUNREACH') || 
          error.message.includes('ETIMEDOUT')
      )) {
        console.error('Network error during upload - may be transient');
        res.status(500).json({ 
          error: 'Cannot connect to storage service',
          details: 'Network connection to Google Cloud Storage failed',
          suggestion: 'Please try again in a few moments',
          shouldRetry: true,  // Network errors are often transient and should be retried
          retryDelay: 3000    // Suggest retrying after 3 seconds
        });
      } else if (error.message && error.message.includes('Bucket')) {
        console.error(`GCS bucket error: ${error.message}`);
        res.status(500).json({ 
          error: 'Storage bucket configuration error',
          details: `Problem with storage bucket "${bucketName}": ${error.message}`,
          suggestion: 'Please contact support to verify Google Cloud Storage configuration',
          shouldRetry: false  // No point retrying bucket configuration issues
        });
      } else if (error.message && (
          error.message.includes('credentials') || 
          error.message.includes('authentication') || 
          error.message.includes('auth')
      )) {
        console.error('GCS authentication error');
        res.status(500).json({ 
          error: 'Storage authentication error',
          details: 'Failed to authenticate with Google Cloud Storage',
          suggestion: 'Please contact support to verify Google Cloud Storage credentials',
          shouldRetry: false  // No point retrying authentication issues
        });
      } else {
        // Generic error
        // Classify the error type for more intelligent retry decisions
        const errorMessage = error.message || 'Unknown error';
        
        // Connection reset errors - these are definitely retriable
        if (errorMessage.includes('ECONNRESET') || errorMessage.includes('socket hang up')) {
          console.error(`Connection reset during upload: ${errorMessage}`);
          res.status(500).json({
            error: 'Connection interrupted',
            errorCode: error.code || 'ECONNRESET',
            errorMessage: errorMessage,
            details: 'The connection was reset while uploading the file',
            suggestion: 'This is likely a transient network issue',
            shouldRetry: true,
            retryDelay: 2000 // Quick retry for connection resets
          });
        } 
        // Rate limiting or server overload - retriable with longer backoff
        else if (error.code === 429 || errorMessage.includes('Too many requests') || errorMessage.includes('rate limit')) {
          console.error(`Rate limit or server overload during upload: ${errorMessage}`);
          res.status(429).json({
            error: 'Upload rate limit exceeded',
            errorCode: error.code || 429,
            errorMessage: errorMessage,
            details: 'The server is processing too many uploads right now',
            suggestion: 'Please wait a moment before retrying',
            shouldRetry: true,
            retryDelay: 10000 // Longer delay for rate limiting
          });
        }
        // GCS timeout errors - retriable with medium backoff
        else if (errorMessage.includes('timeout') || errorMessage.includes('timed out')) {
          console.error(`Timeout during upload: ${errorMessage}`);
          res.status(500).json({
            error: 'Upload operation timed out',
            errorCode: error.code || 'TIMEOUT',
            errorMessage: errorMessage,
            details: 'The upload operation took too long to complete',
            suggestion: 'This could be due to file size or network conditions',
            shouldRetry: true,
            retryDelay: 5000 // Medium delay for timeouts
          });
        }
        // File validation errors - not retriable
        else if (errorMessage.includes('validation') || errorMessage.includes('invalid file')) {
          console.error(`File validation error: ${errorMessage}`);
          res.status(400).json({
            error: 'Invalid file',
            errorCode: error.code || 'VALIDATION_ERROR',
            errorMessage: errorMessage,
            details: 'The file did not pass validation checks',
            suggestion: 'Please check the file format and try again with a valid file',
            shouldRetry: false
          });
        }
        // Other server-side errors - may be retriable
        else {
          // Generic server error - default to retriable with our best guess about whether it's worth retrying
          const isLikelyRetriable = 
            !errorMessage.includes('permission') && 
            !errorMessage.includes('access') && 
            !errorMessage.includes('not found') &&
            !errorMessage.includes('invalid') &&
            !errorMessage.includes('corruption') &&
            (error.code === undefined || error.code >= 500 || typeof error.code !== 'number');
          
          console.error(`Generic upload error: ${errorMessage}`, {
            stack: error.stack,
            code: error.code,
            isLikelyRetriable
          });
          
          res.status(500).json({ 
            error: 'Failed to upload file',
            errorCode: error.code,
            errorMessage: errorMessage,
            details: 'An unexpected error occurred during upload',
            suggestion: isLikelyRetriable 
              ? 'This may be a temporary issue, please try again'
              : 'Please check your file and try again with a different file if the issue persists',
            shouldRetry: isLikelyRetriable,
            retryDelay: isLikelyRetriable ? 5000 : 0
          });
        }
      }
    }
  });
  
  /**
   * Diagnose GCS permissions issues
   * This endpoint runs a comprehensive check of GCS permissions and configuration
   * to help troubleshoot file upload issues in different environments
   */
  app.get('/api/storage/check-permissions', ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      console.log('Running GCS permissions check...');
      
      // Check if the user has the necessary role to access this endpoint
      if (req.user && (req.user as any).role !== 'Superuser') {
        return res.status(403).json({ 
          error: 'Access denied', 
          message: 'Only Superusers can access this diagnostic endpoint' 
        });
      }
      
      const permissionsResult = await checkGcsPermissions();
      
      // Extract service account email from credentials for diagnostics
      let serviceAccountEmail = null;
      let credentialType = 'unknown';
      let credentialProjectId = null;
      
      if (process.env.GOOGLE_CLOUD_CREDENTIALS) {
        try {
          const credentials = JSON.parse(process.env.GOOGLE_CLOUD_CREDENTIALS);
          serviceAccountEmail = credentials.client_email;
          credentialType = credentials.type || 'missing-type';
          credentialProjectId = credentials.project_id;
        } catch (e) {
          credentialType = 'parse-error';
        }
      }
      
      // Add additional environment information
      const environmentInfo = {
        nodeEnv: process.env.NODE_ENV || 'development',
        googleBucketEnvVar: process.env.GOOGLE_CLOUD_BUCKET || '(not set)',
        correctedBucketName: bucketName,
        hasGoogleCredentials: !!process.env.GOOGLE_CLOUD_CREDENTIALS,
        credentialsLength: process.env.GOOGLE_CLOUD_CREDENTIALS ? 
          process.env.GOOGLE_CLOUD_CREDENTIALS.length : 0,
        credentialType: credentialType,
        serviceAccountEmail: serviceAccountEmail,
        credentialProjectId: credentialProjectId,
        googleProjectIdEnv: process.env.GOOGLE_CLOUD_PROJECT_ID || '(not set)',
        hostname: req.headers.host,
        serverStartTime: new Date().toISOString(),
        runningEnvironment: process.env.REPLIT_ENVIRONMENT || process.env.ENVIRONMENT || '(not replit)',
        hasGoogleClientId: !!process.env.GOOGLE_CLIENT_ID,
        hasGoogleClientSecret: !!process.env.GOOGLE_CLIENT_SECRET,
        hasGoogleRedirectUri: !!process.env.GOOGLE_REDIRECT_URI,
        deploymentType: process.env.REPLIT_DEPLOYMENT_TYPE || '(not deployed)',
        fixedBucketName: process.env.GOOGLE_CLOUD_BUCKET ? 
          process.env.GOOGLE_CLOUD_BUCKET.trim() : '(not set)'
      };

      // Generate actionable suggestions based on the results
      const suggestions: string[] = [];
      
      // Check for credential issues
      if (!process.env.GOOGLE_CLOUD_CREDENTIALS) {
        suggestions.push('GOOGLE_CLOUD_CREDENTIALS environment variable is missing. Add service account credentials in JSON format.');
      } else if (!process.env.GOOGLE_CLOUD_PROJECT_ID) {
        suggestions.push('GOOGLE_CLOUD_PROJECT_ID environment variable is missing.');
      }
      
      // Check for bucket issues
      if (!permissionsResult.permissions.bucketExists) {
        suggestions.push(`Bucket "${permissionsResult.environment.bucketName}" does not exist or the service account lacks access. Create the bucket or grant Storage Object Admin role.`);
      } else {
        if (!permissionsResult.permissions.canListFiles) {
          suggestions.push('Service account lacks permission to list files. Grant Storage Object Viewer role.');
        }
        if (!permissionsResult.permissions.canUploadFiles) {
          suggestions.push('Service account lacks permission to upload files. Grant Storage Object Creator role.');
        }
      }
      
      // Add suggestion about development vs production
      if (process.env.NODE_ENV === 'production' && !permissionsResult.success) {
        suggestions.push('Consider using the same GCS service account and configuration from the Development environment, where file uploads are working correctly.');
      }
      
      res.status(200).json({
        success: permissionsResult.success,
        permissions: permissionsResult.permissions,
        environment: permissionsResult.environment,
        suggestions: suggestions,
        errors: permissionsResult.errors,
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error('Error checking GCS permissions:', error);
      res.status(500).json({ 
        error: 'Failed to check GCS permissions',
        message: error.message,
        stack: process.env.NODE_ENV !== 'production' ? error.stack : undefined
      });
    }
  });

  return app;
}