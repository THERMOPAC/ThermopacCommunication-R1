import express, { Request, Response } from 'express';
import { storage } from './storage';
import { getGmailClient, getAuthUrl } from './google-auth';
import { getTokens, sanitizeAuthCode } from './google-oauth';
import { gmail_v1 } from 'googleapis';
import { analyzeEmail, generateEmailReplies } from './openai-email-service';
import { emailClassifier } from './email-classifier';

// Sync progress tracking
interface SyncProgress {
  userId: number;
  status: 'running' | 'completed' | 'error';
  total: number;
  processed: number;
  synced: number;
  errors: number;
  startTime: Date;
  endTime?: Date;
  errorMessage?: string;
}

const syncProgressStore = new Map<number, SyncProgress>();

export function setupGmailRoutes(app: express.Express) {
  // Get sync progress
  app.get('/api/gmail/sync/progress', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const progress = syncProgressStore.get(req.user!.id);
    
    if (!progress) {
      return res.json({ status: 'idle' });
    }
    
    return res.json(progress);
  });
  // Manual authentication endpoint for Gmail
  app.post('/api/gmail/manual-auth', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      console.log('=== MANUAL GMAIL AUTHENTICATION ===');
      console.log(`User ${req.user!.username} (ID: ${req.user!.id}) attempting manual authentication`);
      
      const { code } = req.body;
      
      if (!code) {
        console.error('No code provided in request body');
        return res.status(400).json({ error: 'Authorization code is required' });
      }
      
      console.log(`Raw input code length: ${code.length}`);
      
      // Clean the code to extract the authorization code
      const cleanCode = sanitizeAuthCode(code);
      console.log(`Cleaned code length: ${cleanCode.length}`);
      
      if (!cleanCode || cleanCode.length < 20) {
        console.error('Invalid authorization code after cleaning');
        return res.status(400).json({ 
          error: 'Invalid authorization code', 
          details: 'The code could not be extracted from your input. Please make sure to copy the full URL after Google authorization.'
        });
      }
      
      // Exchange the code for tokens
      console.log(`Attempting to exchange manual auth code for user: ${req.user!.id}`);
      const tokens = await getTokens(cleanCode);
      
      if (!tokens) {
        console.error('No tokens returned from getTokens');
        return res.status(400).json({ error: 'Failed to exchange authorization code for tokens' });
      }
      
      console.log('Token exchange successful:');
      console.log('- Access token received:', !!tokens.access_token);
      console.log('- Refresh token received:', !!tokens.refresh_token);
      
      // Save the tokens in database
      await storage.saveGoogleTokens(req.user!.id, tokens);
      
      console.log(`Successfully saved Google tokens for user ${req.user!.id} via manual auth`);
      res.json({ 
        success: true, 
        message: 'Gmail connected successfully!'
      });
    } catch (error) {
      console.error('=== MANUAL AUTH ERROR ===');
      console.error('Error details:', error);
      
      let errorMessage = 'Authentication failed';
      let errorDetails = '';
      
      if (error instanceof Error) {
        errorMessage = error.message;
        console.error('Error message:', errorMessage);
        console.error('Error stack:', error.stack);
        
        // Check for specific error types
        if (errorMessage.includes('invalid_grant')) {
          errorDetails = 'The authorization code has expired or has already been used. Please try again with a new authorization.';
        } else if (errorMessage.includes('redirect_uri_mismatch')) {
          errorDetails = 'The redirect URI doesn\'t match what\'s configured in Google Cloud Console.';
        } else if (errorMessage.includes('invalid_request')) {
          errorDetails = 'The request was malformed. Please ensure you\'re copying the complete URL after authorization.';
        }
      }
      
      res.status(500).json({ 
        error: errorMessage,
        details: errorDetails || 'An unexpected error occurred during OAuth authentication'
      });
    }
  });
  
  // Direct redirect to Google OAuth for Gmail (simpler flow without popups)
  app.get('/api/gmail/auth-url-redirect', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.redirect('/login?message=Please+login+first');
    }
    
    try {
      console.log('=== INITIATING GMAIL OAUTH REDIRECT ===');
      console.log(`User ${req.user!.username} (ID: ${req.user!.id}) initiating Gmail OAuth`);
      
      // Store the user ID in the session to help with redirects
      req.session.gmailAuthUser = req.user!.id;
      
      // Save the session before proceeding
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) {
            console.error('Error saving session before Gmail auth:', err);
            reject(err);
          } else {
            console.log('Session saved successfully with ID:', req.sessionID);
            resolve();
          }
        });
      });
      
      // Generate the OAuth URL
      const authUrl = getAuthUrl(req.user!.id);
      
      console.log('Redirecting to Google OAuth...');
      
      // Redirect directly to Google OAuth
      res.redirect(authUrl);
    } catch (error) {
      console.error('Error initiating Gmail OAuth:', error);
      res.redirect('/emails?error=oauth_init_failed');
    }
  });
  
  // Get Gmail auth URL for connecting account
  app.get('/api/gmail/auth-url', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      console.log('=== GENERATING GMAIL AUTH URL ===');
      console.log(`User ${req.user!.username} (ID: ${req.user!.id}) requesting Gmail auth URL`);
      
      // Store the user ID in the session to help with redirects
      req.session.gmailAuthUser = req.user!.id;
      
      // Save the session before proceeding
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) {
            console.error('Error saving session before Gmail auth:', err);
            reject(err);
          } else {
            console.log('Session saved successfully with ID:', req.sessionID);
            resolve();
          }
        });
      });
      
      // Use the auth utility to generate the URL - with fallback credentials if needed
      const authUrl = getAuthUrl(req.user!.id);
      
      // Log the auth operation
      console.log('Auth URL generated and returning to client');
      
      // Return the URL to the client
      res.json({ 
        url: authUrl,
        sessionId: req.sessionID, // Include session ID for debugging
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error generating auth URL:', error);
      let errorMessage = 'Failed to generate authentication URL';
      
      if (error instanceof Error) {
        console.error('Detailed error message:', error.message);
        console.error('Error stack:', error.stack);
        errorMessage = error.message;
      }
      
      res.status(500).json({ 
        error: errorMessage,
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // Check if user has connected Gmail
  app.get('/api/gmail/status', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      const token = await storage.getGmailToken(req.user!.id);
      res.json({ connected: !!token });
    } catch (error) {
      console.error('Error checking Gmail connection status:', error);
      res.status(500).json({ error: 'Failed to check Gmail connection status' });
    }
  });
  
  // Disconnect Gmail
  app.post('/api/gmail/disconnect', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      await storage.deleteGmailToken(req.user!.id);
      res.json({ success: true });
    } catch (error) {
      console.error('Error disconnecting Gmail:', error);
      res.status(500).json({ error: 'Failed to disconnect Gmail' });
    }
  });
  // Fetch Gmail messages for authenticated user
  app.get('/api/gmail/messages', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const userId = req.user!.id;
    
    try {
      // Check if user has configured Gmail first
      const token = await storage.getGmailToken(userId);
      if (!token) {
        return res.status(400).json({ error: 'Gmail not connected. Please connect your Gmail account first.' });
      }

      // Set up filters
      const filters: any = {};
      
      console.log('Request Query Params:', req.query);
      
      if (req.query.isRead !== undefined) {
        // Make sure we properly convert to boolean
        const isReadParam = req.query.isRead;
        // String-only comparison since query params are always strings
        filters.isRead = isReadParam === 'true';
        console.log('Setting isRead filter to:', filters.isRead, 'from value:', req.query.isRead, 'type:', typeof req.query.isRead);
      }
      
      // Add a safety filter to never return messages with SPAM label
      filters.excludeSpam = true;
      
      if (req.query.isImportant !== undefined) {
        filters.isImportant = req.query.isImportant === 'true';
      }
      
      // Add priority filter support
      if (req.query.priority) {
        const priorityValue = req.query.priority;
        if (Array.isArray(priorityValue)) {
          filters.priority = priorityValue;
        } else if (typeof priorityValue === 'string') {
          // Support comma-separated values like "P0,P1"
          filters.priority = priorityValue.split(',').map(p => p.trim());
        }
        console.log('Setting priority filter to:', filters.priority);
      }
      
      if (req.query.from) {
        filters.from = req.query.from as string;
      }
      
      if (req.query.to) {
        filters.to = req.query.to as string;
      }
      
      if (req.query.subject) {
        filters.subject = req.query.subject as string;
      }
      
      // Handle date filters
      if (req.query.startDate) {
        filters.startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        filters.endDate = new Date(req.query.endDate as string);
      }
      
      // Retrieve messages from database
      const messages = await storage.getGmailMessagesForUser(userId, filters);
      
      // Return messages
      res.json(messages);
    } catch (error) {
      console.error('Error fetching Gmail messages:', error);
      res.status(500).json({ error: 'Failed to fetch Gmail messages' });
    }
  });

  // Mark message as read/unread
  app.patch('/api/gmail/messages/:id/read', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const messageId = parseInt(req.params.id);
    const { isRead } = req.body;
    
    if (isRead === undefined) {
      return res.status(400).json({ error: 'isRead is required' });
    }
    
    try {
      // Update message in the database
      const message = await storage.updateGmailMessage(messageId, { isRead });
      
      // Also update in Gmail if connected
      try {
        const gmail = await getGmailClient(req.user!.id);
        const labels = isRead ? { removeLabelIds: ['UNREAD'] } : { addLabelIds: ['UNREAD'] };
        console.log(`Updating Gmail message ${message.messageId} read status: ${isRead ? 'marking as read (removing UNREAD)' : 'marking as unread (adding UNREAD)'}`);
        
        const result = await gmail.users.messages.modify({
          userId: 'me',
          id: message.messageId,
          requestBody: labels
        });
        
        console.log(`✅ Successfully updated Gmail message ${message.messageId} read status in Gmail`);
      } catch (error) {
        console.error('❌ Failed to update read status in Gmail:', error);
        console.error('Error details:', error instanceof Error ? error.message : error);
        // Continue anyway as we've updated the local database
      }
      
      res.json(message);
    } catch (error) {
      console.error('Error updating message read status:', error);
      res.status(500).json({ error: 'Failed to update message read status' });
    }
  });

  // Mark message as important/not important
  app.patch('/api/gmail/messages/:id/important', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const messageId = parseInt(req.params.id);
    const { isImportant } = req.body;
    
    if (isImportant === undefined) {
      return res.status(400).json({ error: 'isImportant is required' });
    }
    
    try {
      // Update message in the database
      const message = await storage.updateGmailMessage(messageId, { isImportant });
      
      // Also update in Gmail if connected
      try {
        const gmail = await getGmailClient(req.user!.id);
        const labels = isImportant ? { addLabelIds: ['IMPORTANT'] } : { removeLabelIds: ['IMPORTANT'] };
        await gmail.users.messages.modify({
          userId: 'me',
          id: message.messageId,
          requestBody: labels
        });
      } catch (error) {
        console.warn('Could not update important status in Gmail:', error);
        // Continue anyway as we've updated the local database
      }
      
      res.json(message);
    } catch (error) {
      console.error('Error updating message important status:', error);
      res.status(500).json({ error: 'Failed to update message important status' });
    }
  });

  // Get Gmail settings for user
  app.get('/api/gmail/settings', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      const settings = await storage.getGmailSettings(req.user!.id);
      if (!settings) {
        // Create default settings if none exist
        const newSettings = await storage.saveGmailSettings({
          userId: req.user!.id,
          autoSyncEnabled: true,
          syncFrequencyMinutes: 30,
          autoForwardRules: []
        });
        return res.json(newSettings);
      }
      
      res.json(settings);
    } catch (error) {
      console.error('Error fetching Gmail settings:', error);
      res.status(500).json({ error: 'Failed to fetch Gmail settings' });
    }
  });

  // Update Gmail settings
  app.patch('/api/gmail/settings', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const { autoSyncEnabled, syncFrequencyMinutes, autoForwardRules } = req.body;
    const updateData: any = {};
    
    if (autoSyncEnabled !== undefined) {
      updateData.autoSyncEnabled = autoSyncEnabled;
    }
    
    if (syncFrequencyMinutes !== undefined) {
      updateData.syncFrequencyMinutes = syncFrequencyMinutes;
    }
    
    if (autoForwardRules !== undefined) {
      updateData.autoForwardRules = autoForwardRules;
    }
    
    try {
      // Check if settings exist
      let settings = await storage.getGmailSettings(req.user!.id);
      
      if (!settings) {
        // Create new settings if none exist
        settings = await storage.saveGmailSettings({
          userId: req.user!.id,
          ...updateData,
          autoSyncEnabled: updateData.autoSyncEnabled !== undefined ? updateData.autoSyncEnabled : true,
          syncFrequencyMinutes: updateData.syncFrequencyMinutes !== undefined ? updateData.syncFrequencyMinutes : 30,
          autoForwardRules: updateData.autoForwardRules || []
        });
      } else {
        // Update existing settings
        settings = await storage.updateGmailSettings(req.user!.id, updateData);
      }
      
      res.json(settings);
    } catch (error) {
      console.error('Error updating Gmail settings:', error);
      res.status(500).json({ error: 'Failed to update Gmail settings' });
    }
  });
  
  // Delete Gmail message
  app.delete('/api/gmail/messages/:id', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const messageId = parseInt(req.params.id);
    
    if (isNaN(messageId)) {
      return res.status(400).json({ error: 'Invalid message ID' });
    }
    
    try {
      // First, get the message to check if it belongs to the user and to get the Gmail message ID
      const message = await storage.getGmailMessage(messageId);
      
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }
      
      // Debug message ownership
      console.log(`Message delete check: Message userId: ${message.userId}, Current user id: ${req.user!.id}, Match: ${message.userId === req.user!.id}`);
      
      // ALLOW ALL USERS WITH ID 3 (SUPERUSER) TO DELETE ANY MESSAGE
      // This fixes the data synchronization issue with imported emails
      if (message.userId !== req.user!.id && req.user!.id !== 3) {
        return res.status(403).json({ error: 'You do not have permission to delete this message' });
      }
      
      // First delete from the database
      await storage.deleteGmailMessage(messageId);
      
      // Then try to delete from Gmail if connected (but don't block if it fails)
      try {
        const gmail = await getGmailClient(req.user!.id);
        console.log(`🗑️ Attempting to move Gmail message ${message.messageId} to trash in Gmail...`);
        
        await gmail.users.messages.trash({
          userId: 'me',
          id: message.messageId
        });
        
        console.log(`✅ Successfully moved Gmail message ${message.messageId} to trash in Gmail`);
      } catch (error) {
        console.error('❌ Failed to delete message in Gmail (but deleted from local database):', error);
        console.error('Error details:', error instanceof Error ? error.message : error);
        // This is ok - message is already deleted from local database
      }
      
      // Return success regardless of Gmail API result
      res.json({ success: true, message: 'Email message deleted successfully from the system' });
    } catch (error) {
      console.error('Error deleting Gmail message:', error);
      res.status(500).json({ error: 'Failed to delete Gmail message' });
    }
  });

  // Trigger manual sync
  app.post('/api/gmail/sync', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    try {
      console.log('Starting Gmail sync for user:', req.user!.id);
      
      // Initialize progress tracking
      syncProgressStore.set(req.user!.id, {
        userId: req.user!.id,
        status: 'running',
        total: 0,
        processed: 0,
        synced: 0,
        errors: 0,
        startTime: new Date()
      });
      
      const token = await storage.getGmailToken(req.user!.id);
      if (!token) {
        console.log('No Gmail token found for user:', req.user!.id);
        syncProgressStore.delete(req.user!.id);
        return res.status(400).json({ error: 'Gmail not connected. Please connect your Gmail account first.' });
      }
      
      console.log('Gmail token found:', {
        userId: token.userId,
        tokenAge: token.updatedAt ? `${Math.floor((Date.now() - new Date(token.updatedAt).getTime()) / (1000 * 60))} minutes` : 'unknown',
        hasAccessToken: !!token.accessToken,
        hasRefreshToken: !!token.refreshToken,
        tokenExpiry: token.tokenExpiry ? new Date(token.tokenExpiry).toISOString() : 'none'
      });
      
      let gmail: any;
      let messageIds: string[] = [];
      
      try {
        console.log('Attempting to get Gmail client for user:', req.user!.id);
        
        try {
          gmail = await getGmailClient(req.user!.id);
        } catch (error: any) {
          console.error('Failed to initialize Gmail client:', error);
          throw new Error(`Failed to initialize Gmail client: ${error.message || 'Unknown error'}`);
        }
        
        console.log('Gmail client initialized successfully');
        
        // Get existing messages first to filter out duplicates
        const existingMessages = await storage.getGmailMessagesForUser(req.user!.id, {});
        const existingMessageIds = new Set(existingMessages.map(m => m.messageId));
        
        // Fetch messages with pagination until we get enough new messages or run out
        let pageToken: string | undefined = undefined;
        let totalFetched = 0;
        const maxPages = 10; // Fetch up to 10 pages (500 messages max)
        let pagesChecked = 0;
        
        do {
          try {
            // Fetch only unread inbox emails (excluding spam and trash)
            const response: any = await gmail.users.messages.list({
              userId: 'me',
              maxResults: 50,
              q: 'in:inbox -in:spam -in:trash is:unread',
              pageToken: pageToken
            });
            console.log(`Gmail API messages.list request successful (page ${pagesChecked + 1})`);
            
            const messages = response.data.messages || [];
            
            if (messages.length === 0) {
              console.log('No more messages found in Gmail');
              break;
            }
            
            // Filter for new messages only
            const newMessagesInBatch = messages.filter((m: any) => !existingMessageIds.has(m.id));
            const newIds = newMessagesInBatch.map((m: any) => m.id).filter(Boolean) as string[];
            
            messageIds.push(...newIds);
            totalFetched += messages.length;
            
            console.log(`Page ${pagesChecked + 1}: Found ${messages.length} messages, ${newIds.length} are new (total new: ${messageIds.length})`);
            
            // Get next page token
            pageToken = response.data.nextPageToken;
            pagesChecked++;
            
            // Stop if we found enough new messages or no more pages
            if (messageIds.length >= 50 || !pageToken) {
              break;
            }
            
          } catch (apiError) {
            console.error('Gmail API messages.list request failed:', apiError);
            throw apiError;
          }
        } while (pageToken && pagesChecked < maxPages);
        
        console.log(`Pagination complete: Checked ${pagesChecked} pages, ${totalFetched} total messages, found ${messageIds.length} new messages`);
        
        if (messageIds.length === 0) {
          console.log('No new messages to sync for user:', req.user!.id);
          return res.json({ messageCount: 0, message: 'No new messages found. All recent emails are already synced.' });
        }
      } catch (apiError: any) {
        console.error('Gmail API Error:', apiError);
        
        // Check if this is an API not enabled error
        if (apiError.message && apiError.message.includes('Gmail API has not been used in project') &&
            apiError.message.includes('or it is disabled')) {
          
          // Extract the project ID and console URL from the error message if available
          const projectIdMatch = apiError.message.match(/project (\d+)/);
          const projectId = projectIdMatch ? projectIdMatch[1] : 'your Google Cloud project';
          
          const consoleUrlMatch = apiError.message.match(/(https:\/\/console\.developers\.google\.com\/apis\/api\/gmail\.googleapis\.com\/overview\?project=\d+)/);
          const consoleUrl = consoleUrlMatch ? consoleUrlMatch[1] : 'https://console.cloud.google.com/apis/library/gmail.googleapis.com';
          
          return res.status(400).json({ 
            error: 'Gmail API not enabled or still activating',
            message: `The Gmail API needs to be enabled in your Google Cloud project (${projectId}). If you've already enabled it, please wait 5-10 minutes for the changes to fully propagate through Google's systems. You can verify the API is enabled at ${consoleUrl}`
          });
        }
        
        // Handle other API errors with appropriate messages
        return res.status(400).json({
          error: 'Gmail API error',
          message: apiError.message || 'An error occurred while communicating with the Gmail API'
        });
      }
      
      const syncedMessages = [];
      const errors: { messageId: string; error: string }[] = [];
      
      // Helper function to process a single message
      const processMessage = async (messageId: string) => {
        try {
          console.log(`Processing message ${messageId} for user:`, req.user!.id);
          
          // Fetch full message details
          const messageDetails = await gmail.users.messages.get({
            userId: 'me',
            id: messageId,
            format: 'full',
          });
          
          const payload = messageDetails.data.payload;
          if (!payload) {
            console.log(`No payload found for message ${messageId}`);
            return { success: false, messageId, error: 'No payload found' };
          }
          
          // Extract headers
          const headers = payload.headers || [];
          const fromHeader = headers.find((h: any) => h.name?.toLowerCase() === 'from');
          const toHeader = headers.find((h: any) => h.name?.toLowerCase() === 'to');
          const subjectHeader = headers.find((h: any) => h.name?.toLowerCase() === 'subject');
          const dateHeader = headers.find((h: any) => h.name?.toLowerCase() === 'date');
          
          // Extract message body - prefer HTML, fallback to plain text
          const extractBody = (parts: any[]): { html: string, plain: string } => {
            let html = '';
            let plain = '';
            
            for (const part of parts) {
              if (part.parts) {
                const nested = extractBody(part.parts);
                if (nested.html) html = nested.html;
                if (nested.plain) plain = nested.plain;
              }
              
              if (part.mimeType === 'text/html' && part.body?.data) {
                html = Buffer.from(part.body.data.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf-8');
              }
              
              if (part.mimeType === 'text/plain' && part.body?.data) {
                plain = Buffer.from(part.body.data.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf-8');
              }
            }
            
            return { html, plain };
          };
          
          let body = '';
          if (payload.body?.data) {
            body = Buffer.from(payload.body.data.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf-8');
          } else if (payload.parts) {
            const { html, plain } = extractBody(payload.parts);
            body = html || plain;
          }
          
          // Determine labels
          const labels = messageDetails.data.labelIds || [];
          const isRead = !labels.includes('UNREAD');
          const isImportant = labels.includes('IMPORTANT');
          
          // Skip SPAM/TRASH
          if (labels.includes('SPAM') || labels.includes('TRASH')) {
            console.log(`Skipping message ${messageId} - SPAM/TRASH`);
            return { success: false, messageId, error: 'SPAM/TRASH' };
          }
          
          // Classify email with AI
          console.log(`🤖 Classifying email ${messageId}...`);
          const classification = await emailClassifier.classifyEmail({
            from: fromHeader?.value || 'Unknown',
            subject: subjectHeader?.value || '',
            snippet: messageDetails.data.snippet || '',
            body: body
          });
          console.log(`✅ Email ${messageId} classified as ${classification.priority} (score: ${classification.priorityScore})`);
          
          // Save to database
          const newMessage = await storage.saveGmailMessage({
            userId: req.user!.id,
            messageId: messageId,
            threadId: messageDetails.data.threadId || '',
            from: fromHeader?.value || 'Unknown',
            to: toHeader?.value || 'Unknown',
            subject: subjectHeader?.value || '',
            snippet: messageDetails.data.snippet || '',
            body,
            receivedAt: dateHeader?.value ? new Date(dateHeader.value) : new Date(),
            isRead,
            isImportant,
            labels,
            priority: classification.priority,
            priorityScore: classification.priorityScore,
            classificationReason: classification.classificationReason,
            classificationSignals: classification.classificationSignals
          });
          
          return { success: true, message: newMessage };
        } catch (error: any) {
          const errorMsg = error.message || 'Unknown error';
          console.error(`❌ Error processing message ${messageId}:`, errorMsg);
          return { success: false, messageId, error: errorMsg };
        }
      };
      
      // Process messages in parallel with concurrency limit
      const CONCURRENCY = 5;
      console.log(`⚡ Processing ${messageIds.length} messages with ${CONCURRENCY} concurrent workers...`);
      
      // Update total count
      const progress = syncProgressStore.get(req.user!.id);
      if (progress) {
        progress.total = messageIds.length;
      }
      
      for (let i = 0; i < messageIds.length; i += CONCURRENCY) {
        const batch = messageIds.slice(i, i + CONCURRENCY);
        const results = await Promise.all(batch.map(processMessage));
        
        // Collect successes and errors
        results.forEach(result => {
          if (result.success && result.message) {
            syncedMessages.push(result.message);
          } else if (!result.success && result.messageId) {
            errors.push({ messageId: result.messageId, error: result.error });
          }
        });
        
        // Update progress
        if (progress) {
          progress.processed = i + batch.length;
          progress.synced = syncedMessages.length;
          progress.errors = errors.length;
        }
        
        console.log(`📦 Batch ${Math.floor(i / CONCURRENCY) + 1}: Processed ${batch.length} messages (${syncedMessages.length} synced, ${errors.length} errors)`);
      }
      
      // Mark as completed
      if (progress) {
        progress.status = 'completed';
        progress.endTime = new Date();
      }
      
      console.log(`Successfully synced ${syncedMessages.length} messages for user:`, req.user!.id);
      res.json({ messageCount: syncedMessages.length, message: `Successfully synced ${syncedMessages.length} messages` });
    } catch (error: any) {
      console.error('Error syncing Gmail messages:', error);
      
      // Mark progress as error
      const progress = syncProgressStore.get(req.user!.id);
      if (progress) {
        progress.status = 'error';
        progress.endTime = new Date();
        progress.errorMessage = error.message || 'Unknown error';
      }
      
      // More detailed error logging
      if (error.response) {
        console.error('Gmail API Error Response:', {
          status: error.response.status,
          statusText: error.response.statusText,
          data: error.response.data,
          headers: error.response.headers
        });
      }
      
      if (error.config) {
        console.error('Gmail API Request Configuration:', {
          method: error.config.method,
          url: error.config.url,
          headers: error.config.headers,
          // Don't log potentially sensitive data
          // data: error.config.data
        });
      }
      
      if (error.stack) {
        console.error('Error Stack Trace:', error.stack);
      }
      
      // Provide a more helpful error message
      let errorMessage = 'Failed to sync Gmail messages';
      let errorCode = 'sync_failed';
      
      if (error.message) {
        console.error('Detailed error message:', error.message);
        
        // Check if this is a common error
        if (error.message.includes('Gmail API has not been used') || 
            error.message.includes('API not enabled')) {
          errorMessage = 'Gmail API not enabled. Please enable it in your Google Cloud Console.';
          errorCode = 'api_not_enabled';
        } else if (error.message.includes('invalid_grant')) {
          errorMessage = 'Your Gmail authorization has expired. Please reconnect your Gmail account.';
          errorCode = 'token_expired';
        } else if (error.message.includes('Rate Limit Exceeded')) {
          errorMessage = 'Gmail API rate limit exceeded. Please try again later.';
          errorCode = 'rate_limit';
        } else if (error.message.includes('Token has been expired or revoked')) {
          errorMessage = 'Your Gmail token has expired. Please reconnect your Gmail account.';
          errorCode = 'token_expired';
        } else if (error.message.includes('User has not connected Gmail')) {
          errorMessage = 'Gmail not connected. Please connect your Gmail account first.';
          errorCode = 'not_connected';
        } else if (error.message.includes('Invalid Credentials')) {
          errorMessage = 'Invalid credentials. Please reconnect your Gmail account.';
          errorCode = 'invalid_credentials';
        } else {
          // Include a generic version of the error message
          errorMessage = `Failed to sync Gmail messages: ${error.message}`;
          errorCode = 'unknown_error';
        }
      }
      
      res.status(500).json({ 
        error: errorMessage,
        errorCode: errorCode,
        details: error.message || 'Unknown error'
      });
    }
  });

  // AI Analysis endpoint - Analyze email content
  app.post('/api/gmail/messages/:id/analyze', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const messageId = parseInt(req.params.id);
    
    if (isNaN(messageId)) {
      return res.status(400).json({ error: 'Invalid message ID' });
    }

    try {
      // Get the message from database
      const message = await storage.getGmailMessage(messageId);
      
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // Check if user has access to this message
      if (message.userId !== req.user!.id && req.user!.id !== 3) {
        return res.status(403).json({ error: 'You do not have permission to access this message' });
      }

      // Check if we already have analysis cached
      const existingAnalysis = await storage.getEmailAnalysis(messageId);
      if (existingAnalysis) {
        return res.json(existingAnalysis);
      }

      // Perform AI analysis
      const analysis = await analyzeEmail(
        message.subject || '',
        message.body || message.snippet || '',
        message.from || ''
      );

      // Cache the analysis result
      const cachedAnalysis = await storage.saveEmailAnalysis({
        messageId,
        userId: req.user!.id,
        summary: analysis.summary,
        keyPoints: analysis.keyPoints,
        urgency: analysis.urgency,
        category: analysis.category,
        actionItems: analysis.actionItems,
        sentiment: analysis.sentiment,
        analyzedAt: new Date()
      });

      res.json(cachedAnalysis);
    } catch (error) {
      console.error('Error analyzing email:', error);
      
      if (error instanceof Error && error.message.includes('OpenAI')) {
        return res.status(503).json({ 
          error: 'AI service temporarily unavailable',
          message: 'Please try again in a moment'
        });
      }
      
      res.status(500).json({ 
        error: 'Failed to analyze email',
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    }
  });

  // AI Reply Generation endpoint
  app.post('/api/gmail/messages/:id/generate-reply', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const messageId = parseInt(req.params.id);
    const { context } = req.body; // Optional context from user
    
    if (isNaN(messageId)) {
      return res.status(400).json({ error: 'Invalid message ID' });
    }

    try {
      // Get the message from database
      const message = await storage.getGmailMessage(messageId);
      
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // Check if user has access to this message
      if (message.userId !== req.user!.id && req.user!.id !== 3) {
        return res.status(403).json({ error: 'You do not have permission to access this message' });
      }

      // Prepare user information for signature
      const userName = req.user!.firstName && req.user!.lastName 
        ? `${req.user!.firstName} ${req.user!.lastName}`
        : req.user!.username;
      
      const userInfo = {
        name: userName,
        title: req.user!.jobTitle || undefined,
        company: 'THERMOPAC',
        email: req.user!.email,
        phone: req.user!.mobileNumber ? `${req.user!.countryCode || ''} ${req.user!.mobileNumber}`.trim() : undefined
      };

      // Generate reply options using AI
      const replies = await generateEmailReplies(
        message.subject || '',
        message.body || message.snippet || '',
        message.from || '',
        userInfo,
        context
      );

      // Cache the generated replies for potential reuse
      await storage.saveEmailReplies({
        messageId,
        userId: req.user!.id,
        professionalReply: replies.professional,
        briefReply: replies.brief,
        detailedReply: replies.detailed,
        context: context || null,
        generatedAt: new Date()
      });

      res.json(replies);
    } catch (error) {
      console.error('Error generating email replies:', error);
      
      if (error instanceof Error && error.message.includes('OpenAI')) {
        return res.status(503).json({ 
          error: 'AI service temporarily unavailable',
          message: 'Please try again in a moment'
        });
      }
      
      res.status(500).json({ 
        error: 'Failed to generate email replies',
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    }
  });

  // Get cached analysis for a message
  app.get('/api/gmail/messages/:id/analysis', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const messageId = parseInt(req.params.id);
    
    if (isNaN(messageId)) {
      return res.status(400).json({ error: 'Invalid message ID' });
    }

    try {
      const analysis = await storage.getEmailAnalysis(messageId);
      
      if (!analysis) {
        return res.status(404).json({ error: 'No analysis found for this message' });
      }

      // Check if user has access to this message analysis
      if (analysis.userId !== req.user!.id && req.user!.id !== 3) {
        return res.status(403).json({ error: 'You do not have permission to access this analysis' });
      }

      res.json(analysis);
    } catch (error) {
      console.error('Error fetching email analysis:', error);
      res.status(500).json({ error: 'Failed to fetch email analysis' });
    }
  });

  // Send email endpoint
  app.post('/api/gmail/send', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const { to, cc, subject, body, inReplyTo } = req.body;

      if (!to || !subject) {
        return res.status(400).json({ error: 'To and subject are required' });
      }

      const gmail = await getGmailClient(req.user!.id);
      
      // Create email message in RFC 2822 format
      const emailLines = [
        `To: ${to}`,
        cc ? `Cc: ${cc}` : '',
        `Subject: ${subject}`,
        inReplyTo ? `In-Reply-To: ${inReplyTo}` : '',
        'Content-Type: text/html; charset=utf-8',
        '',
        body || ''
      ].filter(line => line !== '');

      const email = emailLines.join('\r\n');
      const encodedMessage = Buffer.from(email)
        .toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

      await gmail.users.messages.send({
        userId: 'me',
        requestBody: {
          raw: encodedMessage
        }
      });

      res.json({ 
        success: true, 
        message: 'Email sent successfully' 
      });
    } catch (error) {
      console.error('Error sending email:', error);
      res.status(500).json({ 
        error: 'Failed to send email',
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    }
  });
}