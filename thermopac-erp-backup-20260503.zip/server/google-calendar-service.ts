import { OAuth2Client } from 'google-auth-library';
import { google, calendar_v3 } from 'googleapis';
import { db } from './db';
import { users, businessMeetings, googleCalendarSyncLog } from '@shared/schema';
import { eq, inArray } from 'drizzle-orm';

// Google Calendar OAuth Configuration
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
// Use the authorized redirect URI from environment
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'https://thermopac-communication-thermopacllp.replit.app/api/auth/google/callback';

// Scopes required for Google Calendar, Meet, and Gmail access
const CALENDAR_SCOPES = [
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/userinfo.email',
  // Gmail scopes (Calendar tokens will also work for Gmail)
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.labels',
  'https://www.googleapis.com/auth/gmail.modify'
];

export class GoogleCalendarService {
  private oauth2Client: OAuth2Client;

  constructor() {
    this.oauth2Client = new OAuth2Client(
      GOOGLE_CLIENT_ID,
      GOOGLE_CLIENT_SECRET,
      GOOGLE_REDIRECT_URI
    );
  }

  /**
   * Generate Google OAuth URL for calendar authorization
   */
  generateAuthUrl(customState?: string): string {
    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: CALENDAR_SCOPES,
      prompt: 'consent', // Force consent to get refresh token
      state: customState || 'service=calendar' // Add state parameter to identify this as calendar OAuth
    });
  }

  /**
   * Exchange authorization code for tokens
   */
  async exchangeCodeForTokens(code: string) {
    const { tokens } = await this.oauth2Client.getToken(code);
    return tokens;
  }

  /**
   * Save user's Google Calendar tokens to database
   */
  async saveUserTokens(userId: number, tokens: any) {
    const expiresAt = tokens.expiry_date ? new Date(tokens.expiry_date) : null;
    
    await db
      .update(users)
      .set({
        googleAccessToken: tokens.access_token,
        googleRefreshToken: tokens.refresh_token,
        googleTokenExpiresAt: expiresAt,
        googleCalendarConnected: true,
        googleCalendarSyncEnabled: true
      })
      .where(eq(users.id, userId));
  }

  /**
   * Refresh access token if expired
   */
  async refreshTokenIfNeeded(userId: number): Promise<boolean> {
    try {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId));

      if (!user?.googleRefreshToken) {
        console.log(`No refresh token found for user ${userId}`);
        return false;
      }

      // Check if token is expired (with 5 minute buffer)
      const now = new Date();
      const expiresAt = user.googleTokenExpiresAt;
      const bufferTime = 5 * 60 * 1000; // 5 minutes in milliseconds

      if (expiresAt && now.getTime() > (expiresAt.getTime() - bufferTime)) {
        console.log(`Token expired for user ${userId}, refreshing...`);
        
        this.oauth2Client.setCredentials({
          refresh_token: user.googleRefreshToken
        });

        const { credentials } = await this.oauth2Client.refreshAccessToken();
        
        // Update tokens in database
        await this.saveUserTokens(userId, credentials);
        console.log(`Successfully refreshed token for user ${userId}`);
        return true;
      }

      return true; // Token is still valid
    } catch (error) {
      console.error(`Error refreshing token for user ${userId}:`, error);
      return false;
    }
  }

  /**
   * Get authenticated calendar client for user
   */
  async getCalendarClient(userId: number): Promise<calendar_v3.Calendar | null> {
    try {
      // Refresh token if needed
      const tokenValid = await this.refreshTokenIfNeeded(userId);
      if (!tokenValid) {
        return null;
      }

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId));

      if (!user?.googleAccessToken || !user.googleCalendarConnected) {
        return null;
      }

      // Set up OAuth client with user's tokens
      this.oauth2Client.setCredentials({
        access_token: user.googleAccessToken,
        refresh_token: user.googleRefreshToken
      });

      return google.calendar({ version: 'v3', auth: this.oauth2Client });
    } catch (error) {
      console.error(`Failed to get calendar client for user ${userId}:`, error);
      return null;
    }
  }

  /**
   * Fetch upcoming Google Calendar events with Google Meet links
   */
  async fetchUpcomingEvents(userId: number, maxResults: number = 25): Promise<any[]> {
    try {
      const calendar = await this.getCalendarClient(userId);
      if (!calendar) {
        throw new Error('Google Calendar not connected for user');
      }

      // Get start of today and 30 days from now to include events from earlier today
      const now = new Date();
      const startOfToday = new Date(now);
      startOfToday.setHours(0, 0, 0, 0);
      const maxTime = new Date();
      maxTime.setDate(now.getDate() + 30);

      console.log(`Fetching events for user ${userId} from start of today ${startOfToday.toISOString()} to ${maxTime.toISOString()}`);

      const response = await calendar.events.list({
        calendarId: 'primary',
        timeMin: startOfToday.toISOString(),
        timeMax: maxTime.toISOString(),
        maxResults: maxResults,
        singleEvents: true,
        orderBy: 'startTime',
        fields: 'items(id,summary,description,start,end,hangoutLink,creator,organizer,attendees,location,status,htmlLink)'
      });

      const events = response.data.items || [];
      console.log(`Retrieved ${events.length} total events from Google Calendar`);
      
      // Detailed logging for debugging
      if (events.length > 0) {
        console.log('First few events:', events.slice(0, 3).map(e => ({
          id: e.id,
          summary: e.summary,
          start: e.start,
          status: e.status
        })));
      } else {
        console.log('No events found. API Response status:', response.status);
        console.log('API Response data keys:', Object.keys(response.data || {}));
        
        // Try a broader search to see if there are any events at all
        try {
          const broadResponse = await calendar.events.list({
            calendarId: 'primary',
            maxResults: 5,
            singleEvents: true,
            orderBy: 'startTime'
          });
          console.log(`Broad search found ${broadResponse.data.items?.length || 0} events total`);
        } catch (broadError) {
          console.log('Broad search also failed:', broadError.message);
        }
      }

      // Transform ALL events to our format (not just those with Meet links)
      const transformedEvents = events.map(event => {
        // Extract meeting links from various fields
        const extractMeetingLink = (event: any): string | null => {
          // Primary: hangoutLink (official Google Meet link)
          if (event.hangoutLink) {
            return event.hangoutLink;
          }
          
          // Secondary: check description for meeting links
          if (event.description) {
            // Google Meet links
            const meetLinkRegex = /https:\/\/meet\.google\.com\/[a-z0-9-]+/i;
            
            // Teams meeting links (actual meeting URLs, not dial-in pages)
            const teamsLinkRegex = /https:\/\/teams\.microsoft\.com\/l\/meetup-join\/[^\s<>"']+/i;
            const teamsWebappRegex = /https:\/\/teams\.live\.com\/meet\/[^\s<>"']+/i;
            
            // Zoom meeting links
            const zoomLinkRegex = /https:\/\/[a-z0-9-]+\.zoom\.us\/j\/[0-9]+(\?[^\s<>"']*)?/i;
            
            // WebEx meeting links
            const webexLinkRegex = /https:\/\/[a-z0-9-]+\.webex\.com\/[^\s<>"']+/i;
            
            const meetMatch = event.description.match(meetLinkRegex);
            if (meetMatch) return meetMatch[0];
            
            const teamsMatch = event.description.match(teamsLinkRegex);
            if (teamsMatch) return teamsMatch[0];
            
            const teamsWebappMatch = event.description.match(teamsWebappRegex);
            if (teamsWebappMatch) return teamsWebappMatch[0];
            
            const zoomMatch = event.description.match(zoomLinkRegex);
            if (zoomMatch) return zoomMatch[0];
            
            const webexMatch = event.description.match(webexLinkRegex);
            if (webexMatch) return webexMatch[0];
          }
          
          // Tertiary: check location field for meeting links
          if (event.location) {
            const meetLinkRegex = /https:\/\/meet\.google\.com\/[a-z0-9-]+/i;
            const teamsLinkRegex = /https:\/\/teams\.microsoft\.com\/l\/meetup-join\/[^\s<>"']+/i;
            const teamsWebappRegex = /https:\/\/teams\.live\.com\/meet\/[^\s<>"']+/i;
            const zoomLinkRegex = /https:\/\/[a-z0-9-]+\.zoom\.us\/j\/[0-9]+(\?[^\s<>"']*)?/i;
            const webexLinkRegex = /https:\/\/[a-z0-9-]+\.webex\.com\/[^\s<>"']+/i;
            
            const meetMatch = event.location.match(meetLinkRegex);
            if (meetMatch) return meetMatch[0];
            
            const teamsMatch = event.location.match(teamsLinkRegex);
            if (teamsMatch) return teamsMatch[0];
            
            const teamsWebappMatch = event.location.match(teamsWebappRegex);
            if (teamsWebappMatch) return teamsWebappMatch[0];
            
            const zoomMatch = event.location.match(zoomLinkRegex);
            if (zoomMatch) return zoomMatch[0];
            
            const webexMatch = event.location.match(webexLinkRegex);
            if (webexMatch) return webexMatch[0];
          }
          
          return null;
        };

        const extractedMeetingLink = extractMeetingLink(event);
        
        return {
          id: event.id,
          summary: event.summary || 'Untitled Event',
          description: event.description || '',
          start: {
            dateTime: event.start?.dateTime,
            date: event.start?.date,
            timeZone: event.start?.timeZone
          },
          end: {
            dateTime: event.end?.dateTime,
            date: event.end?.date,
            timeZone: event.end?.timeZone
          },
          hangoutLink: extractedMeetingLink || event.hangoutLink,
          location: event.location,
          status: event.status,
          htmlLink: event.htmlLink,
          creator: {
            email: event.creator?.email,
            displayName: event.creator?.displayName
          },
          organizer: {
            email: event.organizer?.email,
            displayName: event.organizer?.displayName
          },
          attendees: event.attendees?.map(attendee => ({
            email: attendee.email,
            displayName: attendee.displayName,
            responseStatus: attendee.responseStatus
          })) || []
        };
      });

      console.log(`Successfully fetched and transformed ${transformedEvents.length} upcoming events from Google Calendar`);
      return transformedEvents;

    } catch (error) {
      console.error(`Error fetching upcoming events for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Create Google Calendar event from meeting data
   * Returns both event ID and Google Meet link
   */
  async createCalendarEvent(userId: number, meetingData: any): Promise<{ eventId: string; meetLink?: string } | null> {
    try {
      const calendar = await this.getCalendarClient(userId);
      if (!calendar) {
        throw new Error('Google Calendar not connected for user');
      }

      // Get attendee emails from the database
      const attendeeEmails = await this.getAttendeeEmails(meetingData.attendeeIds, meetingData.externalAttendees);
      
      console.log(`📧 Creating Google Calendar event with ${attendeeEmails.length} invitees: ${attendeeEmails.join(', ')}`);

      // Convert meeting date and times to ISO format
      const startDateTime = this.createDateTime(meetingData.meetingDate, meetingData.startTime, meetingData.timezone);
      const endDateTime = this.createDateTime(meetingData.meetingDate, meetingData.endTime, meetingData.timezone);

      const event: calendar_v3.Schema$Event = {
        summary: meetingData.title,
        description: this.formatEventDescription(meetingData),
        location: meetingData.location || meetingData.meetingUrl,
        start: {
          dateTime: startDateTime,
          timeZone: meetingData.timezone || 'Asia/Kolkata'
        },
        end: {
          dateTime: endDateTime,
          timeZone: meetingData.timezone || 'Asia/Kolkata'
        },
        attendees: attendeeEmails.map(email => ({ email })),
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'email', minutes: 24 * 60 }, // 1 day before
            { method: 'popup', minutes: 10 }       // 10 minutes before
          ]
        },
        visibility: 'default',
        transparency: 'opaque',
        // Auto-generate Google Meet link
        conferenceData: meetingData.autoCreateGoogleMeet !== false ? {
          createRequest: {
            requestId: `meet-${meetingData.id}-${Date.now()}`,
            conferenceSolutionKey: {
              type: 'hangoutsMeet'
            }
          }
        } : undefined
      };

      const response = await calendar.events.insert({
        calendarId: 'primary',
        requestBody: event,
        sendUpdates: 'all', // Send invitations to all attendees
        conferenceDataVersion: 1 // Required for conference data
      });

      // Extract Google Meet link if created
      const meetLink = response.data.conferenceData?.entryPoints?.find(
        entry => entry.entryPointType === 'video'
      )?.uri;

      // Update meeting with Google Meet link if available
      if (meetLink) {
        await db
          .update(businessMeetings)
          .set({ 
            googleMeetLink: meetLink,
            googleMeetUrl: meetLink  // Store in both fields for compatibility
          })
          .where(eq(businessMeetings.id, meetingData.id));
          
        console.log(`Meeting ${meetingData.id} updated with Google Meet link: ${meetLink}`);
      }

      // Log successful creation
      await this.logSyncOperation(meetingData.id, userId, 'create', response.data.id!, 'success');

      console.log(`Google Calendar event created successfully. Event ID: ${response.data.id}, Meet Link: ${meetLink || 'None generated'}`);
      
      return {
        eventId: response.data.id!,
        meetLink: meetLink || undefined
      };
    } catch (error) {
      console.error('Failed to create Google Calendar event:', error);
      
      // Log error
      await this.logSyncOperation(
        meetingData.id, 
        userId, 
        'create', 
        null, 
        'error', 
        error instanceof Error ? error.message : 'Unknown error'
      );
      
      return null;
    }
  }

  /**
   * Update existing Google Calendar event
   */
  async updateCalendarEvent(userId: number, eventId: string, meetingData: any): Promise<boolean> {
    try {
      const calendar = await this.getCalendarClient(userId);
      if (!calendar) {
        throw new Error('Google Calendar not connected for user');
      }

      const attendeeEmails = await this.getAttendeeEmails(meetingData.attendeeIds, meetingData.externalAttendees);
      const startDateTime = this.createDateTime(meetingData.meetingDate, meetingData.startTime, meetingData.timezone);
      const endDateTime = this.createDateTime(meetingData.meetingDate, meetingData.endTime, meetingData.timezone);

      const event: calendar_v3.Schema$Event = {
        summary: meetingData.title,
        description: this.formatEventDescription(meetingData),
        location: meetingData.location || meetingData.meetingUrl,
        start: {
          dateTime: startDateTime,
          timeZone: meetingData.timezone || 'Asia/Kolkata'
        },
        end: {
          dateTime: endDateTime,
          timeZone: meetingData.timezone || 'Asia/Kolkata'
        },
        attendees: attendeeEmails.map(email => ({ email })),
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'email', minutes: 24 * 60 },
            { method: 'popup', minutes: 10 }
          ]
        },
        // Preserve or add Google Meet link
        conferenceData: meetingData.autoCreateGoogleMeet !== false ? {
          createRequest: {
            requestId: `meet-${meetingData.id}-${Date.now()}`,
            conferenceSolutionKey: {
              type: 'hangoutsMeet'
            }
          }
        } : undefined
      };

      const response = await calendar.events.update({
        calendarId: 'primary',
        eventId: eventId,
        requestBody: event,
        sendUpdates: 'all',
        conferenceDataVersion: 1
      });

      // Extract and update Google Meet link if available
      const meetLink = response.data.conferenceData?.entryPoints?.find(
        entry => entry.entryPointType === 'video'
      )?.uri;

      if (meetLink) {
        await db
          .update(businessMeetings)
          .set({ googleMeetLink: meetLink })
          .where(eq(businessMeetings.id, meetingData.id));
      }

      await this.logSyncOperation(meetingData.id, userId, 'update', eventId, 'success');
      return true;
    } catch (error) {
      console.error('Failed to update Google Calendar event:', error);
      await this.logSyncOperation(
        meetingData.id, 
        userId, 
        'update', 
        eventId, 
        'error', 
        error instanceof Error ? error.message : 'Unknown error'
      );
      return false;
    }
  }

  /**
   * Delete Google Calendar event
   */
  async deleteCalendarEvent(userId: number, eventId: string, meetingId: number): Promise<boolean> {
    try {
      const calendar = await this.getCalendarClient(userId);
      if (!calendar) {
        throw new Error('Google Calendar not connected for user');
      }

      await calendar.events.delete({
        calendarId: 'primary',
        eventId: eventId,
        sendUpdates: 'all'
      });

      await this.logSyncOperation(meetingId, userId, 'delete', eventId, 'success');
      return true;
    } catch (error) {
      console.error('Failed to delete Google Calendar event:', error);
      await this.logSyncOperation(
        meetingId, 
        userId, 
        'delete', 
        eventId, 
        'error', 
        error instanceof Error ? error.message : 'Unknown error'
      );
      return false;
    }
  }

  /**
   * Disconnect user's Google Calendar
   */
  async disconnectCalendar(userId: number): Promise<boolean> {
    try {
      await db
        .update(users)
        .set({
          googleAccessToken: null,
          googleRefreshToken: null,
          googleTokenExpiresAt: null,
          googleCalendarConnected: false,
          googleCalendarSyncEnabled: false,
          googleEmail: null
        })
        .where(eq(users.id, userId));

      return true;
    } catch (error) {
      console.error('Failed to disconnect Google Calendar:', error);
      return false;
    }
  }

  /**
   * Get attendee email addresses from user IDs and external attendees
   */
  private async getAttendeeEmails(attendeeIds: number[], externalAttendees: any[]): Promise<string[]> {
    const emails: string[] = [];

    console.log(`🔍 Fetching emails for ${attendeeIds?.length || 0} internal attendees: [${attendeeIds?.join(', ') || 'none'}]`);

    // Get internal attendee emails for ALL attendees
    if (attendeeIds && attendeeIds.length > 0) {
      const attendees = await db
        .select({ email: users.email })
        .from(users)
        .where(inArray(users.id, attendeeIds)); // ✅ Get ALL attendees, not just first one

      console.log(`📧 Found ${attendees.length} internal attendee emails: ${attendees.map(a => a.email).join(', ')}`);
      emails.push(...attendees.map(a => a.email).filter(email => email));
    }

    // Add external attendee emails
    if (externalAttendees && externalAttendees.length > 0) {
      console.log(`🌐 Adding ${externalAttendees.length} external attendee emails`);
      emails.push(...externalAttendees.map((attendee: any) => attendee.email));
    }

    const finalEmails = emails.filter(email => email && email.includes('@'));
    console.log(`✅ Final attendee email list: ${finalEmails.join(', ')}`);
    return finalEmails;
  }

  /**
   * Create ISO datetime string from date and time
   */
  private createDateTime(date: string, time: string, timezone: string): string {
    const dateStr = new Date(date).toISOString().split('T')[0];
    // Ensure time has seconds (Google Calendar API requirement)
    const timeWithSeconds = time.includes(':') && time.split(':').length === 2 ? `${time}:00` : time;
    return `${dateStr}T${timeWithSeconds}`;
  }

  /**
   * Format meeting description for calendar event
   */
  private formatEventDescription(meetingData: any): string {
    let description = '';
    
    if (meetingData.description) {
      description += `${meetingData.description}\n\n`;
    }

    if (meetingData.agenda) {
      description += `Agenda:\n${meetingData.agenda}\n\n`;
    }

    if (meetingData.meetingUrl) {
      description += `Meeting Link: ${meetingData.meetingUrl}\n`;
    }

    description += `Meeting Type: ${meetingData.meetingType}\n`;
    description += `Priority: ${meetingData.priority}\n`;

    return description.trim();
  }

  /**
   * Generate Google Meet link for a meeting by creating a real calendar event
   */
  async generateMeetLink(meetingData: any, userId: number): Promise<string | null> {
    try {
      // Check if user has Google Calendar connected
      const [user] = await db
        .select({
          googleCalendarConnected: users.googleCalendarConnected,
          googleCalendarSyncEnabled: users.googleCalendarSyncEnabled
        })
        .from(users)
        .where(eq(users.id, userId));

      if (!user?.googleCalendarConnected || !user?.googleCalendarSyncEnabled) {
        console.log(`User ${userId} doesn't have Google Calendar connected. Providing connection instructions.`);
        throw new Error('GOOGLE_CALENDAR_NOT_CONNECTED');
      }

      // Create real Google Calendar event with Meet link
      const result = await this.createCalendarEvent(userId, meetingData);
      
      if (!result || !result.eventId) {
        throw new Error('Failed to create Google Calendar event');
      }

      // Update meeting with Google event ID and sync status
      const updateData: any = { 
        googleEventId: result.eventId,
        googleCalendarSynced: true 
      };
      
      if (result.meetLink) {
        updateData.googleMeetLink = result.meetLink;
        updateData.googleMeetUrl = result.meetLink; // Store in both fields for compatibility
      }
      
      await db
        .update(businessMeetings)
        .set(updateData)
        .where(eq(businessMeetings.id, meetingData.id));

      if (result.meetLink) {
        console.log(`Generated real Google Meet link for meeting ${meetingData.id}: ${result.meetLink}`);
        return result.meetLink;
      } else {
        throw new Error('Google Meet link not found in created event');
      }
      
    } catch (error) {
      console.error('Error generating Google Meet link:', error);
      return null;
    }
  }

  /**
   * Update Google Calendar event as concluded for all meeting participants
   */
  async updateEventAsCompleted(
    meetingId: number, 
    googleEventId: string,
    attendeeIds: number[],
    concludedBy: string, 
    concludedAt: Date
  ): Promise<{ success: number; failed: number; errors: string[] }> {
    const results = { success: 0, failed: 0, errors: [] as string[] };
    
    console.log(`Updating Google Calendar event ${googleEventId} as concluded for ${attendeeIds.length} participants`);
    
    // Get meeting details for context
    const [meeting] = await db
      .select()
      .from(businessMeetings)
      .where(eq(businessMeetings.id, meetingId));
    
    if (!meeting) {
      results.failed = attendeeIds.length;
      results.errors.push('Meeting not found');
      return results;
    }
    
    // Get participant details for connected users only
    const participantUsers = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        googleCalendarConnected: users.googleCalendarConnected,
        googleCalendarSyncEnabled: users.googleCalendarSyncEnabled
      })
      .from(users)
      .where(eq(users.id, attendeeIds[0])); // Start with first attendee, we'll handle multiple in a loop
    
    // Get all participants with Google Calendar connected
    const connectedParticipants = [];
    for (const attendeeId of attendeeIds) {
      const [user] = await db
        .select({
          id: users.id,
          username: users.username,
          email: users.email,
          googleCalendarConnected: users.googleCalendarConnected,
          googleCalendarSyncEnabled: users.googleCalendarSyncEnabled
        })
        .from(users)
        .where(eq(users.id, attendeeId));
      
      if (user?.googleCalendarConnected && user?.googleCalendarSyncEnabled) {
        connectedParticipants.push(user);
      }
    }
    
    console.log(`Found ${connectedParticipants.length} participants with Google Calendar connected`);
    
    // Update event for each connected participant
    for (const participant of connectedParticipants) {
      try {
        const calendar = await this.getCalendarClient(participant.id);
        if (!calendar) {
          results.failed++;
          results.errors.push(`Failed to get calendar client for ${participant.username}`);
          continue;
        }
        
        // Get current event
        const currentEvent = await calendar.events.get({
          calendarId: 'primary',
          eventId: googleEventId
        });
        
        if (!currentEvent.data) {
          results.failed++;
          results.errors.push(`Event not found in ${participant.username}'s calendar`);
          continue;
        }
        
        // Format conclusion timestamp
        const conclusionTimestamp = concludedAt.toLocaleString('en-IN', {
          timeZone: 'Asia/Kolkata',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        });
        
        // Create updated description with conclusion marker
        const originalDescription = currentEvent.data.description || '';
        const conclusionMarker = `\n\n✅ MEETING CONCLUDED\nConcluded: ${conclusionTimestamp} IST\nConcluded by: ${concludedBy}`;
        
        // Check if already concluded (prevent duplicate markers)
        const updatedDescription = originalDescription.includes('✅ MEETING CONCLUDED') 
          ? originalDescription 
          : originalDescription + conclusionMarker;
        
        // Update the event
        await calendar.events.update({
          calendarId: 'primary',
          eventId: googleEventId,
          requestBody: {
            ...currentEvent.data,
            description: updatedDescription,
            status: 'confirmed' // Ensure event is confirmed
          },
          sendUpdates: 'all' // Send notifications to all attendees
        });
        
        // Log successful update
        await this.logSyncOperation(meetingId, participant.id, 'conclude', googleEventId, 'success');
        results.success++;
        
        console.log(`Successfully updated calendar event for ${participant.username} (${participant.email})`);
        
      } catch (error) {
        results.failed++;
        const errorMsg = `Failed to update calendar for ${participant.username}: ${error instanceof Error ? error.message : 'Unknown error'}`;
        results.errors.push(errorMsg);
        
        // Log failed update
        await this.logSyncOperation(
          meetingId, 
          participant.id, 
          'conclude', 
          googleEventId, 
          'error', 
          errorMsg
        );
        
        console.error(errorMsg);
      }
    }
    
    console.log(`Google Calendar conclusion sync completed: ${results.success} success, ${results.failed} failed`);
    return results;
  }

  /**
   * Log sync operation to database
   */
  private async logSyncOperation(
    meetingId: number, 
    userId: number, 
    action: string, 
    googleEventId: string | null, 
    status: string, 
    errorMessage?: string
  ) {
    try {
      await db.insert(googleCalendarSyncLog).values({
        meetingId,
        userId,
        action,
        googleEventId,
        status,
        errorMessage,
        syncDetails: {
          timestamp: new Date().toISOString(),
          action,
          status
        }
      });
    } catch (error) {
      console.error('Failed to log sync operation:', error);
    }
  }
}

export const googleCalendarService = new GoogleCalendarService();