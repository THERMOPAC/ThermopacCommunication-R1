import { Router } from 'express';
import multer from 'multer';
import { eq, and, like, desc, sql } from 'drizzle-orm';
import { db } from './db';
import { 
  designDrawings, 
  drawingVersions, 
  designProjects, 
  projects, 
  users 
} from '../shared/schema';
import { ensureAuthenticated as authenticateUser } from './auth-middleware';
import { uploadFileWithDiagnostics } from './utils/gcs-enhanced-upload';
import { resolveDrawingVersionWithFallback } from './utils/epc-migration-helpers';
import { resolveProjectGeoCodes, buildDrawingGcsPath } from './epc-coding';
import { initializeGCS } from './utils/gcs-operations';

const router = Router();

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'application/octet-stream'];
    const allowedExtensions = ['.dwg', '.pdf', '.png', '.jpg', '.jpeg'];
    const fileExtension = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
    
    if (allowedTypes.includes(file.mimetype) || allowedExtensions.includes(fileExtension)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Allowed: DWG, PDF, PNG, JPG'));
    }
  }
});

// Get all drawings with filters and joins
router.get('/drawings', authenticateUser, async (req, res) => {
  try {
    const { search, category, status, projectId } = req.query;
    
    // Simple query to get just the core drawings data first
    let query = db.select().from(designDrawings);

    // Apply filters
    const conditions = [];
    
    if (search) {
      conditions.push(
        sql`(${designDrawings.drawingNumber} ILIKE ${`%${search}%`} OR ${designDrawings.drawingTitle} ILIKE ${`%${search}%`})`
      );
    }
    
    if (category && category !== 'all') {
      conditions.push(eq(designDrawings.category, category as string));
    }
    
    if (status && status !== 'all') {
      conditions.push(eq(designDrawings.status, status as string));
    }
    
    if (projectId) {
      conditions.push(eq(designDrawings.designProjectId, parseInt(projectId as string)));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(designDrawings.updatedAt));

    const result = await query;

    // Return simplified structure for now to avoid join issues
    const drawings = result.map(row => ({
      id: row.id,
      designProjectId: row.designProjectId,
      drawingNumber: row.drawingNumber,
      drawingTitle: row.drawingTitle,
      category: row.category,
      disciplineCode: row.disciplineCode,
      status: row.status,
      currentVersionId: row.currentVersionId,
      createdBy: row.createdBy,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      project: null, // Simplified for now
      currentVersion: null, // Simplified for now  
      creator: null // Simplified for now
    }));

    res.json(drawings);
  } catch (error) {
    console.error('Error fetching drawings:', error);
    res.status(500).json({ error: 'Failed to fetch drawings' });
  }
});

// Get versions for a specific drawing
router.get('/drawings/:id/versions', authenticateUser, async (req, res) => {
  try {
    const drawingId = parseInt(req.params.id);
    
    const versions = await db
      .select({
        id: drawingVersions.id,
        drawingId: drawingVersions.drawingId,
        version: drawingVersions.version,
        revision: drawingVersions.revision,
        fileName: drawingVersions.fileName,
        fileUrl: drawingVersions.fileUrl,
        filePath: drawingVersions.filePath,
        fileSize: drawingVersions.fileSize,
        fileType: drawingVersions.fileType,
        uploadedBy: drawingVersions.uploadedBy,
        uploadDate: drawingVersions.uploadDate,
        versionNotes: drawingVersions.versionNotes,
        uploaderUsername: users.username,
        uploaderFirstName: users.firstName,
        uploaderLastName: users.lastName
      })
      .from(drawingVersions)
      .leftJoin(users, eq(drawingVersions.uploadedBy, users.id))
      .where(eq(drawingVersions.drawingId, drawingId))
      .orderBy(desc(drawingVersions.uploadDate));

    const formattedVersions = versions.map(version => ({
      id: version.id,
      drawingId: version.drawingId,
      version: version.version,
      revision: version.revision,
      fileName: version.fileName,
      fileUrl: version.fileUrl,
      filePath: version.filePath,
      fileSize: version.fileSize,
      fileType: version.fileType,
      uploadedBy: version.uploadedBy,
      uploadDate: version.uploadDate,
      versionNotes: version.versionNotes,
      uploader: {
        username: version.uploaderUsername,
        firstName: version.uploaderFirstName,
        lastName: version.uploaderLastName
      }
    }));

    res.json(formattedVersions);
  } catch (error) {
    console.error('Error fetching drawing versions:', error);
    res.status(500).json({ error: 'Failed to fetch drawing versions' });
  }
});

// Upload new drawing with version
router.post('/drawings/upload', authenticateUser, upload.single('file'), async (req, res) => {
  try {
    const {
      projectId,
      designProjectId,
      drawingNumber,
      drawingTitle,
      category,
      disciplineCode,
      versionNotes
    } = req.body;

    const file = req.file;
    const userId = req.user!.id;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    let actualDesignProjectId;
    let projectCode;

    // If designProjectId is provided, use it directly
    if (designProjectId) {
      actualDesignProjectId = parseInt(designProjectId);
    } 
    // If projectId is provided, find or create the design project
    else if (projectId) {
      // First, try to find existing design project for this project
      const existingDesignProject = await db
        .select({ id: designProjects.id })
        .from(designProjects)
        .where(eq(designProjects.projectId, parseInt(projectId)))
        .limit(1);

      if (existingDesignProject.length > 0) {
        actualDesignProjectId = existingDesignProject[0].id;
      } else {
        // Create new design project for this project
        const project = await db
          .select({ name: projects.name, code: projects.code })
          .from(projects)
          .where(eq(projects.id, parseInt(projectId)))
          .limit(1);

        if (project.length === 0) {
          return res.status(400).json({ error: 'Project not found' });
        }



        // Truncate design project name to fit database constraint (255 chars)
        const baseProjectName = project[0].name || 'Unknown Project';
        const designProjectName = `${baseProjectName} - Design Phase`;
        const truncatedDesignProjectName = designProjectName.length > 255 
          ? designProjectName.substring(0, 252) + '...' 
          : designProjectName;

        const [newDesignProject] = await db
          .insert(designProjects)
          .values({
            projectId: parseInt(projectId),
            projectCode: project[0].code || '2025-' + projectId,
            designProjectName: truncatedDesignProjectName,
            designPhase: 'Detailed',
            status: 'In Progress',
            designManagerId: userId,
            startDate: new Date(),
            createdBy: userId,
            createdAt: new Date(),
            updatedAt: new Date()
          })
          .returning();

        actualDesignProjectId = newDesignProject.id;
      }
    } else {
      return res.status(400).json({ error: 'Either projectId or designProjectId is required' });
    }

    // Get design project info for GCS path
    const designProject = await db
      .select({
        designProjectName: designProjects.designProjectName,
        projectCode: projects.code,
        projectName: projects.name,
        projectDbId: projects.id,
      })
      .from(designProjects)
      .leftJoin(projects, eq(designProjects.projectId, projects.id))
      .where(eq(designProjects.id, actualDesignProjectId))
      .limit(1);

    if (designProject.length === 0) {
      return res.status(400).json({ error: 'Design project not found' });
    }

    projectCode = designProject[0].projectCode || 'UNKNOWN';
    
    // **AUTOMATIC REVISION CONTROL LOGIC**
    // First, check if drawing with same drawingNumber already exists
    const existingDrawing = await db
      .select({ 
        id: designDrawings.id,
        drawingNumber: designDrawings.drawingNumber
      })
      .from(designDrawings)
      .where(eq(designDrawings.drawingNumber, drawingNumber))
      .limit(1);

    let isRevision = existingDrawing.length > 0;
    let drawingId = isRevision ? existingDrawing[0].id : null;

    // Check existing versions for revision control
    const existingVersions = await db
      .select({ 
        id: drawingVersions.id,
        revision: drawingVersions.revision,
        fileName: drawingVersions.fileName 
      })
      .from(drawingVersions)
      .leftJoin(designDrawings, eq(drawingVersions.drawingId, designDrawings.id))
      .where(eq(designDrawings.drawingNumber, drawingNumber))
      .orderBy(desc(drawingVersions.createdAt));

    let autoRevision = 'R1';
    
    if (existingVersions.length > 0) {
      // Extract revision numbers and find the next revision
      const revisions = existingVersions
        .map(d => d.revision)
        .filter(r => r && r.match(/^R\d+$/))
        .map(r => {
          const match = r.match(/^R(\d+)$/);
          return match ? parseInt(match[1]) : null;
        })
        .filter(r => r !== null)
        .sort((a, b) => b - a);

      if (revisions.length > 0) {
        const latestRevision = revisions[0];
        // Auto-increment revision (R1 → R2 → R3)
        autoRevision = `R${latestRevision + 1}`;
      } else {
        autoRevision = 'R2'; // If no valid revisions found, start at R2
      }
    }

    const finalRevision = autoRevision;

    // Build TPEL governed GCS path via shared builder
    const fileExtension = file.originalname.split('.').pop() || 'pdf';
    const versionedFileName = `${drawingNumber}_${finalRevision}.${fileExtension}`;

    let gcsPath: string;
    const designProjectDbId = designProject[0].projectDbId;
    // G5: No new writes to legacy paths. All uploads must use the TPEL governed path.
    if (!designProjectDbId) {
      return res.status(400).json({
        error: 'G5 violation: This design project is not linked to an EPC project. Drawing uploads require a linked EPC project to generate a governed TPEL path. Link the design project to an EPC project before uploading.',
      });
    }
    try {
      const geo = await resolveProjectGeoCodes(designProjectDbId);
      const itemCode = (disciplineCode || 'PROJ').toUpperCase();
      gcsPath = buildDrawingGcsPath(
        geo.continentCode, geo.countryCode, geo.customerShortCode,
        geo.fyCode, geo.projectSeq,
        itemCode, drawingNumber, finalRevision, fileExtension
      );
    } catch (geoErr: any) {
      return res.status(400).json({
        error: `G5 violation: Could not resolve TPEL geo-codes for the linked EPC project — ${geoErr?.message || 'unknown error'}. Ensure the project has continent/country/customer codes assigned.`,
      });
    }

    // Upload to GCS
    const uploadResult = await uploadFileWithDiagnostics(gcsPath, file.buffer, file.mimetype);
    if (!uploadResult.successful) {
      return res.status(500).json({ error: `Upload failed: ${uploadResult.error?.message || 'Unknown error'}` });
    }

    // Create drawing record (only if this is the first version)
    if (!isRevision) {
      // Truncate fields to fit database constraints
      const truncatedDrawingNumber = drawingNumber.length > 100 ? drawingNumber.substring(0, 100) : drawingNumber;
      const truncatedDrawingTitle = drawingTitle.length > 255 ? drawingTitle.substring(0, 252) + '...' : drawingTitle;
      const truncatedCategory = (category || 'Assembly Drawing').length > 50 ? (category || 'Assembly Drawing').substring(0, 50) : (category || 'Assembly Drawing');
      const truncatedDisciplineCode = (disciplineCode || 'PD').length > 10 ? (disciplineCode || 'PD').substring(0, 10) : (disciplineCode || 'PD');

      const [newDrawing] = await db
        .insert(designDrawings)
        .values({
          designProjectId: actualDesignProjectId,
          drawingNumber: truncatedDrawingNumber,
          drawingTitle: truncatedDrawingTitle,
          category: truncatedCategory,
          disciplineCode: truncatedDisciplineCode,
          status: 'Draft',
          createdBy: userId,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      
      drawingId = newDrawing.id;
    }
    // If it's a revision, drawingId is already set from the existingDrawing query above

    // Create new version with character length constraints
    const truncatedRevision = finalRevision.length > 10 ? finalRevision.substring(0, 10) : finalRevision;
    const truncatedFileName = versionedFileName.length > 255 ? versionedFileName.substring(0, 252) + '...' : versionedFileName;
    const truncatedFileType = (file.mimetype || '').length > 50 ? (file.mimetype || '').substring(0, 50) : (file.mimetype || '');
    const truncatedMimeType = (file.mimetype || '').length > 100 ? (file.mimetype || '').substring(0, 100) : (file.mimetype || '');

    const [newVersion] = await db
      .insert(drawingVersions)
      .values({
        drawingId: drawingId,
        version: '1',
        revision: truncatedRevision,
        fileName: truncatedFileName,
        fileUrl: uploadResult.url,
        filePath: uploadResult.path || gcsPath,
        fileSize: file.size,
        fileType: truncatedFileType,
        mimeType: truncatedMimeType,
        uploadedBy: userId,
        createdBy: userId,
        uploadDate: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
        versionNotes: versionNotes || 'Initial version'
      })
      .returning();

    // Update drawing with current version ID
    await db
      .update(designDrawings)
      .set({ 
        currentVersionId: newVersion.id,
        updatedAt: new Date()
      })
      .where(eq(designDrawings.id, drawingId));

    // Get updated drawing info for response
    const updatedDrawing = await db
      .select()
      .from(designDrawings)
      .where(eq(designDrawings.id, drawingId))
      .limit(1);

    res.json({
      success: true,
      drawing: updatedDrawing[0],
      version: newVersion,
      message: `Drawing uploaded successfully with revision ${finalRevision}`
    });
  } catch (error) {
    console.error('Error uploading drawing:', error);
    res.status(500).json({ error: 'Failed to upload drawing' });
  }
});

// Upload new version of existing drawing
router.post('/drawings/:id/versions', authenticateUser, upload.single('file'), async (req, res) => {
  try {
    const drawingId = parseInt(req.params.id);
    const { versionNotes } = req.body;
    const file = req.file;
    const userId = req.user!.id;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Get drawing info
    const drawing = await db
      .select({
        id: designDrawings.id,
        drawingNumber: designDrawings.drawingNumber,
        designProjectId: designDrawings.designProjectId,
        projectCode: projects.code,
        projectDbId: projects.id,
      })
      .from(designDrawings)
      .leftJoin(designProjects, eq(designDrawings.designProjectId, designProjects.id))
      .leftJoin(projects, eq(designProjects.projectId, projects.id))
      .where(eq(designDrawings.id, drawingId))
      .limit(1);

    if (drawing.length === 0) {
      return res.status(404).json({ error: 'Drawing not found' });
    }

    // Get latest version number
    const latestVersion = await db
      .select({
        version: drawingVersions.version,
        revision: drawingVersions.revision
      })
      .from(drawingVersions)
      .where(eq(drawingVersions.drawingId, drawingId))
      .orderBy(desc(drawingVersions.uploadDate))
      .limit(1);

    let newVersion = '1';
    let newRevision = '0';

    if (latestVersion.length > 0) {
      const currentVersion = parseInt(latestVersion[0].version);
      const currentRevision = parseInt(latestVersion[0].revision);
      newVersion = (currentVersion).toString();
      newRevision = (currentRevision + 1).toString();
    }

    const projectCode = drawing[0].projectCode || 'UNKNOWN';
    const fileExtB = file.originalname.split('.').pop() || 'pdf';

    // Build TPEL governed GCS path via shared builder (G5: no writes to legacy paths)
    let gcsPath: string;
    if (!drawing[0].projectDbId) {
      return res.status(400).json({
        error: 'G5 violation: This drawing is not linked to an EPC project. Revision uploads require a linked EPC project to generate a governed TPEL path.',
      });
    }
    try {
      const geo = await resolveProjectGeoCodes(drawing[0].projectDbId);
      gcsPath = buildDrawingGcsPath(
        geo.continentCode, geo.countryCode, geo.customerShortCode,
        geo.fyCode, geo.projectSeq,
        'PROJ', drawing[0].drawingNumber, newRevision, fileExtB
      );
    } catch (geoErr: any) {
      return res.status(400).json({
        error: `G5 violation: Could not resolve TPEL geo-codes — ${geoErr?.message || 'unknown error'}. Ensure the project has continent/country/customer codes assigned.`,
      });
    }

    // Upload to GCS
    const uploadResult = await uploadFileWithDiagnostics(gcsPath, file.buffer, file.mimetype);
    if (!uploadResult.successful) {
      return res.status(500).json({ error: `Upload failed: ${uploadResult.error?.message || 'Unknown error'}` });
    }

    // Create new version
    const [newVersionRecord] = await db
      .insert(drawingVersions)
      .values({
        drawingId,
        version: newVersion,
        revision: newRevision,
        fileName: file.originalname,
        fileUrl: uploadResult.url,
        filePath: uploadResult.path || gcsPath,
        fileSize: file.size,
        fileType: file.mimetype,
        uploadedBy: userId,
        uploadDate: new Date(),
        versionNotes: versionNotes || `Version ${newVersion}.${newRevision}`
      })
      .returning();

    // Update drawing's current version and status
    await db
      .update(designDrawings)
      .set({ 
        currentVersionId: newVersionRecord.id,
        status: 'Active',
        updatedAt: new Date()
      })
      .where(eq(designDrawings.id, drawingId));

    res.json({
      success: true,
      version: newVersionRecord
    });
  } catch (error) {
    console.error('Error uploading drawing version:', error);
    res.status(500).json({ error: 'Failed to upload drawing version' });
  }
});

// Download drawing version — EPC-first read with legacy fallback
router.get('/versions/:versionId/download', authenticateUser, async (req, res) => {
  try {
    const versionId = parseInt(req.params.versionId);
    const userId = (req as any).user?.id || 1;
    
    const version = await db
      .select({
        id: drawingVersions.id,
        fileName: drawingVersions.fileName,
        fileUrl: drawingVersions.fileUrl,
        filePath: drawingVersions.filePath,
        fileSize: drawingVersions.fileSize,
        mimeType: drawingVersions.mimeType,
        revision: drawingVersions.revision,
        drawingId: drawingVersions.drawingId
      })
      .from(drawingVersions)
      .where(eq(drawingVersions.id, versionId))
      .limit(1);

    if (version.length === 0) {
      return res.status(404).json({ error: 'Drawing version not found' });
    }

    const versionData = version[0];
    const legacyPath = versionData.filePath || '';

    const resolved = await resolveDrawingVersionWithFallback(
      versionId,
      legacyPath,
      userId
    );

    if (resolved.source === 'epc') {
      const { bucket } = await initializeGCS();
      if (bucket) {
        const file = bucket.file(resolved.path);
        const [exists] = await file.exists();
        if (exists) {
          const [signedUrl] = await file.getSignedUrl({
            action: 'read',
            expires: Date.now() + (15 * 60 * 1000),
          });
          return res.json({ url: signedUrl, source: 'epc' });
        }
      }
    }

    if (versionData.fileUrl) {
      return res.redirect(versionData.fileUrl);
    }

    if (legacyPath) {
      const { bucket } = await initializeGCS();
      if (bucket) {
        const file = bucket.file(legacyPath);
        const [exists] = await file.exists();
        if (exists) {
          const [signedUrl] = await file.getSignedUrl({
            action: 'read',
            expires: Date.now() + (15 * 60 * 1000),
          });
          return res.json({ url: signedUrl, source: 'legacy' });
        }
      }
    }

    return res.status(404).json({ error: 'File not accessible' });
  } catch (error) {
    console.error('Error downloading drawing version:', error);
    res.status(500).json({ error: 'Failed to download drawing version' });
  }
});

export default router;