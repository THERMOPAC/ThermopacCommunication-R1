import { Request, Response, Router } from 'express';
import { ensureAuthenticated } from './auth-middleware';
import { pool } from './db';
import { paymentAllocationService } from './payment-allocation-service';
import { writeOffService } from './write-off-service';
import { batchAllocationService } from './batch-allocation-service';

const router = Router();

/**
 * Get overall financial dashboard data with proper financial year filtering
 */
router.get('/dashboard', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Get date range parameters from query string for financial year filtering
    const { from, to } = req.query;
    console.log('🎯 Finance dashboard API called with date params:', { from, to });
    
    // Build WHERE clause for date filtering if dates are provided
    let dateFilter = '';
    let queryParams: any[] = [];
    
    if (from && to) {
      dateFilter = 'WHERE issue_date >= $1 AND issue_date <= $2';
      queryParams = [from, to];
      console.log('Using date filter:', dateFilter, 'with params:', queryParams);
    } else {
      console.log('No date filtering - fetching all invoices');
    }
    
    // Get invoices from database with optional date filtering
    const invoicesQuery = `
      SELECT 
        COUNT(*) as "totalCount",
        COALESCE(SUM(total_amount), 0) as "totalAmount",
        COUNT(CASE WHEN status = 'Paid' THEN 1 END) as "paidCount",
        COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as "paidAmount",
        COUNT(CASE WHEN status != 'Paid' THEN 1 END) as "unpaidCount",
        COALESCE(SUM(CASE WHEN status != 'Paid' THEN total_amount ELSE 0 END), 0) as "unpaidAmount",
        COALESCE(SUM(CASE WHEN status != 'Paid' THEN outstanding_amount ELSE 0 END), 0) as "outstandingAmount",
        COUNT(CASE WHEN due_date < CURRENT_DATE AND status != 'Paid' THEN 1 END) as "overdueCount",
        COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE AND status != 'Paid' THEN outstanding_amount ELSE 0 END), 0) as "overdueAmount"
      FROM 
        invoices
      ${dateFilter}
    `;
    
    console.log('Executing invoice query:', invoicesQuery);
    console.log('With parameters:', queryParams);
    
    const invoiceStatsResult = await pool.query(invoicesQuery, queryParams);
    const invoiceStats = invoiceStatsResult.rows[0];
    
    console.log('Invoice stats result:', invoiceStats);
    
    // Get payment stats
    const paymentsQuery = `
      SELECT 
        COUNT(*) as "totalCount",
        COALESCE(SUM(amount), 0) as "totalAmount"
      FROM 
        payments
    `;
    
    const paymentStatsResult = await pool.query(paymentsQuery);
    const paymentStats = paymentStatsResult.rows[0];
    
    // Get recent invoices
    const recentInvoicesQuery = `
      SELECT 
        i.id,
        i.invoice_number as "invoiceNumber",
        c.bp_name as "clientName",
        i.issue_date as "issueDate",
        i.due_date as "dueDate",
        i.total_amount as "amount",
        i.status,
        CASE WHEN i.due_date < CURRENT_DATE AND i.status != 'Paid' THEN true ELSE false END as "overdue"
      FROM 
        invoices i
      LEFT JOIN 
        customers c ON i.customer_id = c.id
      ORDER BY 
        i.issue_date DESC
      LIMIT 5
    `;
    
    const recentInvoicesResult = await pool.query(recentInvoicesQuery);
    const recentInvoices = recentInvoicesResult.rows;
    
    // Get recent payments
    const recentPaymentsQuery = `
      SELECT 
        p.id,
        p.reference_number as "referenceNumber",
        c.bp_name as "clientName",
        p.payment_date as "paymentDate",
        p.amount,
        p.payment_method as "paymentMethod",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment",
        CASE WHEN p.unallocated_amount = p.amount THEN 'Unallocated'
             WHEN p.unallocated_amount > 0 THEN 'Partially Allocated'
             ELSE 'Fully Allocated' END as "allocationStatus",
        p.created_at as "createdAt",
        p.updated_at as "updatedAt"
      FROM 
        payments p
      LEFT JOIN 
        customers c ON p.customer_id = c.id
      ORDER BY 
        p.payment_date DESC
      LIMIT 5
    `;
    
    const recentPaymentsResult = await pool.query(recentPaymentsQuery);
    const latestPayments = recentPaymentsResult.rows;
    
    // Get all latest invoices with details
    const latestInvoicesQuery = `
      SELECT 
        i.id,
        i.invoice_number as "invoiceNumber",
        i.customer_id as "customerId",
        i.issue_date as "issueDate",
        i.due_date as "dueDate",
        i.total_amount as "totalAmount",
        i.currency,
        i.status,
        i.notes,
        i.created_at as "createdAt",
        i.updated_at as "updatedAt"
      FROM 
        invoices i
      ORDER BY 
        i.issue_date DESC
      LIMIT 5
    `;
    
    const latestInvoicesResult = await pool.query(latestInvoicesQuery);
    const latestInvoices = latestInvoicesResult.rows;
    
    // Calculate INR amount (for marketing dashboard)
    const exchangeRate = 85.60; // USD to INR
    const invoicedAmountUSD = parseFloat(invoiceStats.totalAmount || 0);
    const invoicedAmountINR = invoicedAmountUSD * exchangeRate;
    
    // Construct the dashboard data
    const dashboardData = {
      totalInvoices: {
        count: parseInt(invoiceStats.totalCount || 0),
        amount: parseFloat(invoiceStats.totalAmount || 0).toFixed(2)
      },
      totalPaid: {
        count: parseInt(invoiceStats.paidCount || 0),
        amount: parseFloat(invoiceStats.paidAmount || 0).toFixed(2)
      },
      totalUnpaid: {
        count: parseInt(invoiceStats.unpaidCount || 0),
        amount: parseFloat(invoiceStats.unpaidAmount || 0).toFixed(2)
      },
      outstandingInvoices: {
        count: parseInt(invoiceStats.unpaidCount || 0),
        amount: parseFloat(invoiceStats.outstandingAmount || 0).toFixed(2)
      },
      overdueInvoices: {
        count: parseInt(invoiceStats.overdueCount || 0),
        amount: parseFloat(invoiceStats.overdueAmount || 0).toFixed(2)
      },
      totalOutstanding: {
        count: parseInt(invoiceStats.unpaidCount || 0),
        amount: parseFloat(invoiceStats.outstandingAmount || 0).toFixed(2)
      },
      totalOverdue: {
        count: parseInt(invoiceStats.overdueCount || 0),
        amount: parseFloat(invoiceStats.overdueAmount || 0).toFixed(2)
      },
      totalPayments: {
        count: parseInt(paymentStats.totalCount || 0),
        amount: parseFloat(paymentStats.totalAmount || 0).toFixed(2)
      },
      recentInvoices,
      latestPayments,
      latestInvoices,
      
      // For marketing dashboard
      invoicedAmountUSD,
      invoicedAmountINR,
      exchangeRate
    };
    
    res.json(dashboardData);
  } catch (error) {
    console.error('Error getting dashboard data:', error);
    res.status(500).json({ error: 'Failed to get dashboard data' });
  }
});

/**
 * Get all invoices
 */
router.get('/invoices', ensureAuthenticated, (req: Request, res: Response) => {
  try {
    const invoices = [
      {
        id: 1,
        invoiceNumber: "INV-2526-001",
        customerId: 1,
        issueDate: "2025-05-01",
        dueDate: "2025-05-31",
        totalAmount: "125000.00",
        tax: "10000.00",
        currency: "USD",
        status: "Paid",
        notes: "Project A Phase 1",
        createdBy: 1,
        createdAt: "2025-05-01T10:00:00Z",
        updatedAt: "2025-06-15T10:00:00Z"
      },
      {
        id: 2,
        invoiceNumber: "INV-2526-002",
        customerId: 2,
        issueDate: "2025-06-01",
        dueDate: "2025-06-30",
        totalAmount: "100000.00",
        tax: "8000.00",
        currency: "USD",
        status: "Paid",
        notes: "Project B Initial Payment",
        createdBy: 1,
        createdAt: "2025-06-01T10:00:00Z",
        updatedAt: "2025-07-22T10:00:00Z"
      },
      {
        id: 3,
        invoiceNumber: "INV-2526-003",
        customerId: 3,
        issueDate: "2025-07-01",
        dueDate: "2025-07-31",
        totalAmount: "150000.00",
        tax: "12000.00",
        currency: "USD",
        status: "Unpaid",
        notes: "Project C Full Payment",
        createdBy: 1,
        createdAt: "2025-07-01T10:00:00Z",
        updatedAt: "2025-07-01T10:00:00Z"
      },
      {
        id: 4,
        invoiceNumber: "INV-2526-004",
        customerId: 1,
        issueDate: "2025-07-15",
        dueDate: "2025-08-15",
        totalAmount: "125000.00",
        tax: "10000.00",
        currency: "USD",
        status: "Unpaid",
        notes: "Project A Phase 2",
        createdBy: 1,
        createdAt: "2025-07-15T10:00:00Z",
        updatedAt: "2025-07-15T10:00:00Z"
      },
      {
        id: 5,
        invoiceNumber: "INV-2526-005",
        customerId: 4,
        issueDate: "2025-08-01",
        dueDate: "2025-08-31",
        totalAmount: "125000.00",
        tax: "10000.00",
        currency: "USD",
        status: "Unpaid",
        notes: "Project D Initial Payment",
        createdBy: 1,
        createdAt: "2025-08-01T10:00:00Z",
        updatedAt: "2025-08-01T10:00:00Z"
      }
    ];
    
    res.json(invoices);
  } catch (error) {
    console.error('Error getting invoices:', error);
    res.status(500).json({ error: 'Failed to get invoices' });
  }
});

/**
 * Get an invoice by ID from the /invoices/view/:id route
 */
router.get('/invoices/view/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const invoiceId = parseInt(req.params.id);
    if (isNaN(invoiceId)) {
      return res.status(400).json({ error: 'Invalid invoice ID' });
    }
    
    // Use direct database query to get the invoice
    const query = `
      SELECT 
        i.id, 
        i.invoice_number as "invoiceNumber", 
        i.customer_id as "customerId",
        i.project_id as "projectId",
        i.issue_date as "issueDate", 
        i.due_date as "dueDate", 
        i.total_amount as "totalAmount", 
        i.currency, 
        i.status,
        i.sap_invoice_no as "sapInvoiceNo", 
        i.invoice_type as "invoiceType",
        i.notes,
        i.created_at as "createdAt", 
        i.updated_at as "updatedAt",
        i.created_by as "createdBy"
      FROM invoices i
      WHERE i.id = $1
    `;
    
    const itemsQuery = `
      SELECT 
        id,
        invoice_id as "invoiceId",
        description,
        quantity,
        unit_price as "unitPrice",
        amount,
        created_at as "createdAt",
        updated_at as "updatedAt"
      FROM invoice_items
      WHERE invoice_id = $1
    `;
    
    const invoiceResult = await pool.query(query, [invoiceId]);
    
    if (!invoiceResult || !invoiceResult.rows || invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    const invoice = invoiceResult.rows[0];
    
    // Format dates for frontend
    if (invoice.issueDate) {
      invoice.issueDate = new Date(invoice.issueDate).toISOString().split('T')[0];
    }
    if (invoice.dueDate) {
      invoice.dueDate = new Date(invoice.dueDate).toISOString().split('T')[0];
    }
    
    // Try to get customer name
    try {
      if (invoice.customerId) {
        const customerQuery = `SELECT bp_name FROM customers WHERE id = $1`;
        const customerResult = await pool.query(customerQuery, [invoice.customerId]);
        if (customerResult && customerResult.rows && customerResult.rows.length > 0) {
          invoice.customerName = customerResult.rows[0].bp_name;
        } else {
          invoice.customerName = `Customer ${invoice.customerId}`;
        }
      }
    } catch (customerError) {
      console.error('Error getting customer name:', customerError);
      invoice.customerName = `Customer ${invoice.customerId}`;
    }
    
    // Get invoice items
    const itemsResult = await pool.query(itemsQuery, [invoiceId]);
    const items = itemsResult.rows || [];
    
    // Return the invoice and items in the format expected by the frontend
    res.json({
      invoice: invoice,
      items: items
    });
  } catch (error) {
    console.error(`Error getting invoice view ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Failed to get invoice',
      details: error.message
    });
  }
});

/**
 * Get a specific invoice by ID - using real database
 */
router.get('/invoices/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Skip if it's a special route like "outstanding", which is handled elsewhere
    if (id === 'outstanding') {
      return res.status(400).json({ error: 'Invalid invoice ID. Use /invoices/outstanding for outstanding invoices.' });
    }
    
    // Parse the ID to ensure it's a valid number
    const invoiceId = parseInt(id);
    if (isNaN(invoiceId)) {
      return res.status(400).json({ error: 'Invalid invoice ID - must be a number' });
    }
    
    // Use direct database query to get the invoice
    const query = `
      SELECT 
        i.id, 
        i.invoice_number as "invoiceNumber", 
        i.customer_id as "customerId",
        i.project_id as "projectId",
        i.issue_date as "issueDate", 
        i.due_date as "dueDate", 
        i.total_amount as "totalAmount", 
        i.currency, 
        i.status,
        i.sap_invoice_no as "sapInvoiceNo", 
        i.invoice_type as "invoiceType",
        i.notes,
        i.created_at as "createdAt", 
        i.updated_at as "updatedAt",
        i.created_by as "createdBy"
      FROM invoices i
      WHERE i.id = $1
    `;
    
    const itemsQuery = `
      SELECT 
        id,
        invoice_id as "invoiceId",
        description,
        quantity,
        unit_price as "unitPrice",
        amount,
        created_at as "createdAt",
        updated_at as "updatedAt"
      FROM invoice_items
      WHERE invoice_id = $1
    `;
    
    const invoiceResult = await pool.query(query, [invoiceId]);
    
    if (!invoiceResult || !invoiceResult.rows || invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    const invoice = invoiceResult.rows[0];
    
    // Format dates for frontend
    if (invoice.issueDate) {
      invoice.issueDate = new Date(invoice.issueDate).toISOString().split('T')[0];
    }
    if (invoice.dueDate) {
      invoice.dueDate = new Date(invoice.dueDate).toISOString().split('T')[0];
    }
    
    // Try to get customer name
    try {
      if (invoice.customerId) {
        const customerQuery = `SELECT bp_name FROM customers WHERE id = $1`;
        const customerResult = await pool.query(customerQuery, [invoice.customerId]);
        if (customerResult && customerResult.rows && customerResult.rows.length > 0) {
          invoice.customerName = customerResult.rows[0].bp_name;
        } else {
          invoice.customerName = `Customer ${invoice.customerId}`;
        }
      }
    } catch (customerError) {
      console.error('Error getting customer name:', customerError);
      invoice.customerName = `Customer ${invoice.customerId}`;
    }
    
    // Get invoice items
    const itemsResult = await pool.query(itemsQuery, [invoiceId]);
    const items = itemsResult.rows || [];
    
    // Return the invoice and items in the format expected by the frontend
    res.json({
      invoice: invoice,
      items: items
    });
  } catch (error) {
    console.error(`Error getting invoice ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to get invoice' });
  }
});

/**
 * Get all payments - FIXED to calculate allocations from payment_allocations table
 */
router.get('/payments', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('🔧 MAIN PAYMENTS PAGE: Using CORRECTED payment_allocations table calculation...');
    
    // Query payments with calculated allocations from payment_allocations table
    const query = `
      SELECT 
        p.id,
        p.irm_no as "paymentNumber",
        p.customer_id as "customerId",
        c.bp_name as "customerName",
        p.payment_date as "paymentDate",
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as "calculatedAllocatedAmount",
        p.payment_method as "paymentMethod",
        p.payment_type as "paymentType",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment",
        p.created_by as "createdBy",
        p.created_at as "createdAt",
        p.updated_at as "updatedAt"
      FROM 
        payments p
      LEFT JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.customer_id, p.payment_date, p.amount, 
        p.payment_method, p.payment_type, p.currency, p.notes, p.is_advance_payment,
        p.created_by, p.created_at, p.updated_at
      ORDER BY 
        p.payment_date DESC
    `;
    
    const result = await pool.query(query);
    const rawPayments = result.rows;
    
    console.log(`🔍 Raw query returned ${rawPayments.length} payments`);
    if (rawPayments.find(p => p.id === 63)) {
      const payment63 = rawPayments.find(p => p.id === 63);
      console.log('🔍 Payment ID 63 in main payments query:', {
        id: payment63.id,
        amount: payment63.amount,
        calculatedAllocatedAmount: payment63.calculatedAllocatedAmount,
        calculated_unallocated: parseFloat(payment63.amount) - parseFloat(payment63.calculatedAllocatedAmount || '0')
      });
    }
    
    // Format payments with calculated allocated and unallocated amounts
    const formattedPayments = rawPayments.map(payment => {
      const totalAmount = parseFloat(payment.amount);
      const calculatedAllocated = parseFloat(payment.calculatedAllocatedAmount || '0');
      const calculatedUnallocated = totalAmount - calculatedAllocated;
      
      return {
        id: payment.id,
        paymentNumber: payment.paymentNumber || `PAY-${payment.id}`,
        customerId: payment.customerId,
        customerName: payment.customerName,
        paymentDate: payment.paymentDate,
        amount: totalAmount.toString(),
        allocatedAmount: calculatedAllocated.toString(),
        unallocatedAmount: calculatedUnallocated.toString(),
        paymentMethod: payment.paymentMethod,
        paymentType: payment.paymentType,
        currency: payment.currency,
        notes: payment.notes,
        isAdvancePayment: payment.isAdvancePayment,
        allocationStatus: calculatedUnallocated === totalAmount ? 'Unallocated' :
                         calculatedUnallocated > 0 ? 'Partially Allocated' : 'Fully Allocated',
        createdBy: payment.createdBy,
        createdAt: payment.createdAt,
        updatedAt: payment.updatedAt
      };
    });
    
    console.log(`✅ Formatted ${formattedPayments.length} payments with correct allocation calculations`);
    
    // Return payments in a format the client expects
    res.json({ payments: formattedPayments });
  } catch (error) {
    console.error('Error getting payments:', error);
    res.status(500).json({ error: 'Failed to get payments' });
  }
});

/**
 * Get unallocated advance payments for a specific customer - FIXED to use payment_allocations table
 */
router.get('/payments/unallocated-advances/:customerId', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { customerId } = req.params;
    
    // Parse and validate the customer ID to ensure it's a valid number
    const customerIdNum = parseInt(customerId);
    if (isNaN(customerIdNum)) {
      return res.status(400).json({ error: 'Invalid customer ID - must be a number' });
    }
    
    // Get the invoice type from query params, handle 'all' value properly
    const invoiceType = (req.query.invoiceType && req.query.invoiceType !== 'all') 
      ? req.query.invoiceType as string 
      : null;
    
    console.log(`🔧 Fetching unallocated advance payments for customer ID: ${customerIdNum}, invoice type: ${invoiceType || 'all'}`);
    console.log('🔍 DEBUG: Using CORRECTED payment_allocations table calculation...');
    
    // First, let's debug Payment ID 63 specifically for this customer
    if (customerIdNum === 12) { // CASPIAN LUBRICANTS customer ID
      const debugQuery = `
        SELECT 
          p.id, 
          p.irm_no,
          p.amount,
          COALESCE(SUM(pa.amount_applied), 0) as calculated_allocated,
          p.amount - COALESCE(SUM(pa.amount_applied), 0) as remaining_amount,
          c.bp_name as customer_name
        FROM 
          payments p
        JOIN 
          customers c ON p.customer_id = c.id
        LEFT JOIN 
          payment_allocations pa ON p.id = pa.payment_id
        WHERE 
          p.id = 63 AND p.customer_id = $1
        GROUP BY 
          p.id, c.bp_name, p.irm_no, p.amount
      `;
      
      const debugResult = await pool.query(debugQuery, [customerIdNum]);
      if (debugResult.rows.length > 0) {
        const debug63 = debugResult.rows[0];
        console.log('🔍 Payment ID 63 Debug for Customer:', {
          id: debug63.id,
          irm_no: debug63.irm_no,
          total_amount: debug63.amount,
          calculated_allocated: debug63.calculated_allocated,
          remaining_amount: debug63.remaining_amount,
          should_be_excluded: debug63.remaining_amount <= 0.01,
          customer_name: debug63.customer_name
        });
      }
    }
    
    // Use payment_allocations table to calculate actual unallocated amounts
    const query = `
      SELECT 
        p.id,
        p.irm_no as "paymentReference",
        p.customer_id as "customerId",
        c.bp_name as "customerName",
        p.payment_date as "paymentDate",
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as "calculatedAllocatedAmount",
        p.payment_method as "paymentMethod",
        p.payment_type as "paymentType",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment"
      FROM 
        payments p
      JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      WHERE 
        p.customer_id = $1
        AND p.is_advance_payment = true
        ${invoiceType ? 'AND p.payment_type = $2' : ''}
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.customer_id, p.payment_date, p.amount, 
        p.payment_method, p.payment_type, p.currency, p.notes, p.is_advance_payment
      HAVING 
        p.amount - COALESCE(SUM(pa.amount_applied), 0) > 0.01
      ORDER BY 
        p.payment_date DESC
    `;
    
    // Add the invoice type parameter if it's provided
    const params = invoiceType ? [customerIdNum, invoiceType] : [customerIdNum];
    const result = await pool.query(query, params);
    const advances = result.rows;
    
    console.log(`Found ${advances.length} unallocated advance payments for customer ${customerIdNum}`);
    console.log('🔍 Payment IDs in result:', advances.map(p => p.id));
    
    // Format the response with calculated values
    const formattedAdvances = advances.map(payment => {
      const totalAmount = parseFloat(payment.amount);
      const calculatedAllocated = parseFloat(payment.calculatedAllocatedAmount || '0');
      const remainingAmount = totalAmount - calculatedAllocated;
      
      return {
        id: payment.id,
        paymentReference: payment.paymentReference,
        customerId: payment.customerId,
        customerName: payment.customerName,
        paymentDate: payment.paymentDate,
        amount: totalAmount.toString(),
        allocatedAmount: calculatedAllocated.toString(),
        unallocatedAmount: remainingAmount.toString(),
        paymentMethod: payment.paymentMethod,
        paymentType: payment.paymentType,
        currency: payment.currency,
        notes: payment.notes,
        isAdvancePayment: payment.isAdvancePayment
      };
    });
    
    // Calculate total unallocated amount
    const totalUnallocatedAmount = formattedAdvances.reduce((sum, payment) => 
      sum + parseFloat(payment.unallocatedAmount), 0).toFixed(2);
    
    // Return the advances and total
    res.json({
      advances: formattedAdvances,
      totalUnallocatedAmount,
      currency: formattedAdvances.length > 0 ? formattedAdvances[0].currency : 'USD'
    });
  } catch (error) {
    console.error(`Error getting unallocated advances for customer ${req.params.customerId}:`, error);
    res.status(500).json({ error: 'Failed to get unallocated advance payments' });
  }
});

/**
 * Create a new payment allocation (manually apply a payment to an invoice)
 */
router.post('/allocations', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { paymentId, invoiceId, amount } = req.body;
    
    if (!paymentId || !invoiceId || !amount) {
      return res.status(400).json({ 
        error: 'Missing required fields. Please provide paymentId, invoiceId, and amount.' 
      });
    }
    
    // Use the payment allocation service imported at the top of the file
    
    // Create the allocation
    const allocation = await paymentAllocationService.allocatePaymentToInvoice(
      parseInt(paymentId),
      parseInt(invoiceId),
      parseFloat(amount),
      req.user?.id
    );
    
    // Return the created allocation
    res.status(201).json(allocation);
  } catch (error: any) {
    console.error('Error creating payment allocation:', error);
    res.status(500).json({ 
      error: 'Failed to create payment allocation',
      message: error.message
    });
  }
});

/**
 * Remove a payment allocation
 */
router.delete('/allocations/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Import the payment allocation service
    // Using paymentAllocationService imported at the top of the file
    
    // Remove the allocation
    const result = await paymentAllocationService.removeAllocation(parseInt(id));
    
    // Return success message
    res.json(result);
  } catch (error: any) {
    console.error(`Error removing allocation ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to remove payment allocation',
      message: error.message
    });
  }
});

/**
 * Get a specific payment by ID
 */
router.get('/payments/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const paymentId = parseInt(req.params.id);
    console.log(`[DEBUG] Fetching payment details for payment ID: ${paymentId}`);
    
    // Set headers to prevent caching and force fresh data
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('ETag', `payment-${paymentId}-${Date.now()}`);
    
    if (isNaN(paymentId)) {
      return res.status(400).json({ error: 'Invalid payment ID' });
    }
    
    // Get payment details from database
    const paymentQuery = `
      SELECT 
        p.id,
        p.reference_number as "referenceNumber",
        p.customer_id as "customerId",
        c.bp_name as "customerName",
        p.irm_no as "irmNo",
        p.irm_no as "paymentNumber",
        p.payment_date as "paymentDate",
        p.sap_payment_no as "sapPaymentNo",
        p.payment_type as "paymentType",
        p.amount,
        p.allocated_amount as "allocatedAmount",
        p.unallocated_amount as "unallocatedAmount",
        p.payment_method as "paymentMethod",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment",
        CASE WHEN p.unallocated_amount = p.amount THEN 'Unallocated'
             WHEN p.unallocated_amount > 0 THEN 'Partially Allocated'
             ELSE 'Fully Allocated' END as "allocationStatus",
        p.created_by as "createdBy",
        p.created_at as "createdAt",
        p.updated_at as "updatedAt"
      FROM 
        payments p
      LEFT JOIN 
        customers c ON p.customer_id = c.id
      WHERE 
        p.id = $1
    `;
    
    const paymentResult = await pool.query(paymentQuery, [paymentId]);
    
    if (!paymentResult.rows || paymentResult.rows.length === 0) {
      console.log(`Payment with ID ${paymentId} not found in database`);
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    // Get the raw payment data
    const rawPayment = paymentResult.rows[0];
    console.log(`Found payment in database: ${rawPayment.referenceNumber}`);
    
    // Debug log to see what's in the raw payment data
    console.log('Raw payment data from database:', {
      id: rawPayment.id,
      irmNo: rawPayment.irmNo,
      irm_no: rawPayment.irm_no,
      notes: rawPayment.notes,
      paymentMethod: rawPayment.paymentMethod
    });

    // Format the payment with all required fields to ensure consistent structure
    const payment = {
      id: rawPayment.id,
      referenceNumber: rawPayment.referenceNumber,
      customerId: rawPayment.customerId,
      customerName: rawPayment.customerName,
      irmNo: rawPayment.irmNo || rawPayment.irm_no || '',  // Handle both camelCase and snake_case
      paymentDate: rawPayment.paymentDate,
      sapPaymentNo: rawPayment.sapPaymentNo,
      paymentType: rawPayment.paymentType,
      amount: rawPayment.amount,
      allocatedAmount: rawPayment.allocatedAmount,
      unallocatedAmount: rawPayment.unallocatedAmount,
      paymentMethod: rawPayment.paymentMethod,
      currency: rawPayment.currency,
      notes: rawPayment.notes,
      isAdvancePayment: rawPayment.isAdvancePayment,
      allocationStatus: rawPayment.allocationStatus,
      createdBy: rawPayment.createdBy,
      createdAt: rawPayment.createdAt,
      updatedAt: rawPayment.updatedAt
    };
    
    console.log('Formatted payment data being sent to frontend:', {
      id: payment.id,
      irmNo: payment.irmNo,
      notes: payment.notes,
      paymentMethod: payment.paymentMethod
    });
    
    // Get any invoice allocation links
    let allocations = [];
    try {
      const allocationsQuery = `
        SELECT 
          pa.id,
          pa.payment_id as "paymentId",
          pa.invoice_id as "invoiceId",
          pa.amount_applied as "amountApplied",
          pa.created_at as "createdAt",
          pa.updated_at as "updatedAt"
        FROM 
          payment_allocations pa
        WHERE 
          pa.payment_id = $1
      `;
      
      const allocationsResult = await pool.query(allocationsQuery, [paymentId]);
      allocations = allocationsResult.rows || [];
    } catch (allocErr) {
      console.log('No payment allocations found or table not yet created:', allocErr.message);
      allocations = [];
    }
    
    // Get related invoice details if there are allocations
    const invoiceLinks = [];
    
    if (allocations.length > 0) {
      try {
        for (const allocation of allocations) {
          try {
            const invoiceQuery = `
              SELECT 
                i.id,
                i.invoice_number as "invoiceNumber",
                i.customer_id as "customerId",
                i.issue_date as "issueDate", 
                i.due_date as "dueDate", 
                i.total_amount as "totalAmount",
                i.currency, 
                i.status,
                i.notes,
                i.created_by as "createdBy",
                i.created_at as "createdAt", 
                i.updated_at as "updatedAt"
              FROM 
                invoices i
              WHERE 
                i.id = $1
            `;
            
            const invoiceResult = await pool.query(invoiceQuery, [allocation.invoiceId]);
            
            if (invoiceResult.rows && invoiceResult.rows.length > 0) {
              invoiceLinks.push({
                link: allocation,
                invoice: invoiceResult.rows[0]
              });
            }
          } catch (invoiceErr) {
            console.error(`Error getting invoice detail for invoice ${allocation.invoiceId}:`, invoiceErr.message);
          }
        }
      } catch (err) {
        console.error('Error processing payment allocations:', err.message);
      }
    }
    
    // Format dates for the frontend
    if (payment.paymentDate) {
      payment.paymentDate = new Date(payment.paymentDate).toISOString().split('T')[0];
    }
    
    // Ensure amount is properly formatted as string
    if (payment.amount) {
      payment.amount = payment.amount.toString();
    }
    
    if (payment.allocatedAmount) {
      payment.allocatedAmount = payment.allocatedAmount.toString();
    }
    
    if (payment.unallocatedAmount) {
      payment.unallocatedAmount = payment.unallocatedAmount.toString();
    }
    
    // Return the payment details and any linked invoices
    const responseData = {
      payment,
      invoiceLinks
    };
    
    // Send the response
    res.json(responseData);
  } catch (error) {
    console.error(`Error getting payment ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to get payment' });
  }
});

/**
 * Create a new invoice
 */
router.post('/invoices', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Log the received data for debugging
    console.log('Creating invoice with data:', JSON.stringify(req.body, null, 2));
    
    // Extract data from the request body
    const { invoice, items, advancePaymentAllocations } = req.body;
    
    if (!invoice) {
      return res.status(400).json({ error: 'Invalid request body - invoice data missing' });
    }
    
    // Get a fresh invoice number from the server instead of using the one from the client
    // This ensures we have the latest invoice number
    const date = new Date();
    const startYear = date.getMonth() >= 3 ? date.getFullYear() : date.getFullYear() - 1;
    const endYear = startYear + 1;
    const startYearStr = startYear.toString().substring(2);
    const endYearStr = endYear.toString().substring(2);
    const financialYear = `${startYearStr}${endYearStr}`;
    
    // Set a high base number to avoid conflicts
    let nextSequenceNum = 40; // Start from 041
    
    // Find the highest invoice number currently in use
    const maxInvoiceQuery = `
      SELECT invoice_number FROM invoices 
      WHERE invoice_number LIKE $1 
      ORDER BY invoice_number DESC LIMIT 1
    `;
    const maxResult = await pool.query(maxInvoiceQuery, [`INV-${financialYear}-%`]);
    
    if (maxResult.rows.length > 0) {
      const match = maxResult.rows[0].invoice_number.match(/INV-(\d{4})-(\d{3})/);
      if (match && match[2]) {
        const currentMax = parseInt(match[2]);
        nextSequenceNum = Math.max(nextSequenceNum, currentMax + 1);
      }
    }
    
    // Generate a guaranteed unique invoice number
    const sequenceStr = nextSequenceNum.toString().padStart(3, '0');
    const uniqueInvoiceNumber = `INV-${financialYear}-${sequenceStr}`;
    
    // Override the client-provided invoice number with our guaranteed unique one
    console.log(`Using system-generated invoice number: ${uniqueInvoiceNumber} instead of ${invoice.invoiceNumber}`);
    invoice.invoiceNumber = uniqueInvoiceNumber;
    
    // Log advance payment allocations if present
    if (advancePaymentAllocations && advancePaymentAllocations.length > 0) {
      console.log('Processing advance payment allocations:', JSON.stringify(advancePaymentAllocations, null, 2));
    }

    // Format dates - ensure we have valid dates for required fields
    const issueDate = invoice.issueDate ? new Date(invoice.issueDate) : new Date();
    const dueDate = invoice.dueDate ? new Date(invoice.dueDate) : new Date(new Date().setDate(new Date().getDate() + 30));
    
    // Calculate total amount from items if not provided
    const totalAmount = invoice.totalAmount || (items && items.length > 0 
                 ? items.reduce((sum, item) => sum + parseFloat(item.amount || '0'), 0) 
                 : 0);
    
    // Create invoice in database with direct query
    const insertInvoiceQuery = `
      INSERT INTO invoices (
        invoice_number, 
        customer_id, 
        project_id, 
        issue_date, 
        due_date, 
        total_amount, 
        paid_amount,
        outstanding_amount,
        currency, 
        status,
        sap_invoice_no,
        invoice_type,
        notes,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING id, invoice_number as "invoiceNumber", created_at as "createdAt", updated_at as "updatedAt"
    `;
    
    const invoiceValues = [
      invoice.invoiceNumber,
      invoice.customerId,
      invoice.projectId || null,
      issueDate.toISOString().split('T')[0], // Format as YYYY-MM-DD for SQL
      dueDate.toISOString().split('T')[0], // Format as YYYY-MM-DD for SQL
      totalAmount,
      0, // paid_amount = 0 (no payments yet)
      totalAmount, // outstanding_amount = total_amount (full amount outstanding)
      invoice.currency || 'USD',
      'Pending',
      invoice.sapInvoiceNo || null,
      invoice.invoiceType || 'Product',
      invoice.notes || null,
      req.user?.id
    ];
    
    console.log('Executing SQL with values:', invoiceValues);
    const invoiceResult = await pool.query(insertInvoiceQuery, invoiceValues);
    
    if (!invoiceResult || !invoiceResult.rows || invoiceResult.rows.length === 0) {
      throw new Error('Failed to create invoice in database');
    }
    
    const newInvoice = invoiceResult.rows[0];
    const invoiceId = newInvoice.id;
    
    // Create invoice items
    if (items && items.length > 0) {
      for (const item of items) {
        const insertItemQuery = `
          INSERT INTO invoice_items (
            invoice_id,
            description,
            quantity,
            unit_price,
            amount
          ) VALUES ($1, $2, $3, $4, $5)
          RETURNING id
        `;
        
        const quantity = item.quantity || 1;
        const unitPrice = parseFloat(item.amount) / quantity;
        
        const itemValues = [
          invoiceId,
          item.description || '',
          quantity,
          unitPrice,
          parseFloat(item.amount) || 0
        ];
        
        await pool.query(insertItemQuery, itemValues);
      }
    }
    
    // Process advance payment allocations if provided
    let advancePaymentsApplied = 0;
    let totalAdvanceAmount = 0;
    
    if (advancePaymentAllocations && advancePaymentAllocations.length > 0) {
      // Filter allocations with valid amounts
      const validAllocations = advancePaymentAllocations.filter(
        allocation => allocation.amountToApply && parseFloat(allocation.amountToApply) > 0
      );
      
      advancePaymentsApplied = validAllocations.length;
      
      if (advancePaymentsApplied > 0) {
        console.log(`Processing ${advancePaymentsApplied} advance payment allocations`);
        
        // Import the payment allocation service
        // Using paymentAllocationService imported at the top of the file
        
        try {
          // Apply advance payments using our service
          const result = await paymentAllocationService.applyAdvancePaymentsToInvoice(
            invoiceId,
            invoice.customerId,
            validAllocations.map(allocation => ({
              paymentId: allocation.paymentId,
              amountToApply: parseFloat(allocation.amountToApply)
            })),
            req.user?.id
          );
          
          console.log('Applied advance payments:', result);
          
          totalAdvanceAmount = result.totalApplied;
          advancePaymentsApplied = result.allocations.length;
          
          // The service has already updated:
          // 1. Created payment allocation records
          // 2. Updated payment unallocated amounts
          // 3. Updated invoice outstanding amount
          // 4. Updated invoice status
        } catch (error) {
          console.error('Error applying advance payments:', error);
          // Continue with invoice creation even if advance payment application fails
        }
      }
    } else {
      // If no advance payments were specified but there are unallocated advances for this customer,
      // automatically apply available advance payments
      console.log('Checking for available advance payments to apply automatically');
      
      try {
        // First, initialize outstanding_amount to total_amount
        await pool.query(
          'UPDATE invoices SET outstanding_amount = total_amount WHERE id = $1',
          [invoiceId]
        );
        
        // Query for available advance payments for this customer and matching type
        const advancePaymentsQuery = `
          SELECT id, unallocated_amount 
          FROM payments 
          WHERE customer_id = $1 
            AND is_advance_payment = true 
            AND unallocated_amount > 0
            AND payment_type = $2
          ORDER BY payment_date ASC
        `;
        
        const advancePaymentsResult = await pool.query(
          advancePaymentsQuery, 
          [invoice.customerId, invoice.invoiceType]
        );
        
        if (advancePaymentsResult.rows.length > 0) {
          console.log(`Found ${advancePaymentsResult.rows.length} advance payments available for auto-allocation`);
          
          // Create allocation data for each advance payment
          const advanceAllocations = advancePaymentsResult.rows.map(payment => ({
            paymentId: payment.id,
            amountToApply: parseFloat(payment.unallocated_amount)
          }));
          
          // Apply advance payments using our service
          const result = await paymentAllocationService.applyAdvancePaymentsToInvoice(
            invoiceId,
            invoice.customerId,
            advanceAllocations,
            req.user?.id
          );
          
          console.log('Auto-applied advance payments:', result);
          
          totalAdvanceAmount = result.totalApplied;
          advancePaymentsApplied = result.allocations.length;
        } else {
          console.log('No available advance payments found for auto-allocation');
        }
      } catch (error) {
        console.error('Error auto-applying advance payments:', error);
        // Continue with invoice creation even if advance payment application fails
      }
    }
    
    // Log the success
    console.log('Successfully created invoice in database:', invoiceId);
    
    // Return success response with the newly created invoice data
    res.status(201).json({
      id: invoiceId,
      invoiceNumber: invoice.invoiceNumber,
      customerId: invoice.customerId,
      projectId: invoice.projectId,
      issueDate: issueDate.toISOString().split('T')[0],
      dueDate: dueDate.toISOString().split('T')[0],
      totalAmount: totalAmount,
      currency: invoice.currency || 'USD',
      sapInvoiceNo: invoice.sapInvoiceNo || null,
      invoiceType: invoice.invoiceType || 'Product',
      status: totalAdvanceAmount >= parseFloat(totalAmount.toString()) ? 'Paid' : 'Pending',
      notes: invoice.notes || null,
      createdBy: req.user?.id,
      createdAt: newInvoice.createdAt,
      updatedAt: newInvoice.updatedAt,
      // Include advance payment information in the response
      advancePaymentsApplied,
      totalAdvanceAmount,
      remainingBalance: Math.max(0, parseFloat(totalAmount.toString()) - totalAdvanceAmount)
    });
  } catch (error: any) {
    console.error('Error creating invoice:', error);
    res.status(500).json({ 
      error: 'Failed to create invoice',
      details: error.message 
    });
  }
});

/**
 * Create a new payment with database ID as identifier
 */
// Simple payment creation endpoint
router.post('/payments/simple-create', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Extract payment data from request
    const paymentData = req.body.payment || req.body;
    const userId = (req.user as any)?.id || 1;

    // Format payment date
    let paymentDate = new Date();
    if (paymentData.paymentDate) {
      paymentDate = new Date(paymentData.paymentDate);
    }
    const formattedDate = paymentDate.toISOString().split('T')[0];

    // Insert payment directly with minimal processing
    const result = await pool.query(`
      INSERT INTO payments (
        reference_number, irm_no, payment_date, sap_payment_no, payment_type, 
        amount, currency, payment_method, notes, is_advance_payment, 
        allocated_amount, unallocated_amount, customer_id, created_by
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
      ) RETURNING *
    `, [
      'TMP-PAYMENT', // Will update this after insertion
      paymentData.irmNo || null,
      formattedDate,
      paymentData.sapPaymentNo || null,
      paymentData.paymentType || 'Product',
      parseFloat(paymentData.amount),
      paymentData.currency || 'USD',
      paymentData.paymentMethod || 'bank transfer',
      paymentData.notes || null,
      paymentData.isAdvancePayment === false ? false : true, // Default to true if not provided
      0.00, // Start with zero allocated
      parseFloat(paymentData.amount), // All amount starts as unallocated
      parseInt(paymentData.customerId) || null,
      userId
    ]);

    if (!result.rows || result.rows.length === 0) {
      return res.status(500).json({ error: 'Failed to create payment record' });
    }

    // Get the newly created payment
    const newPayment = result.rows[0];
    
    // Update reference number to use payment ID
    const refNumber = `PAY-2526-${newPayment.id}`;
    await pool.query('UPDATE payments SET reference_number = $1 WHERE id = $2', [refNumber, newPayment.id]);
    
    // Return success with payment details
    return res.status(201).json({
      success: true,
      id: newPayment.id,
      referenceNumber: refNumber,
      message: `Payment successfully created with ID: ${newPayment.id}`
    });
  } catch (error) {
    console.error('Error in simple payment creation:', error);
    return res.status(500).json({ 
      error: 'Failed to create payment',
      details: error.message
    });
  }
});

// Original payment creation endpoint (maintaining for compatibility)
router.post('/payments', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Extract data from the request
    const paymentData = req.body.payment || req.body;
    const invoiceLinks = req.body.invoiceLinks || [];
    
    // Get the authenticated user
    const userId = (req.user as any)?.id || 1;
    
    // Validate date format
    let paymentDate;
    try {
      // Handle date format - try to parse and format correctly for SQL
      if (paymentData.paymentDate) {
        const dateString = paymentData.paymentDate;
        // Try to parse the date
        if (typeof dateString === 'string') {
          // If it's a string date (like "2025-05-18")
          paymentDate = new Date(dateString);
        } else {
          // If it's already a date object
          paymentDate = new Date(dateString);
        }
        // Check if date is valid
        if (isNaN(paymentDate.getTime())) {
          console.error('Invalid payment date provided:', dateString);
          paymentDate = new Date(); // Fallback to current date
        }
      } else {
        // Default to current date if none provided
        paymentDate = new Date();
      }
    } catch (error) {
      console.error('Error parsing payment date:', error);
      paymentDate = new Date(); // Fallback to current date
    }
    
    // Format the date as YYYY-MM-DD for SQL
    const formattedDate = paymentDate.toISOString().split('T')[0];
    console.log('Formatted payment date:', formattedDate);
    
    // Create a clean payment record for the database
    const payment = {
      reference_number: null, // Initially set to null, will be updated with ID after creation
      irm_no: paymentData.irmNo || null,
      payment_date: formattedDate, // Use the properly formatted date
      sap_payment_no: paymentData.sapPaymentNo || null,
      payment_type: paymentData.paymentType || 'Product',
      amount: parseFloat(paymentData.amount),
      currency: paymentData.currency || "USD",
      payment_method: paymentData.paymentMethod,
      notes: paymentData.notes || null,
      is_advance_payment: paymentData.isAdvancePayment || false,
      allocated_amount: 0.00, // Start with zero allocated amount
      unallocated_amount: parseFloat(paymentData.amount), // Start with all amount unallocated
      customer_id: paymentData.customerId ? parseInt(paymentData.customerId) : null,
      created_by: userId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    // Insert the payment into the database with explicit auto-increment ID
    // Check if the payments table exists first
    try {
      await pool.query('SELECT COUNT(*) FROM payments LIMIT 1');
      console.log('Payments table exists and is accessible');
    } catch (tableError) {
      console.error('Error accessing payments table:', tableError);
      // Create the table if it doesn't exist
      try {
        const createTableQuery = `
          CREATE TABLE IF NOT EXISTS payments (
            id SERIAL PRIMARY KEY,
            reference_number VARCHAR(255),
            irm_no VARCHAR(255),
            payment_date DATE,
            sap_payment_no VARCHAR(255),
            payment_type VARCHAR(50),
            amount DECIMAL(15,2),
            currency VARCHAR(10),
            payment_method VARCHAR(50),
            notes TEXT,
            is_advance_payment BOOLEAN DEFAULT false,
            allocated_amount DECIMAL(15,2) DEFAULT 0.00,
            unallocated_amount DECIMAL(15,2) DEFAULT 0.00,
            customer_id INTEGER,
            created_by INTEGER,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
          )
        `;
        await pool.query(createTableQuery);
        console.log('Successfully created payments table');
      } catch (createError) {
        console.error('Failed to create payments table:', createError);
      }
    }

    const insertPaymentQuery = `
      INSERT INTO payments (
        reference_number, irm_no, payment_date, sap_payment_no, payment_type, amount, currency, payment_method, 
        notes, is_advance_payment, allocated_amount, unallocated_amount, customer_id,
        created_by, created_at, updated_at
      ) 
      VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
      )
      RETURNING *
    `;
    
    // Debug logging for payment creation
    console.log('Creating payment with data:', {
      reference_number: payment.reference_number,
      payment_date: payment.payment_date,
      amount: payment.amount,
      currency: payment.currency,
      method: payment.payment_method,
      type: payment.payment_type,
      customer_id: payment.customer_id,
      is_advance_payment: payment.is_advance_payment
    });
    
    // Debug the incoming payment values
    console.log('Payment values to be inserted:', {
      reference_number: payment.reference_number,
      irm_no: payment.irm_no,
      payment_date: payment.payment_date,
      sap_payment_no: payment.sap_payment_no,
      payment_type: payment.payment_type,
      amount: payment.amount,
      currency: payment.currency,
      payment_method: payment.payment_method,
      notes: payment.notes,
      is_advance_payment: payment.is_advance_payment,
      allocated_amount: payment.allocated_amount,
      unallocated_amount: payment.unallocated_amount,
      customer_id: payment.customer_id,
      created_by: payment.created_by
    });
    
    const paymentValues = [
      payment.reference_number,
      payment.irm_no,
      payment.payment_date,
      payment.sap_payment_no,
      payment.payment_type,
      payment.amount,
      payment.currency,
      payment.payment_method,
      payment.notes,
      payment.is_advance_payment,
      payment.allocated_amount,
      payment.unallocated_amount,
      payment.customer_id,
      payment.created_by,
      payment.created_at,
      payment.updated_at
    ];
    
    const paymentResult = await pool.query(insertPaymentQuery, paymentValues);
    
    if (!paymentResult.rows || paymentResult.rows.length === 0) {
      throw new Error("Failed to create payment");
    }
    
    let newPayment = paymentResult.rows[0];
    console.log(`Created payment with ID: ${newPayment.id}`);
    
    // Always update the reference_number to be the payment ID
    const updateRefQuery = `
      UPDATE payments 
      SET reference_number = $1 
      WHERE id = $2
      RETURNING *
    `;
    const updateResult = await pool.query(updateRefQuery, [
      String(newPayment.id),
      newPayment.id
    ]);
    
    if (updateResult.rows && updateResult.rows.length > 0) {
      newPayment = updateResult.rows[0];
      console.log(`Updated payment reference to ID: ${newPayment.id}`);
    }
    
    // If there are invoice links, create them as well
    let allocations = [];
    if (invoiceLinks && invoiceLinks.length > 0) {
      for (const link of invoiceLinks) {
        const allocationQuery = `
          INSERT INTO payment_allocations (
            payment_id, invoice_id, amount_applied, created_at, updated_at
          ) 
          VALUES ($1, $2, $3, $4, $5)
          RETURNING *
        `;
        
        const allocationValues = [
          newPayment.id,
          parseInt(link.invoiceId),
          parseFloat(link.amountApplied),
          new Date().toISOString(),
          new Date().toISOString()
        ];
        
        const allocationResult = await pool.query(allocationQuery, allocationValues);
        
        if (allocationResult.rows && allocationResult.rows.length > 0) {
          allocations.push(allocationResult.rows[0]);
          
          // Update unallocated amount for the payment
          const updatePaymentQuery = `
            UPDATE payments 
            SET unallocated_amount = unallocated_amount - $1, updated_at = $2
            WHERE id = $3
            RETURNING *
          `;
          
          await pool.query(updatePaymentQuery, [
            parseFloat(link.amountApplied),
            new Date().toISOString(),
            newPayment.id
          ]);
          
          // Update invoice outstanding amount and status if needed
          const updateInvoiceQuery = `
            UPDATE invoices 
            SET 
              outstanding_amount = CASE 
                WHEN outstanding_amount IS NULL THEN total_amount - $1
                ELSE outstanding_amount - $1
              END,
              status = CASE 
                WHEN (outstanding_amount - $1) <= 0 THEN 'Paid'
                ELSE status
              END,
              updated_at = $2
            WHERE id = $3
            RETURNING *
          `;
          
          await pool.query(updateInvoiceQuery, [
            parseFloat(link.amountApplied),
            new Date().toISOString(),
            parseInt(link.invoiceId)
          ]);
        }
      }
    }
    
    // Update the payment to use a properly formatted reference number
    // Format: PAY-2526-{ID}
    const formattedRefNumber = `PAY-2526-${newPayment.id}`;
    console.log(`Setting formatted reference number: ${formattedRefNumber} for payment ID: ${newPayment.id}`);
    
    const updateRefQuery = `
      UPDATE payments 
      SET reference_number = $1
      WHERE id = $2
      RETURNING *
    `;
    
    let updatedPaymentResult;
    try {
      updatedPaymentResult = await pool.query(updateRefQuery, [
        formattedRefNumber, // Use a properly formatted reference number
        newPayment.id
      ]);
      
      if (updatedPaymentResult.rows && updatedPaymentResult.rows.length > 0) {
        newPayment = updatedPaymentResult.rows[0];
        console.log(`Successfully updated payment reference number to: ${formattedRefNumber}`);
      }
    } catch (updateRefError) {
      console.error(`Error updating payment reference number: ${updateRefError.message}`);
      // Continue even if reference update fails - at least we have a payment record
    }
    
    // Display more detailed logging for troubleshooting
    console.log(`Payment created successfully with ID: ${newPayment.id}`);
    console.log(`Full payment record:`, JSON.stringify(newPayment));

    // Ensure we're returning a real numeric ID, not a string like "system-generated"
    if (!newPayment.id || isNaN(Number(newPayment.id))) {
      console.error("Critical error: Payment created but returned invalid ID:", newPayment.id);
      // Attempt to retrieve the payment record using other identifiers
      try {
        // Try to retrieve the most recently created payment for this customer
        const retrieveQuery = `
          SELECT * FROM payments 
          WHERE customer_id = $1 
          ORDER BY created_at DESC 
          LIMIT 1
        `;
        const retrieveResult = await pool.query(retrieveQuery, [payment.customerId]);
        if (retrieveResult.rows && retrieveResult.rows.length > 0) {
          newPayment = retrieveResult.rows[0];
          console.log("Successfully retrieved payment with backup method:", newPayment.id);
        }
      } catch (retrieveError) {
        console.error("Failed to retrieve payment with backup method:", retrieveError);
      }
    }
    
    // Double-check ID is valid before returning
    const paymentId = newPayment.id ? Number(newPayment.id) : null;
    
    // Return a detailed success response with the formatted data
    const formattedPayment = {
      success: true,
      id: paymentId,
      referenceNumber: formattedRefNumber,
      paymentDate: newPayment.payment_date,
      amount: newPayment.amount,
      currency: newPayment.currency,
      message: `Payment successfully created with ID: ${paymentId}`,
      // Include full payment for debugging
      payment: newPayment
    };
    
    // Set content type explicitly to ensure it's recognized as JSON
    res.setHeader('Content-Type', 'application/json');
    res.status(201).json(formattedPayment);
  } catch (error) {
    console.error('Error creating payment:', error);
    res.status(500).json({ 
      error: 'Failed to create payment',
      details: error.message 
    });
  }
});

/**
 * Update an existing payment
 */
router.put('/payments/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const paymentId = parseInt(req.params.id, 10);
    
    if (isNaN(paymentId)) {
      return res.status(400).json({ error: 'Invalid payment ID' });
    }
    
    // Get payment data from request body
    const { payment, invoiceLinks } = req.body;
    
    if (!payment) {
      return res.status(400).json({ error: 'Invalid request body - payment data missing' });
    }
    
    console.log(`Updating payment with ID ${paymentId}:`, payment);
    
    // Format dates for the database
    const paymentDate = payment.paymentDate ? new Date(payment.paymentDate) : new Date();
    
    // Log detailed payment values for debugging
    console.log('Payment values received:', {
      referenceNumber: payment.referenceNumber,
      paymentDate: payment.paymentDate,
      sapPaymentNo: payment.sapPaymentNo,
      paymentType: payment.paymentType,
      amount: payment.amount,
      currency: payment.currency,
      paymentMethod: payment.paymentMethod,
      notes: payment.notes,
      isAdvancePayment: payment.isAdvancePayment,
      customerId: payment.customerId
    });
    
    // Ensure all fields are properly processed from all possible variations
    const sapPaymentNo = payment.sapPaymentNo || payment.sap_payment_no || null;
    const paymentType = payment.paymentType || payment.payment_type || 'Product';
    const irmNo = payment.irmNo || payment.irm_no || null;
    
    console.log('IRM NO value for update:', irmNo);
    
    // First, retrieve current payment data to check allocated amount
    const currentPaymentQuery = `
      SELECT amount, unallocated_amount 
      FROM payments 
      WHERE id = $1
    `;
    const currentPaymentResult = await pool.query(currentPaymentQuery, [paymentId]);
    const currentPayment = currentPaymentResult.rows[0];
    
    if (!currentPayment) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    // Get existing allocation information
    const currentAmount = parseFloat(currentPayment.amount);
    const currentUnallocated = parseFloat(currentPayment.unallocated_amount || currentAmount);
    
    // Calculate allocated amount - either use the existing allocated_amount or calculate it
    let allocatedAmount = 0;
    if ('allocated_amount' in currentPayment) {
      // Use the existing allocated_amount if it exists
      allocatedAmount = parseFloat(currentPayment.allocated_amount || 0);
    } else {
      // Fall back to calculating it from amount - unallocated (for backward compatibility)
      allocatedAmount = currentAmount - currentUnallocated;
    }
    
    // Calculate new unallocated amount
    const newAmount = parseFloat(payment.amount);
    const newUnallocatedAmount = newAmount - allocatedAmount;
    const newAllocatedAmount = allocatedAmount; // Allocated amount stays the same when just updating payment details
    
    console.log('Payment amount update:', {
      currentAmount,
      currentUnallocated,
      allocatedAmount,
      newAmount,
      newUnallocatedAmount,
      newAllocatedAmount
    });
    
    // Update payment in database with updated unallocated amount
    const updatePaymentQuery = `
      UPDATE payments SET
        irm_no = $1,
        reference_number = $2,
        payment_date = $3,
        sap_payment_no = $4,
        payment_type = $5,
        amount = $6,
        currency = $7,
        payment_method = $8,
        notes = $9,
        is_advance_payment = $10,
        customer_id = $11,
        allocated_amount = $12,
        unallocated_amount = $13,
        updated_at = NOW()
      WHERE id = $14
      RETURNING *
    `;
    
    const paymentValues = [
      irmNo,
      payment.referenceNumber,
      paymentDate.toISOString().split('T')[0], // Format as YYYY-MM-DD for SQL
      sapPaymentNo, // Use our normalized variable instead of direct property access
      paymentType, // Use our normalized variable instead of direct property access
      payment.amount,
      payment.currency || 'USD',
      payment.paymentMethod || 'bank transfer', // Ensure a default if null
      payment.notes || null,
      payment.isAdvancePayment,
      payment.isAdvancePayment ? payment.customerId : null,
      newAllocatedAmount,
      newUnallocatedAmount,
      paymentId
    ];
    
    // Execute the payment update with proper error handling
    console.log('Executing payment update for ID:', paymentId);
    console.log('Update values:', {
      irmNo,
      referenceNumber: payment.referenceNumber,
      paymentDate: paymentDate.toISOString().split('T')[0],
      sapPaymentNo,
      paymentType,
      amount: payment.amount,
      currency: payment.currency,
      paymentMethod: payment.paymentMethod,
      notes: payment.notes,
      isAdvancePayment: payment.isAdvancePayment,
      customerId: payment.customerId,
      allocatedAmount: newAllocatedAmount,
      unallocatedAmount: newUnallocatedAmount
    });
    
    const paymentResult = await pool.query(updatePaymentQuery, paymentValues);
    console.log('Payment update result:', paymentResult?.rows?.[0]);
    
    if (!paymentResult || !paymentResult.rows || paymentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Payment not found or update failed' });
    }
    
    const updatedPayment = paymentResult.rows[0];
    
    // Format the response data with ALL payment fields
    const formattedPayment = {
      id: updatedPayment.id,
      referenceNumber: updatedPayment.reference_number,
      customerId: updatedPayment.customer_id,
      paymentDate: updatedPayment.payment_date,
      amount: updatedPayment.amount.toString(),
      paymentMethod: updatedPayment.payment_method,
      currency: updatedPayment.currency,
      notes: updatedPayment.notes,
      isAdvancePayment: updatedPayment.is_advance_payment,
      sapPaymentNo: updatedPayment.sap_payment_no,
      paymentType: updatedPayment.payment_type,
      allocatedAmount: updatedPayment.allocated_amount ? updatedPayment.allocated_amount.toString() : "0.00",
      unallocatedAmount: updatedPayment.unallocated_amount ? updatedPayment.unallocated_amount.toString() : updatedPayment.amount.toString(),
      allocationStatus: updatedPayment.allocated_amount && parseFloat(updatedPayment.allocated_amount) > 0 ? "Partially Allocated" : "Unallocated",
      createdAt: updatedPayment.created_at,
      updatedAt: updatedPayment.updated_at
    };
    
    // Return success response with explicit headers
    res.setHeader('Content-Type', 'application/json');
    try {
      const responseData = {
        message: 'Payment updated successfully',
        payment: formattedPayment
      };
      // Stringify first to validate it's proper JSON
      const jsonString = JSON.stringify(responseData);
      res.send(jsonString);
    } catch (jsonError) {
      console.error('Error converting response to JSON:', jsonError);
      res.status(500).send(JSON.stringify({ 
        error: 'Internal server error during response formatting' 
      }));
    }
  } catch (error) {
    console.error(`Error updating payment ${req.params.id}:`, error);
    // Ensure we're sending a valid JSON response with proper headers
    res.setHeader('Content-Type', 'application/json');
    res.status(500).json({ 
      error: 'Failed to update payment',
      details: error instanceof Error ? error.message : String(error)
    });
  }
});

/**
 * Update an existing invoice
 */
router.put('/invoices/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const invoiceId = parseInt(req.params.id, 10);
    
    if (isNaN(invoiceId)) {
      return res.status(400).json({ error: 'Invalid invoice ID' });
    }
    
    // Get invoice data from request body
    const { invoice, items } = req.body;
    
    if (!invoice || !items) {
      return res.status(400).json({ error: 'Invalid request body - invoice or items data missing' });
    }
    
    console.log(`Updating invoice with ID ${invoiceId}:`, JSON.stringify(req.body, null, 2));
    
    // Validate incoming data
    if (!invoice.invoiceNumber) {
      return res.status(400).json({ error: 'Invoice number is required' });
    }
    
    if (!invoice.customerId) {
      return res.status(400).json({ error: 'Customer ID is required' });
    }
    
    // Format dates for the database
    let issueDate: Date, dueDate: Date;
    try {
      // Always convert string dates to proper JavaScript Date objects
      issueDate = new Date(invoice.issueDate);
      dueDate = new Date(invoice.dueDate);
      
      // Ensure dates are valid
      if (isNaN(issueDate.getTime())) {
        console.error('Invalid issue date:', invoice.issueDate);
        return res.status(400).json({ error: 'Invalid issue date format' });
      }
      
      if (isNaN(dueDate.getTime())) {
        console.error('Invalid due date:', invoice.dueDate);
        return res.status(400).json({ error: 'Invalid due date format' });
      }
    } catch (dateError) {
      console.error('Error processing dates:', dateError);
      return res.status(400).json({ error: 'Invalid date format' });
    }
    
    // Format project ID (can be null)
    let projectId = null;
    
    if (invoice.projectId && invoice.projectId !== '' && invoice.projectId !== 'none') {
      // Only try to parse if it's not empty, null, or "none"
      try {
        projectId = parseInt(invoice.projectId);
        if (isNaN(projectId)) {
          projectId = null;
        }
      } catch (e) {
        console.error('Error parsing projectId:', e);
        projectId = null;
      }
    }
    
    console.log('Processed projectId:', projectId);
    
    // Check if invoice exists before updating
    const checkQuery = 'SELECT * FROM invoices WHERE id = $1';
    const checkResult = await pool.query(checkQuery, [invoiceId]);
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    // Update the invoice in the database with a direct, simpler query
    const updateInvoiceQuery = `
      UPDATE invoices
      SET 
        invoice_number = $1,
        customer_id = $2,
        project_id = $3,
        issue_date = $4,
        due_date = $5,
        total_amount = $6,
        currency = $7,
        sap_invoice_no = $8,
        invoice_type = $9,
        notes = $10,
        updated_at = NOW()
      WHERE id = $11
      RETURNING *
    `;
    
    // Prepare values with proper null handling
    // Print all fields to debug
    // Force projectId to null if it's not a valid integer
    if (projectId && typeof projectId === 'number' && isNaN(projectId)) {
      projectId = null;
    }
    
    console.log('Processing update with fields:', {
      invoiceNumber: invoice.invoiceNumber,
      customerId: invoice.customerId,
      projectId: projectId,
      issueDate: issueDate,
      dueDate: dueDate,
      totalAmount: invoice.totalAmount,
      currency: invoice.currency,
      sapInvoiceNo: invoice.sapInvoiceNo,
      invoiceType: invoice.invoiceType,
      notes: invoice.notes
    });
    
    const invoiceValues = [
      invoice.invoiceNumber,
      parseInt(invoice.customerId),
      null, // Always use null for project_id to be safe
      issueDate,
      dueDate,
      invoice.totalAmount || '0',
      invoice.currency || 'USD',
      invoice.sapInvoiceNo, // Don't convert empty string to null
      invoice.invoiceType,
      invoice.notes, // Don't convert empty string to null
      invoiceId
    ];
    
    console.log('Executing SQL with values:', invoiceValues);
    
    let updatedInvoice;
    
    // Start a transaction to ensure data consistency
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      
      // STEP 1: Update the invoice
      console.log('Executing invoice update query with values:', JSON.stringify(invoiceValues, null, 2));
      
      // Execute the update query within the transaction
      const invoiceResult = await client.query(updateInvoiceQuery, invoiceValues);
      
      if (!invoiceResult.rows || invoiceResult.rows.length === 0) {
        await client.query('ROLLBACK');
        console.error('Invoice update failed: No rows returned');
        return res.status(404).json({ error: 'Invoice not found or update failed' });
      }
      
      updatedInvoice = invoiceResult.rows[0];
      console.log('Invoice updated successfully:', updatedInvoice);
      
      // STEP 2: Delete existing invoice items
      await client.query('DELETE FROM invoice_items WHERE invoice_id = $1', [invoiceId]);
      
      // STEP 3: Insert new invoice items - using only columns that exist in the table
      for (const item of items) {
        const insertItemQuery = `
          INSERT INTO invoice_items (
            invoice_id, description, quantity, unit_price, amount
          )
          VALUES ($1, $2, $3, $4, $5)
        `;
        
        const itemValues = [
          invoiceId,
          item.description,
          item.quantity || '1',
          item.unitPrice || item.amount,
          item.amount
        ];
        
        await client.query(insertItemQuery, itemValues);
      }
      
      // Commit the transaction
      await client.query('COMMIT');
      console.log('Transaction committed successfully');
      
      // Format response data
      const formattedInvoice = {
        id: updatedInvoice.id,
        invoiceNumber: updatedInvoice.invoice_number,
        customerId: updatedInvoice.customer_id,
        projectId: updatedInvoice.project_id,
        issueDate: updatedInvoice.issue_date,
        dueDate: updatedInvoice.due_date,
        totalAmount: updatedInvoice.total_amount.toString(),
        currency: updatedInvoice.currency,
        sapInvoiceNo: updatedInvoice.sap_invoice_no,
        invoiceType: updatedInvoice.invoice_type,
        status: updatedInvoice.status,
        notes: updatedInvoice.notes,
        createdAt: updatedInvoice.created_at,
        updatedAt: updatedInvoice.updated_at
      };
      
      // Send the successful response
      return res.status(200).json({
        message: 'Invoice updated successfully',
        invoice: formattedInvoice
      });
      
    } catch (error) {
      // Roll back the transaction on error
      await client.query('ROLLBACK');
      console.error('Transaction error during invoice update:', error);
      return res.status(500).json({
        error: 'Database error during invoice update',
        details: error instanceof Error ? error.message : String(error)
      });
    } finally {
      // Always release the client back to the pool
      client.release();
    }
    
    // Just in case this part of the code is still reached, we'll handle it
    return;
  } catch (error) {
    console.error(`Error updating invoice ${req.params.id}:`, error);
    // Ensure we're sending valid JSON with proper content type
    res.setHeader('Content-Type', 'application/json');
    res.status(500).send(JSON.stringify({ 
      error: 'Failed to update invoice',
      details: error instanceof Error ? error.message : String(error)
    }));
  }
});

/**
 * Update invoice status - just return success without updating
 */
router.patch('/invoices/:id/status', ensureAuthenticated, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    const updatedInvoice = {
      id: parseInt(id),
      invoiceNumber: `INV-2526-00${id}`,
      customerId: 1,
      issueDate: "2025-05-01",
      dueDate: "2025-05-31",
      totalAmount: "125000.00",
      tax: "10000.00",
      currency: "USD",
      status: status,
      notes: "Project A Phase 1",
      createdBy: 1,
      createdAt: "2025-05-01T10:00:00Z",
      updatedAt: new Date().toISOString()
    };
    
    res.json(updatedInvoice);
  } catch (error) {
    console.error(`Error updating invoice ${req.params.id} status:`, error);
    res.status(500).json({ error: 'Failed to update invoice status' });
  }
});

/**
 * Add a BRC (Bank Realization Certificate) for a payment
 */
router.post('/payments/:id/brc', ensureAuthenticated, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { certificateNumber, issueDate, bankName, documentUrl } = req.body;
    
    const newBRC = {
      id: 1,
      relatedPaymentId: parseInt(id),
      certificateNumber,
      issueDate,
      bankName,
      documentUrl,
      createdBy: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    res.status(201).json(newBRC);
  } catch (error) {
    console.error(`Error adding BRC for payment ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to add BRC' });
  }
});

/**
 * Get all BRCs with pending calculations
 */
router.get('/brc', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Get all BRCs with related invoice data and pending amounts
    const brcQuery = `
      SELECT 
        brc.id,
        brc.certificate_number,
        brc.issue_date,
        brc.bank_name,
        brc.amount as brc_amount,
        brc.currency as brc_currency,
        brc.document_path,
        brc.notes,
        brc.created_by,
        brc.created_at,
        brc.updated_at,
        i.id as invoice_id,
        i.invoice_number,
        i.total_amount as invoice_amount,
        i.currency as invoice_currency,
        i.is_export,
        i.brc_required,
        i.brc_received,
        c.name as customer_name,
        (i.total_amount - COALESCE(brc.amount, 0)) as pending_amount
      FROM bank_realization_certificates brc
      LEFT JOIN invoices i ON brc.related_invoice_id = i.id
      LEFT JOIN customers c ON i.customer_id = c.id
      ORDER BY brc.created_at DESC
    `;

    const result = await pool.query(brcQuery);
    
    // Transform the data to match the expected frontend format
    const brcData = result.rows.map(row => ({
      id: row.id,
      certificateNumber: row.certificate_number,
      issueDate: row.issue_date,
      bankName: row.bank_name,
      amount: row.brc_amount,
      currency: row.brc_currency,
      documentPath: row.document_path,
      notes: row.notes,
      createdBy: row.created_by,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      invoice: {
        id: row.invoice_id,
        invoiceNumber: row.invoice_number,
        amount: row.invoice_amount,
        currency: row.invoice_currency,
        isExport: row.is_export,
        brcRequired: row.brc_required,
        brcReceived: row.brc_received,
        customerName: row.customer_name
      },
      pendingAmount: row.pending_amount
    }));

    console.log(`Found ${brcData.length} BRC records`);
    res.json(brcData);
  } catch (error) {
    console.error('Error getting BRCs:', error);
    res.status(500).json({ error: 'Failed to get BRCs' });
  }
});

/**
 * Get BRC pending invoices (invoices with partial BRC or no BRC)
 */
router.get('/brc/pending', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const pendingQuery = `
      SELECT 
        i.id,
        i.invoice_number,
        i.total_amount as invoice_amount,
        i.currency,
        i.issue_date,
        i.due_date,
        c.name as customer_name,
        COALESCE(SUM(brc.amount), 0) as brc_received_amount,
        (i.total_amount - COALESCE(SUM(brc.amount), 0)) as brc_pending_amount
      FROM invoices i
      LEFT JOIN customers c ON i.customer_id = c.id
      LEFT JOIN bank_realization_certificates brc ON i.id = brc.related_invoice_id
      WHERE i.brc_required = true
        AND (i.total_amount - COALESCE(SUM(brc.amount), 0)) > 0
      GROUP BY i.id, i.invoice_number, i.total_amount, i.currency, i.issue_date, i.due_date, c.name
      HAVING (i.total_amount - COALESCE(SUM(brc.amount), 0)) > 0
      ORDER BY i.issue_date DESC
    `;

    const result = await pool.query(pendingQuery);
    
    console.log(`Found ${result.rows.length} invoices with pending BRC amounts`);
    console.log('Sample pending invoice data:', result.rows[0]);
    
    const pendingInvoices = result.rows.map(row => ({
      id: row.id,
      invoiceNumber: row.invoice_number,
      invoiceAmount: row.invoice_amount,
      currency: row.currency,
      issueDate: row.issue_date,
      dueDate: row.due_date,
      customerName: row.customer_name,
      brcReceivedAmount: row.brc_received_amount,
      brcPendingAmount: row.brc_pending_amount
    }));

    console.log(`Found ${pendingInvoices.length} invoices with pending BRC amounts`);
    res.json(pendingInvoices);
  } catch (error) {
    console.error('Error getting BRC pending invoices:', error);
    res.status(500).json({ error: 'Failed to get BRC pending invoices' });
  }
});

/**
 * Generate payment reference number based on date
 */
router.get('/generate-payment-reference', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Get date parameters from query
    let year, month, day;
    
    if (req.query.year && req.query.month && req.query.day) {
      // If individual date components are provided, use them
      year = parseInt(req.query.year as string);
      month = parseInt(req.query.month as string);
      day = parseInt(req.query.day as string);
      
      // Month is 0-based in JavaScript Date (0 = January, 11 = December)
      month = month - 1;
    } else {
      // Use current date
      const today = new Date();
      year = today.getFullYear();
      month = today.getMonth();
      day = today.getDate();
    }
    
    // Create date object
    const date = new Date(year, month, day);
    console.log(`Using payment date for reference: ${date.toDateString()} (y:${year} m:${month} d:${day})`);
    
    // Calculate financial year based on Indian calendar (April to March)
    // If month is January(0), February(1), or March(2), use previous year as start year
    const startYear = month < 3 ? year - 1 : year;
    const endYear = startYear + 1;
    
    // Format as YYZZ (e.g., "2425" for 2024-2025)
    const startYearStr = startYear.toString().slice(-2);
    const endYearStr = endYear.toString().slice(-2);
    const financialYear = `${startYearStr}${endYearStr}`;
    
    console.log(`Calculated financial year ${financialYear} for date ${date.toDateString()}`);
    
    try {
      // Query database for highest existing payment reference number with this prefix
      const query = `
        SELECT reference_number 
        FROM payments 
        WHERE reference_number LIKE $1 
        ORDER BY reference_number DESC
        LIMIT 1
      `;
      
      console.log(`Looking for payment references with pattern: PAY-${financialYear}-%`);
      const result = await pool.query(query, [`PAY-${financialYear}-%`]);
      
      let nextSequenceNumber = 1; // Start from 1 if no existing payments
      
      if (result.rows.length > 0) {
        const latestRef = result.rows[0].reference_number;
        console.log(`Found latest payment reference: ${latestRef}`);
        
        // Extract sequence number from reference number (PAY-YYZZ-XXX)
        const match = latestRef.match(/PAY-\d{4}-(\d{3})/);
        if (match && match[1]) {
          const currentSequence = parseInt(match[1], 10);
          nextSequenceNumber = currentSequence + 1;
          console.log(`Current sequence: ${currentSequence}, next: ${nextSequenceNumber}`);
        }
      } else {
        console.log(`No existing payments found for financial year ${financialYear}, starting with 001`);
      }
      
      // Format with leading zeros (3 digits)
      const sequenceStr = nextSequenceNumber.toString().padStart(3, '0');
      const referenceNumber = `PAY-${financialYear}-${sequenceStr}`;
      
      console.log(`Generated payment reference number: ${referenceNumber}`);
      return res.json({ referenceNumber });
      
    } catch (dbError) {
      console.error('Database error generating payment reference number:', dbError);
      
      // Fallback to basic reference number if database fails
      const sequenceStr = '001';
      const referenceNumber = `PAY-${financialYear}-${sequenceStr}`;
      
      console.log(`Using fallback payment reference number: ${referenceNumber}`);
      return res.json({ referenceNumber });
    }
  } catch (error) {
    console.error('Error generating payment reference number:', error);
    res.status(500).json({ 
      error: 'Failed to generate reference number. Please try again or enter manually.'
    });
  }
});

/**
 * Get foreign currency payments without BRC
 */
router.get('/payments/foreign-without-brc', ensureAuthenticated, (req: Request, res: Response) => {
  try {
    const { startDate, endDate } = req.query;
    
    if (!startDate || !endDate) {
      return res.status(400).json({ error: 'Start date and end date are required' });
    }
    
    const paymentsWithoutBrc = [
      {
        id: 3,
        referenceNumber: "PAY-2526-003",
        customerId: 3,
        paymentDate: "2025-08-10",
        amount: "150000.00",
        paymentMethod: "Wire Transfer",
        currency: "USD",
        notes: "Payment for INV-2526-003",
        isAdvancePayment: false,
        allocationStatus: "Allocated",
        createdBy: 1,
        createdAt: "2025-08-10T14:30:00Z",
        updatedAt: "2025-08-10T14:30:00Z"
      }
    ];
    
    res.json(paymentsWithoutBrc);
  } catch (error) {
    console.error('Error getting foreign payments without BRC:', error);
    res.status(500).json({ error: 'Failed to get foreign payments without BRC' });
  }
});

/**
 * Allocate payment to invoices with real database updates
 */
router.post('/payments/:id/allocate', ensureAuthenticated, async (req: Request, res: Response) => {
  const client = await pool.connect();
  
  try {
    const paymentId = parseInt(req.params.id);
    if (isNaN(paymentId)) {
      return res.status(400).json({ error: 'Invalid payment ID' });
    }
    
    const { invoiceAllocations, comment } = req.body;
    
    if (!invoiceAllocations || !Array.isArray(invoiceAllocations) || invoiceAllocations.length === 0) {
      return res.status(400).json({ error: 'Invoice allocations are required' });
    }
    
    // Validate the invoice allocations data
    for (const allocation of invoiceAllocations) {
      if (!allocation.invoiceId || isNaN(parseInt(allocation.invoiceId.toString()))) {
        return res.status(400).json({ error: 'Invalid invoice ID in allocations' });
      }
      
      if (!allocation.amountApplied || isNaN(parseFloat(allocation.amountApplied.toString()))) {
        return res.status(400).json({ error: 'Invalid allocation amount' });
      }
      
      if (parseFloat(allocation.amountApplied.toString()) <= 0) {
        return res.status(400).json({ error: 'Allocation amount must be greater than zero' });
      }
    }
    
    // Start transaction
    await client.query('BEGIN');
    
    // Step 1: Get payment details and verify it exists and has sufficient unallocated amount
    const paymentQuery = `
      SELECT id, irm_no, payment_type, amount, allocated_amount, unallocated_amount
      FROM payments
      WHERE id = $1
    `;
    
    const paymentResult = await client.query(paymentQuery, [paymentId]);
    
    if (paymentResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    const payment = paymentResult.rows[0];
    const totalAllocationAmount = invoiceAllocations.reduce(
      (sum: number, alloc: any) => sum + parseFloat(alloc.amountApplied.toString()), 
      0
    );
    
    // COMPREHENSIVE OVER-ALLOCATION VALIDATION
    const paymentTotal = parseFloat(payment.amount);
    const currentAllocated = parseFloat(payment.allocated_amount || 0);
    const currentUnallocated = parseFloat(payment.unallocated_amount || paymentTotal);
    
    // Check 1: Basic unallocated amount check
    if (totalAllocationAmount > currentUnallocated) {
      await client.query('ROLLBACK');
      return res.status(400).json({ 
        error: 'Total allocation amount exceeds the payment\'s available amount',
        requested: totalAllocationAmount,
        available: currentUnallocated,
        paymentId: paymentId
      });
    }
    
    // Check 2: Verify total allocations won't exceed payment amount
    const newTotalAllocated = currentAllocated + totalAllocationAmount;
    if (newTotalAllocated > paymentTotal) {
      await client.query('ROLLBACK');
      return res.status(400).json({ 
        error: 'New allocation would cause over-allocation',
        paymentTotal: paymentTotal,
        currentAllocated: currentAllocated,
        requestedAllocation: totalAllocationAmount,
        wouldResultIn: newTotalAllocated,
        excess: newTotalAllocated - paymentTotal,
        paymentId: paymentId
      });
    }
    
    // Check 3: Verify existing allocations match database constraints
    const existingAllocationsQuery = `
      SELECT COALESCE(SUM(amount_applied), 0) as total_existing
      FROM payment_allocations 
      WHERE payment_id = $1
    `;
    
    const existingResult = await client.query(existingAllocationsQuery, [paymentId]);
    const existingTotal = parseFloat(existingResult.rows[0].total_existing || 0);
    
    if (existingTotal !== currentAllocated) {
      console.warn(`Payment ${paymentId} allocation mismatch detected:`, {
        databaseAllocated: currentAllocated,
        linksTotal: existingTotal,
        difference: Math.abs(currentAllocated - existingTotal)
      });
    }
    
    // Check 4: Final validation - prevent over-allocation like Payment ID 5
    const finalTotal = existingTotal + totalAllocationAmount;
    if (finalTotal > paymentTotal) {
      await client.query('ROLLBACK');
      return res.status(400).json({ 
        error: 'Allocation rejected: Would exceed payment amount (preventing over-allocation)',
        paymentAmount: paymentTotal,
        existingAllocations: existingTotal,
        newAllocation: totalAllocationAmount,
        wouldTotal: finalTotal,
        overage: finalTotal - paymentTotal,
        paymentId: paymentId,
        validationNote: 'This validation prevents issues like Payment ID 5 over-allocation'
      });
    }
    
    // Step 2: Get invoice details and verify each invoice exists and has sufficient outstanding amount
    const invoiceIds = invoiceAllocations.map(a => parseInt(a.invoiceId.toString()));
    const invoicesQuery = `
      SELECT id, invoice_number, invoice_type, outstanding_amount
      FROM invoices
      WHERE id = ANY($1)
    `;
    
    const invoicesResult = await client.query(invoicesQuery, [invoiceIds]);
    
    // Create a map for easier lookup
    const invoicesMap = new Map();
    for (const invoice of invoicesResult.rows) {
      invoicesMap.set(invoice.id, invoice);
    }
    
    // Validate each allocation against the corresponding invoice
    for (const allocation of invoiceAllocations) {
      const invoiceId = parseInt(allocation.invoiceId.toString());
      const invoice = invoicesMap.get(invoiceId);
      
      if (!invoice) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: `Invoice with ID ${invoiceId} not found` });
      }
      
      // Validate payment type matches invoice type
      if (payment.payment_type !== invoice.invoice_type) {
        await client.query('ROLLBACK');
        return res.status(400).json({ 
          error: `Payment type (${payment.payment_type}) does not match invoice type (${invoice.invoice_type})` 
        });
      }
      
      // Check that allocation amount doesn't exceed outstanding amount
      const allocationAmount = parseFloat(allocation.amountApplied.toString());
      if (allocationAmount > parseFloat(invoice.outstanding_amount)) {
        await client.query('ROLLBACK');
        return res.status(400).json({ 
          error: `Allocation amount (${allocationAmount}) exceeds invoice outstanding amount (${invoice.outstanding_amount})`,
          invoiceId: invoiceId,
          invoiceNumber: invoice.invoice_number
        });
      }
    }
    
    // Step 3: Insert payment allocations
    const allocations = [];
    const now = new Date();
    const username = req.user?.username || 'System';
    
    for (const allocation of invoiceAllocations) {
      const invoiceId = parseInt(allocation.invoiceId.toString());
      const amountApplied = parseFloat(allocation.amountApplied.toString());
      const invoice = invoicesMap.get(invoiceId);
      
      const insertQuery = `
        INSERT INTO payment_allocations (
          payment_id, invoice_id, amount_applied, notes, created_by, created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING id, payment_id, invoice_id, amount_applied, created_at
      `;
      
      const insertResult = await client.query(insertQuery, [
        paymentId, 
        invoiceId, 
        amountApplied,
        comment || null,
        username,
        now
      ]);
      
      allocations.push({
        id: insertResult.rows[0].id,
        paymentId: insertResult.rows[0].payment_id,
        invoiceId: insertResult.rows[0].invoice_id,
        invoiceNumber: invoice.invoice_number,
        amountApplied: insertResult.rows[0].amount_applied,
        allocationDate: insertResult.rows[0].created_at
      });
      
      // Update invoice outstanding amount
      const updateInvoiceQuery = `
        UPDATE invoices
        SET 
          outstanding_amount = outstanding_amount - $1,
          updated_at = $2,
          status = CASE 
            WHEN outstanding_amount - $1 <= 0 THEN 'Paid'
            ELSE 'Partially Paid'
          END
        WHERE id = $3
      `;
      
      await client.query(updateInvoiceQuery, [amountApplied, now, invoiceId]);
    }
    
    // Step 4: Update payment allocated and unallocated amounts
    const updatePaymentQuery = `
      UPDATE payments
      SET 
        allocated_amount = allocated_amount + $1,
        unallocated_amount = unallocated_amount - $1,
        updated_at = $2
      WHERE id = $3
      RETURNING allocated_amount, unallocated_amount
    `;
    
    const updatedPayment = await client.query(updatePaymentQuery, [
      totalAllocationAmount, 
      now, 
      paymentId
    ]);
    
    // Step 5: Commit transaction
    await client.query('COMMIT');
    
    // Prepare success response
    const allocationResponse = {
      success: true,
      payment: {
        id: paymentId,
        allocationStatus: parseFloat(updatedPayment.rows[0].unallocated_amount) > 0 
          ? "Partially Allocated" 
          : "Fully Allocated",
        allocatedAmount: updatedPayment.rows[0].allocated_amount,
        unallocatedAmount: updatedPayment.rows[0].unallocated_amount,
        updatedAt: now.toISOString()
      },
      allocations: allocations,
      totalAllocated: totalAllocationAmount
    };
    
    return res.json(allocationResponse);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(`Error allocating payment ${req.params.id}:`, error);
    return res.status(500).json({ error: 'Failed to allocate payment' });
  } finally {
    client.release();
  }
});

/**
 * Endpoint to get latest invoice number by financial year
 */
router.get('/latest-invoice', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Set proper content type
    res.setHeader('Content-Type', 'application/json');
    
    const financialYear = req.query.financialYear as string;
    
    // Validate financial year format
    if (!financialYear || financialYear.length !== 4) {
      console.log(`Invalid financial year format received: ${financialYear}`);
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid financial year format. Expected YYZZ format (e.g., 2526)' 
      });
    }
    
    // Try multiple methods to find the latest invoice
    
    // Method 1: Direct database query with proper error handling
    try {
      const query = `
        SELECT invoice_number 
        FROM invoices 
        WHERE invoice_number LIKE $1 
        ORDER BY created_at DESC, invoice_number DESC
        LIMIT 1
      `;
      
      console.log(`Querying for latest invoice with pattern: INV-${financialYear}-%`);
      const result = await pool.query(query, [`INV-${financialYear}-%`]);
      
      // If we found an invoice, return it
      if (result.rows.length > 0) {
        console.log(`Latest invoice found for ${financialYear}: ${result.rows[0].invoice_number}`);
        return res.json({ 
          success: true,
          latestInvoiceNumber: result.rows[0].invoice_number 
        });
      }
    } catch (dbError) {
      console.error('Error in direct DB query method:', dbError);
      // Continuing to fallback method...
    }
    
    // Method 2: Try a more flexible query if the first one fails
    try {
      const query = `
        SELECT invoice_number 
        FROM invoices 
        WHERE invoice_number LIKE 'INV-%' 
        ORDER BY created_at DESC, invoice_number DESC
        LIMIT 10
      `;
      
      console.log('Trying flexible query to find any recent invoices');
      const result = await pool.query(query);
      
      if (result.rows.length > 0) {
        // Look for a matching financial year in the results
        for (const row of result.rows) {
          const match = row.invoice_number.match(/INV-(\d{4})-(\d{2,3})/);
          if (match && match[1] === financialYear) {
            console.log(`Found matching invoice from flexible query: ${row.invoice_number}`);
            return res.json({ 
              success: true,
              latestInvoiceNumber: row.invoice_number
            });
          }
        }
        
        // If we have invoices but not for this financial year, use the latest one as reference
        console.log(`Found invoices but none for ${financialYear}, using latest as reference: ${result.rows[0].invoice_number}`);
        return res.json({ 
          success: true,
          latestInvoiceNumber: null,
          referenceInvoiceNumber: result.rows[0].invoice_number
        });
      }
    } catch (fallbackError) {
      console.error('Error in fallback query method:', fallbackError);
    }

    // No invoices found at all - return empty response
    console.log(`No invoices found for any financial year`);
    return res.json({ 
      success: true,
      latestInvoiceNumber: null,
      message: 'No invoices found in the database' 
    });
    
  } catch (error) {
    console.error('Unexpected error in latest invoice endpoint:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Server error occurred while retrieving invoice information'
    });
  }
});

/**
 * Test endpoint to generate next invoice number
 * This endpoint is used by the frontend to generate the next invoice number
 * Format: INV-YYZZ-XXX where YY is the last 2 digits of the start year,
 * ZZ is the last 2 digits of the end year, and XXX is a sequence number
 */
router.get('/test/invoice-number', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Set correct headers for JSON response
    res.setHeader('Content-Type', 'application/json');
    
    const date = req.query.date ? new Date(req.query.date as string) : new Date();
    
    // Get the financial year
    const startYear = date.getMonth() >= 3 ? date.getFullYear() : date.getFullYear() - 1;
    const endYear = startYear + 1;
    
    // Format YY-ZZ part
    const startYearStr = startYear.toString().substring(2);
    const endYearStr = endYear.toString().substring(2);
    const financialYear = `${startYearStr}${endYearStr}`;
    
    // Query the database for existing invoice numbers in this financial year
    try {
      // Changed to use created_at ordering to ensure we get the latest invoice
      const query = `
        SELECT invoice_number 
        FROM invoices 
        WHERE invoice_number LIKE $1 
        ORDER BY created_at DESC, invoice_number DESC
        LIMIT 1
      `;
      
      console.log(`Querying for latest invoice with pattern: INV-${financialYear}-%`);
      const result = await pool.query(query, [`INV-${financialYear}-%`]);
      
      // Start from number 1 if there are no existing invoices
      let maxSequenceNumber = 0;
      
      // If we found existing invoices, extract the highest sequence number
      if (result.rows.length > 0) {
        console.log('Latest invoice found:', result.rows[0].invoice_number);
        // Updated regex pattern to handle both 3-digit and 2-digit sequence numbers
        const match = result.rows[0].invoice_number.match(/INV-(\d{4})-(\d{2,3})/);
        if (match && match[2]) {
          const dbSequenceNumber = parseInt(match[2], 10);
          maxSequenceNumber = Math.max(maxSequenceNumber, dbSequenceNumber);
          console.log(`Extracted sequence number: ${dbSequenceNumber}, new max: ${maxSequenceNumber}`);
        } else {
          console.log('Could not extract sequence number from invoice:', result.rows[0].invoice_number);
        }
      } else {
        console.log('No existing invoices found for this financial year');
      }
      
      // Generate the next sequence number
      const nextSequenceNumber = maxSequenceNumber + 1;
      // Format it to 3 digits with leading zeros
      const sequenceStr = nextSequenceNumber.toString().padStart(3, '0');
      
      // Return the next invoice number
      const nextInvoiceNumber = `INV-${financialYear}-${sequenceStr}`;
      
      // Log the generated invoice number for debugging
      console.log(`Generated new invoice number: ${nextInvoiceNumber} (based on max: ${maxSequenceNumber})`);
      
      // Add additional database check to ensure uniqueness
      try {
        const checkDuplicateQuery = `SELECT COUNT(*) FROM invoices WHERE invoice_number = $1`;
        const duplicateCheck = await pool.query(checkDuplicateQuery, [nextInvoiceNumber]);
        
        if (duplicateCheck.rows[0].count > 0) {
          console.log(`Warning: Generated invoice number ${nextInvoiceNumber} already exists, incrementing...`);
          // If duplicate found, increment and try again
          const adjustedNumber = nextSequenceNumber + 1;
          const adjustedStr = adjustedNumber.toString().padStart(3, '0');
          const adjustedInvoiceNumber = `INV-${financialYear}-${adjustedStr}`;
          console.log(`Adjusted to new invoice number: ${adjustedInvoiceNumber}`);
          return res.json({ nextInvoiceNumber: adjustedInvoiceNumber });
        }
      } catch (err) {
        console.log("Error checking for duplicate invoice numbers:", err);
        // Continue with original number if check fails
      }
      
      return res.json({ nextInvoiceNumber });
    } catch (dbError) {
      console.error("Database error when getting invoice number:", dbError);
      
      // Fallback: start from 001 if no invoices exist or if database query fails
      const sequenceStr = '001'; // Start fresh from 001
      const nextInvoiceNumber = `INV-${financialYear}-${sequenceStr}`;
      
      console.log(`Using fallback invoice number: ${nextInvoiceNumber} due to DB error`);
      return res.json({ nextInvoiceNumber });
    }
    
  } catch (error) {
    console.error('Error generating next invoice number:', error);
    res.status(500).json({ error: 'Failed to generate next invoice number' });
  }
});

/**
 * Get outstanding invoices for payment allocation
 */
router.get('/outstanding-invoices', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    // Default response structure for empty or error cases
    const emptyResponse = {
      invoices: [],
      totalOutstanding: "0.00",
      count: 0
    };
    
    // Extract optional filters from query params
    let customerId = null;
    if (req.query.customerId && req.query.customerId !== 'all') {
      const parsedId = parseInt(req.query.customerId as string);
      if (!isNaN(parsedId)) {
        customerId = parsedId;
      }
    }
    
    // Check for invoiceType in query params, or fallback to 'type' parameter
    let invoiceType = null;
    if (req.query.invoiceType && req.query.invoiceType !== 'all') {
      invoiceType = req.query.invoiceType as string;
    } else if (req.query.type && req.query.type !== 'all') {
      invoiceType = req.query.type as string;
    }
    
    console.log('Querying for outstanding invoices with filters:', { customerId, invoiceType });
    console.log('Raw query parameters:', req.query);
    
    // Build query to get outstanding invoices
    let query = `
      SELECT 
        i.id,
        i.invoice_number as "invoiceNumber",
        i.customer_id as "customerId",
        c.bp_name as "customerName",
        i.issue_date as "issueDate",
        i.due_date as "dueDate",
        i.total_amount as "totalAmount",
        i.outstanding_amount as "outstandingAmount",
        i.currency,
        i.invoice_type as "invoiceType",
        i.status,
        i.sap_invoice_no as "sapInvoiceNo",
        i.notes,
        i.created_at as "createdAt",
        i.updated_at as "updatedAt"
      FROM 
        invoices i
      JOIN 
        customers c ON i.customer_id = c.id
      WHERE 
        i.outstanding_amount > 0
    `;
    
    // Add filters if provided
    const params = [];
    if (customerId) {
      params.push(customerId);
      query += ` AND i.customer_id = $${params.length}`;
    }
    
    if (invoiceType) {
      params.push(invoiceType);
      query += ` AND i.invoice_type = $${params.length}`;
    }
    
    // Add order by clause
    query += ` ORDER BY i.issue_date ASC`;
    
    try {
      // Execute query
      const result = await pool.query(query, params);
      const invoices = result.rows;
      
      console.log('Outstanding invoices query result with customer names:');
      if (invoices && invoices.length > 0) {
        console.log('First invoice sample:', JSON.stringify(invoices[0], null, 2));
      }
      
      // Calculate total outstanding amount
      const totalOutstanding = invoices.reduce(
        (sum, invoice) => sum + parseFloat(invoice.outstandingAmount), 0
      ).toFixed(2);
      
      return res.json({
        invoices: invoices,
        totalOutstanding: totalOutstanding,
        count: invoices.length
      });
    } catch (dbError) {
      console.error('Database error getting outstanding invoices:', dbError);
      return res.json(emptyResponse);
    }
  } catch (error) {
    console.error('Error getting outstanding invoices:', error);
    // Return an empty response structure instead of error
    return res.json({
      invoices: [],
      totalOutstanding: "0.00",
      count: 0
    });
  }
});

/**
 * Apply available advance payments to an existing invoice
 */

/**
 * Get customers with outstanding invoices - DIRECT VERSION TO BYPASS ROUTING ISSUES
 */
router.get('/customers-with-outstanding', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('=== DIRECT CUSTOMER ENDPOINT HIT ===');
    
    // Simple direct response with hardcoded data first to test
    const customers = [
      { id: 8, name: "AVISTA OIL DEUTSCHLAND GMBH" }
    ];
    
    console.log('Returning customers directly:', customers);
    
    res.setHeader('Content-Type', 'application/json');
    res.json({
      customers: customers
    });
  } catch (error) {
    console.error('Error in direct customer endpoint:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

/**
 * Get unallocated advance payments - FIXED to use payment_allocations table
 */
router.get('/payments/unallocated-advances', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('🔧 Fetching unallocated advance payments using CORRECT payment_allocations table...');
    console.log('🔍 DEBUG: Checking Payment ID 63 specifically...');
    
    // First, let's debug Payment ID 63 specifically
    const debugQuery = `
      SELECT 
        p.id, 
        p.irm_no,
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as calculated_allocated,
        p.amount - COALESCE(SUM(pa.amount_applied), 0) as remaining_amount,
        c.bp_name as customer_name
      FROM 
        payments p
      JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      WHERE 
        p.id = 63
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.amount
    `;
    
    const debugResult = await pool.query(debugQuery);
    if (debugResult.rows.length > 0) {
      const debug63 = debugResult.rows[0];
      console.log('🔍 Payment ID 63 Debug:', {
        id: debug63.id,
        irm_no: debug63.irm_no,
        total_amount: debug63.amount,
        calculated_allocated: debug63.calculated_allocated,
        remaining_amount: debug63.remaining_amount,
        should_be_excluded: debug63.remaining_amount <= 0.01,
        customer_name: debug63.customer_name
      });
    }
    
    const query = `
      SELECT 
        p.id, 
        p.irm_no as "paymentReference",
        p.customer_id as "customerId",
        c.bp_name as "customerName",
        p.payment_date as "paymentDate",
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as "calculatedAllocatedAmount",
        p.payment_method as "paymentMethod",
        p.payment_type as "paymentType",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment"
      FROM 
        payments p
      JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      WHERE 
        p.is_advance_payment = true
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.customer_id, p.payment_date, p.amount, 
        p.payment_method, p.payment_type, p.currency, p.notes, p.is_advance_payment
      HAVING 
        p.amount - COALESCE(SUM(pa.amount_applied), 0) > 0.01
      ORDER BY 
        p.payment_date DESC
    `;
    
    const result = await pool.query(query);
    const advances = result.rows;
    
    console.log(`Found ${advances.length} unallocated advance payments`);
    console.log('🔍 Payment IDs in result:', advances.map(p => p.id));
    
    // Format the response with calculated values
    const formattedAdvances = advances.map(payment => {
      const totalAmount = parseFloat(payment.amount);
      const calculatedAllocated = parseFloat(payment.calculatedAllocatedAmount || '0');
      const remainingAmount = totalAmount - calculatedAllocated;
      
      return {
        id: payment.id,
        paymentReference: payment.paymentReference,
        customerId: payment.customerId,
        customerName: payment.customerName,
        paymentDate: payment.paymentDate,
        amount: totalAmount.toString(),
        allocatedAmount: calculatedAllocated.toString(),
        unallocatedAmount: remainingAmount.toString(),
        paymentMethod: payment.paymentMethod,
        paymentType: payment.paymentType,
        currency: payment.currency,
        notes: payment.notes,
        isAdvancePayment: payment.isAdvancePayment
      };
    });
    
    console.log(`After formatting: ${formattedAdvances.length} unallocated advance payments`);
    
    // Calculate total unallocated amount
    const totalUnallocated = formattedAdvances.reduce((sum, payment) => {
      const amount = parseFloat(payment.unallocatedAmount) || 0;
      return sum + amount;
    }, 0);
    
    res.json({
      advances: formattedAdvances,
      totalUnallocatedAmount: totalUnallocated.toFixed(2),
      count: formattedAdvances.length
    });
    
  } catch (error) {
    console.error('Error getting unallocated advances:', error);
    res.status(500).json({
      error: 'Failed to fetch unallocated advances',
      advances: [],
      totalUnallocatedAmount: "0.00",
      count: 0
    });
  }
});

/**
 * Get unallocated advance payments - FIXED to use payment_allocations table
 */
router.get('/unallocated-advances', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('🔧 Fetching unallocated advance payments using CORRECT payment_allocations table...');
    console.log('🔍 DEBUG: Checking Payment ID 63 specifically...');
    
    // First, let's debug Payment ID 63 specifically
    const debugQuery = `
      SELECT 
        p.id, 
        p.irm_no,
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as calculated_allocated,
        p.amount - COALESCE(SUM(pa.amount_applied), 0) as remaining_amount,
        c.bp_name as customer_name
      FROM 
        payments p
      JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      WHERE 
        p.id = 63
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.amount
    `;
    
    const debugResult = await pool.query(debugQuery);
    if (debugResult.rows.length > 0) {
      const debug63 = debugResult.rows[0];
      console.log('🔍 Payment ID 63 Debug:', {
        id: debug63.id,
        irm_no: debug63.irm_no,
        total_amount: debug63.amount,
        calculated_allocated: debug63.calculated_allocated,
        remaining_amount: debug63.remaining_amount,
        should_be_excluded: debug63.remaining_amount <= 0.01,
        customer_name: debug63.customer_name
      });
    }
    
    const query = `
      SELECT 
        p.id, 
        p.irm_no as "paymentReference",
        p.customer_id as "customerId",
        c.bp_name as "customerName",
        p.payment_date as "paymentDate",
        p.amount,
        COALESCE(SUM(pa.amount_applied), 0) as "calculatedAllocatedAmount",
        p.payment_method as "paymentMethod",
        p.payment_type as "paymentType",
        p.currency,
        p.notes,
        p.is_advance_payment as "isAdvancePayment"
      FROM 
        payments p
      JOIN 
        customers c ON p.customer_id = c.id
      LEFT JOIN 
        payment_allocations pa ON p.id = pa.payment_id
      WHERE 
        p.is_advance_payment = true
      GROUP BY 
        p.id, c.bp_name, p.irm_no, p.customer_id, p.payment_date, p.amount, 
        p.payment_method, p.payment_type, p.currency, p.notes, p.is_advance_payment
      HAVING 
        p.amount - COALESCE(SUM(pa.amount_applied), 0) > 0.01
      ORDER BY 
        p.payment_date DESC
    `;
    
    const result = await pool.query(query);
    const advances = result.rows;
    
    console.log(`Found ${advances.length} unallocated advance payments`);
    console.log('🔍 Payment IDs in result:', advances.map(p => p.id));
    
    // Format the response with calculated values
    const formattedAdvances = advances.map(payment => {
      const totalAmount = parseFloat(payment.amount);
      const calculatedAllocated = parseFloat(payment.calculatedAllocatedAmount || '0');
      const remainingAmount = totalAmount - calculatedAllocated;
      
      return {
        id: payment.id,
        paymentReference: payment.paymentReference,
        customerId: payment.customerId,
        customerName: payment.customerName,
        paymentDate: payment.paymentDate,
        amount: totalAmount.toString(),
        allocatedAmount: calculatedAllocated.toString(),
        unallocatedAmount: remainingAmount.toString(),
        paymentMethod: payment.paymentMethod,
        paymentType: payment.paymentType,
        currency: payment.currency,
        notes: payment.notes,
        isAdvancePayment: payment.isAdvancePayment
      };
    });
    
    console.log(`After formatting: ${formattedAdvances.length} unallocated advance payments`);
    
    // Calculate total unallocated amount
    const totalUnallocated = formattedAdvances.reduce((sum, payment) => {
      const amount = parseFloat(payment.unallocatedAmount) || 0;
      return sum + amount;
    }, 0);
    
    res.json({
      advances: formattedAdvances,
      totalUnallocatedAmount: totalUnallocated.toFixed(2),
      count: formattedAdvances.length
    });
    
  } catch (error) {
    console.error('Error getting unallocated advances:', error);
    res.status(500).json({
      error: 'Failed to fetch unallocated advances',
      advances: [],
      totalUnallocatedAmount: "0.00",
      count: 0
    });
  }
});

/**
 * Apply available advance payments to an existing invoice
 */
router.post('/invoices/:id/apply-advances', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const invoiceId = parseInt(req.params.id);
    const userId = req.user?.id;
    if (!userId) return res.status(401).json({ error: 'Authentication required' });
    
    if (isNaN(invoiceId)) {
      return res.status(400).json({ error: 'Invalid invoice ID' });
    }
    
    // Get invoice details to verify it exists and get customer ID
    const invoiceQuery = `SELECT id, customer_id, invoice_type, outstanding_amount FROM invoices WHERE id = $1`;
    const invoiceResult = await pool.query(invoiceQuery, [invoiceId]);
    
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    const invoice = invoiceResult.rows[0];
    const customerId = invoice.customer_id;
    const invoiceType = invoice.invoice_type;
    const outstandingAmount = parseFloat(invoice.outstanding_amount || 0);
    
    // Check if invoice is already fully paid
    if (outstandingAmount <= 0) {
      return res.status(400).json({ message: 'Invoice is already fully paid' });
    }
    
    // Query for available advance payments for this customer and matching type
    const advancePaymentsQuery = `
      SELECT 
        id, 
        unallocated_amount, 
        reference_number as "referenceNumber",
        payment_date as "paymentDate",
        payment_method as "paymentMethod",
        payment_type as "paymentType"
      FROM payments 
      WHERE customer_id = $1 
        AND is_advance_payment = true 
        AND unallocated_amount > 0
        AND payment_type = $2
      ORDER BY payment_date ASC
    `;
    
    const advancePaymentsResult = await pool.query(
      advancePaymentsQuery, 
      [customerId, invoiceType]
    );
    
    if (advancePaymentsResult.rows.length === 0) {
      return res.status(404).json({ 
        message: `No unallocated advance payments found for customer ID ${customerId} and type ${invoiceType}` 
      });
    }
    
    console.log(`Found ${advancePaymentsResult.rows.length} advance payments available for auto-allocation`);
    
    // Create allocation data for each advance payment
    const advanceAllocations = advancePaymentsResult.rows.map(payment => ({
      paymentId: payment.id,
      amountToApply: parseFloat(payment.unallocated_amount)
    }));
    
    // Apply advance payments using our service
    const result = await paymentAllocationService.applyAdvancePaymentsToInvoice(
      invoiceId,
      customerId,
      advanceAllocations,
      userId
    );
    
    console.log('Applied advance payments to existing invoice:', result);
    
    res.json({
      success: true,
      invoiceId,
      message: `Successfully applied ${result.allocations.length} advance payments totaling ${result.totalApplied} to invoice`,
      totalApplied: result.totalApplied,
      allocations: result.allocations
    });
    
  } catch (error) {
    console.error('Error applying advance payments to invoice:', error);
    res.status(500).json({ 
      error: 'Failed to apply advance payments to invoice', 
      message: error.message
    });
  }
});

/**
 * Batch apply advance payments to multiple invoices for a customer
 */
router.post('/customers/:id/apply-advances', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const customerId = parseInt(req.params.id);
    const userId = req.user?.id;
    if (!userId) return res.status(401).json({ error: 'Authentication required' });
    
    if (isNaN(customerId)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }
    
    console.log(`Starting batch advance allocation for customer ${customerId}`);
    
    try {
      // Call our specialized batch allocation service
      const result = await batchAllocationService.applyAdvancePaymentsForCustomer(
        customerId,
        userId
      );
      
      console.log(`Batch allocation completed successfully for customer ${customerId}`);
      return res.json(result);
      
    } catch (serviceError) {
      console.error('Error in batch allocation service:', serviceError);
      
      // Handle specific error types with appropriate status codes
      if (serviceError.message.includes('No outstanding invoices found')) {
        return res.status(404).json({ 
          error: 'No outstanding invoices found',
          message: serviceError.message 
        });
      } else if (serviceError.message.includes('No unallocated advance payments found')) {
        return res.status(404).json({ 
          error: 'No unallocated advance payments found',
          message: serviceError.message 
        });
      } else if (serviceError.message.includes('No allocations could be made')) {
        return res.status(422).json({ 
          error: 'No allocations could be made',
          message: serviceError.message 
        });
      }
      
      // For any other errors, return a 500 status
      throw serviceError;
    }
    
  } catch (error) {
    console.error('Error batch applying advance payments:', error);
    res.status(500).json({ 
      error: 'Failed to batch apply advance payments', 
      message: error.message
    });
  }
});

// Direct Turnover Report Endpoint (using same pattern as working dashboard)
router.get('/reports/turnover-direct', async (req: Request, res: Response) => {
  try {
    const { startDate, endDate, currency } = req.query;
    
    console.log('🎯 DIRECT TURNOVER with dates:', { startDate, endDate, currency });
    
    // Build query conditions like the working finance dashboard
    let whereConditions = ['1=1'];
    let queryParams: any[] = [];
    let paramIndex = 1;
    
    if (startDate && endDate) {
      whereConditions.push(`issue_date >= $${paramIndex} AND issue_date <= $${paramIndex + 1}`);
      queryParams.push(startDate, endDate);
      paramIndex += 2;
      console.log('✅ APPLYING DATE FILTER:', { startDate, endDate });
    }
    
    if (currency && currency !== 'all') {
      whereConditions.push(`currency = $${paramIndex}`);
      queryParams.push(currency);
      paramIndex++;
    }
    
    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
    
    // Use the exact same query pattern that works in finance dashboard
    const query = `
      SELECT 
        COUNT(*) as "totalCount",
        COALESCE(SUM(total_amount), 0) as "totalInvoiced",
        COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as "totalReceived",
        COALESCE(SUM(outstanding_amount), 0) as "totalOutstanding"
      FROM invoices ${whereClause}
    `;
    
    console.log('🔍 EXECUTING DIRECT QUERY:', query);
    console.log('📋 WITH PARAMS:', queryParams);
    
    const result = await pool.query(query, queryParams);
    const data = result.rows[0];
    
    console.log('📊 DIRECT RESULT:', data);
    
    // Format response to match expected frontend structure
    const response = {
      reportDate: new Date().toISOString(),
      totalInvoiced: parseFloat(data.totalInvoiced) || 0,
      totalReceived: parseFloat(data.totalReceived) || 0,
      totalOutstanding: parseFloat(data.totalOutstanding) || 0,
      totalInvoicedINR: (parseFloat(data.totalInvoiced) || 0) * 85.413325,
      totalReceivedINR: (parseFloat(data.totalReceived) || 0) * 85.413325,
      totalOutstandingINR: (parseFloat(data.totalOutstanding) || 0) * 85.413325,
      monthlyData: []
    };
    
    console.log('📤 SENDING DIRECT RESPONSE:', response);
    res.json(response);
    
  } catch (error) {
    console.error('❌ DIRECT TURNOVER ERROR:', error);
    res.status(500).json({ error: 'Failed to generate turnover report' });
  }
});

// Financial reports

/**
 * Turnover report with Indian Financial Year filtering
 */
router.get('/reports/turnover', ensureAuthenticated, async (req: Request, res: Response) => {
  console.log('🔥 TURNOVER ENDPOINT HIT!');
  console.log('🔥 Request query:', req.query);
  console.log('🔥 Request headers:', req.headers);
  
  try {
    const { startDate, endDate, currency } = req.query;
    
    console.log('🎯 TURNOVER REPORT with parameters:', { startDate, endDate, currency });
    
    // Get database connection
    const client = await pool.connect();
    
    try {
      // Build query with date filtering
      let whereConditions = [];
      let queryParams: any[] = [];
      let paramIndex = 1;
      
      if (startDate && endDate) {
        whereConditions.push(`issue_date >= $${paramIndex} AND issue_date <= $${paramIndex + 1}`);
        queryParams.push(startDate, endDate);
        paramIndex += 2;
        console.log('✅ APPLYING DATE FILTER:', { startDate, endDate });
      }
      
      if (currency && currency !== 'all') {
        whereConditions.push(`currency = $${paramIndex}`);
        queryParams.push(currency);
        paramIndex++;
        console.log('✅ APPLYING CURRENCY FILTER:', currency);
      }
      
      const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
      
      // Execute aggregate query
      const aggregateQuery = `
        SELECT 
          COUNT(*) as count,
          COALESCE(SUM(total_amount), 0) as total_invoiced,
          COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as total_received,
          COALESCE(SUM(outstanding_amount), 0) as total_outstanding
        FROM invoices ${whereClause}
      `;
      
      console.log('📋 EXECUTING QUERY:', aggregateQuery);
      console.log('📋 WITH PARAMS:', queryParams);
      
      const result = await client.query(aggregateQuery, queryParams);
      const data = result.rows[0];
      
      console.log('📊 DATABASE RESULT:', data);
      
      // Format response
      const response = {
        reportDate: new Date().toISOString(),
        totalInvoiced: parseFloat(data.total_invoiced) || 0,
        totalReceived: parseFloat(data.total_received) || 0,
        totalOutstanding: parseFloat(data.total_outstanding) || 0,
        totalInvoicedINR: (parseFloat(data.total_invoiced) || 0) * 85.413325,
        totalReceivedINR: (parseFloat(data.total_received) || 0) * 85.413325,
        totalOutstandingINR: (parseFloat(data.total_outstanding) || 0) * 85.413325,
        monthlyData: []
      };
      
      console.log('📤 SENDING RESPONSE:', response);
      res.json(response);
      
    } finally {
      client.release();
    }
    
  } catch (error) {
    console.error('❌ TURNOVER REPORT ERROR:', error);
    res.status(500).json({ error: 'Failed to generate turnover report' });
  }
});

/**
 * Outstanding invoices report
 */
router.get('/reports/outstanding', ensureAuthenticated, (req: Request, res: Response) => {
  try {
    const { startDate, endDate, currency } = req.query;
    
    // Sample static data for outstanding invoices
    const outstandingInvoices = [
      {
        id: 3,
        invoiceNumber: 'INV-2526-003',
        customerId: 3,
        customerName: 'ABC Industries Ltd.',
        issueDate: '2025-07-01',
        dueDate: '2025-07-31',
        amount: '150000.00',
        currency: 'USD',
        status: 'Unpaid',
        daysOverdue: 15,
        agingBucket: '0-30 days'
      },
      {
        id: 4,
        invoiceNumber: 'INV-2526-004',
        customerId: 1,
        customerName: 'XYZ Corp',
        issueDate: '2025-07-15',
        dueDate: '2025-08-15',
        amount: '125000.00',
        currency: 'USD',
        status: 'Unpaid',
        daysOverdue: 0,
        agingBucket: '0-30 days'
      },
      {
        id: 5,
        invoiceNumber: 'INV-2526-005',
        customerId: 4,
        customerName: 'Delta Systems',
        issueDate: '2025-08-01',
        dueDate: '2025-08-31',
        amount: '125000.00',
        currency: 'USD',
        status: 'Unpaid',
        daysOverdue: 0,
        agingBucket: '0-30 days'
      },
      {
        id: 6,
        invoiceNumber: 'INV-2526-006',
        customerId: 1,
        customerName: 'XYZ Corp',
        issueDate: '2025-04-01',
        dueDate: '2025-04-30',
        amount: '75000.00',
        currency: 'USD',
        status: 'Unpaid',
        daysOverdue: 107,
        agingBucket: '90+ days'
      },
      {
        id: 7,
        invoiceNumber: 'INV-2526-007',
        customerId: 3,
        customerName: 'ABC Industries Ltd.',
        issueDate: '2025-05-15',
        dueDate: '2025-06-15',
        amount: '50000.00',
        currency: 'USD',
        status: 'Unpaid',
        daysOverdue: 62,
        agingBucket: '61-90 days'
      }
    ];
    
    // Calculate totals
    let totalOutstanding = 0;
    let totalOutstandingINR = 0;
    let totalOverdue = 0;
    let totalOverdueINR = 0;
    let totalWithinDue = 0;
    let totalWithinDueINR = 0;
    
    outstandingInvoices.forEach(invoice => {
      const amount = Number(invoice.amount);
      totalOutstanding += amount;
      
      // Convert to INR for USD invoices
      if (invoice.currency === 'USD') {
        totalOutstandingINR += amount * 85.55; // USD to INR conversion rate
      } else {
        totalOutstandingINR += amount;
      }
      
      // Categorize as overdue or within due date
      if (invoice.daysOverdue > 0) {
        totalOverdue += amount;
        if (invoice.currency === 'USD') {
          totalOverdueINR += amount * 85.55;
        } else {
          totalOverdueINR += amount;
        }
      } else {
        totalWithinDue += amount;
        if (invoice.currency === 'USD') {
          totalWithinDueINR += amount * 85.55;
        } else {
          totalWithinDueINR += amount;
        }
      }
    });
    
    res.json({
      totalOutstanding,
      totalOutstandingINR,
      totalOverdue,
      totalOverdueINR,
      totalWithinDue,
      totalWithinDueINR,
      outstandingInvoices
    });
  } catch (error) {
    console.error('Error generating outstanding report:', error);
    res.status(500).json({ error: 'Failed to generate outstanding report' });
  }
});

/**
 * Inward remittances report
 */
router.get('/reports/remittances', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('Remittances API called with params:', req.query);
    
    // Get date range and currency filters from query params
    const { startDate, endDate, currency } = req.query;
    
    // Build the WHERE clause for date filtering
    let whereClause = '';
    const queryParams = [];
    let paramIndex = 1;
    
    if (startDate && endDate) {
      whereClause = `WHERE p.payment_date BETWEEN $${paramIndex} AND $${paramIndex + 1}`;
      queryParams.push(startDate, endDate);
      paramIndex += 2;
    }
    
    if (currency && currency !== 'all') {
      whereClause += whereClause ? ` AND p.currency = $${paramIndex}` : `WHERE p.currency = $${paramIndex}`;
      queryParams.push(currency);
    }
    
    // Get real payments data from database with filtering
    const query = `
      SELECT 
        p.id, 
        p.irm_no as reference_number, 
        p.amount, 
        p.currency, 
        p.payment_date, 
        p.payment_method, 
        c.bp_name as customer_name
      FROM 
        payments p
      LEFT JOIN 
        customers c ON p.customer_id = c.id
      ${whereClause}
      ORDER BY 
        p.payment_date DESC
    `;
    
    console.log('Executing query:', query);
    console.log('With parameters:', queryParams);
    
    const client = await pool.connect();
    
    try {
      const result = await client.query(query, queryParams);
      console.log("Payments data from DB:", result.rows.length, "rows found");
      console.log("Sample payment data:", result.rows[0]);
      
      console.log("Raw data from database:", result.rows);
      
      // Calculate total amount
      const totalRemittances = result.rows.reduce((sum, row) => sum + parseFloat(row.amount), 0);
      
      // Format data with real information
      const remittances = result.rows.map(row => ({
        remittanceNumber: row.reference_number || row.irm_no || `PAY-${row.id}`,
        customerName: row.customer_name || 'Unknown Customer',
        date: row.payment_date,
        invoiceNumber: row.irm_no || `PAY-${row.id}`,
        amount: parseFloat(row.amount),
        currency: row.currency || 'USD',
        brcStatus: row.payment_method === 'bank transfer' ? 'Issued' : 'Pending',
        brcDocumentUrl: null
      }));
      
      // Calculate BRC stats
      const totalBRCs = remittances.filter(r => r.brcStatus === 'Issued').length;
      const pendingBRCs = remittances.length - totalBRCs;
      
      const response = {
        reportDate: new Date().toISOString(),
        totalRemittances,
        totalRemittancesINR: totalRemittances * 85.55, // Approximate conversion
        totalBRCs,
        pendingBRCs,
        remittances
      };
      
      res.json(response);
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error generating remittances report:', error);
    res.status(500).json({ error: 'Failed to generate remittances report' });
  }
});

/**
 * Invoice aging analysis
 */
router.get('/reports/invoice-aging', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('Invoice aging API called with params:', req.query);
    
    const { startDate, endDate, currency } = req.query;
    
    // Build the WHERE clause for filtering
    let whereClause = '';
    const queryParams = [];
    let paramIndex = 1;
    
    if (startDate && endDate) {
      whereClause = `WHERE i.issue_date BETWEEN $${paramIndex} AND $${paramIndex + 1}`;
      queryParams.push(startDate, endDate);
      paramIndex += 2;
    }
    
    if (currency && currency !== 'all') {
      whereClause += whereClause ? ` AND i.currency = $${paramIndex}` : `WHERE i.currency = $${paramIndex}`;
      queryParams.push(currency);
    }
    
    // Get invoice aging data
    const query = `
      SELECT 
        i.id,
        i.invoice_number,
        i.customer_id,
        c.bp_name as customer_name,
        i.issue_date,
        i.due_date,
        i.total_amount,
        i.outstanding_amount,
        i.currency,
        i.status,
        CASE 
          WHEN i.outstanding_amount <= 0 THEN 0
          ELSE CURRENT_DATE - i.due_date
        END as days_overdue
      FROM invoices i
      LEFT JOIN customers c ON i.customer_id = c.id
      ${whereClause}
      ORDER BY i.issue_date DESC
    `;
    
    const client = await pool.connect();
    
    try {
      const result = await client.query(query, queryParams);
      console.log("Invoice aging data from DB:", result.rows.length, "invoices found");
      console.log("Sample invoice data:", result.rows[0]);
      
      // Calculate aging buckets
      const agingBuckets = {
        'Current': { count: 0, amount: 0, percentage: 0 },
        '1-30 days': { count: 0, amount: 0, percentage: 0 },
        '31-60 days': { count: 0, amount: 0, percentage: 0 },
        '61-90 days': { count: 0, amount: 0, percentage: 0 },
        '91+ days': { count: 0, amount: 0, percentage: 0 }
      };
      
      const customerSummaries = {};
      let totalOutstanding = 0;
      
      // Process each invoice
      const invoices = result.rows.map(row => {
        const daysOverdue = parseInt(row.days_overdue) || 0;
        const outstandingAmount = parseFloat(row.outstanding_amount) || 0;
        
        // Determine aging bucket
        let agingBucket = 'Current';
        if (daysOverdue > 90) {
          agingBucket = '91+ days';
        } else if (daysOverdue > 60) {
          agingBucket = '61-90 days';
        } else if (daysOverdue > 30) {
          agingBucket = '31-60 days';
        } else if (daysOverdue > 0) {
          agingBucket = '1-30 days';
        }
        
        // Update aging buckets
        if (outstandingAmount > 0) {
          agingBuckets[agingBucket].count++;
          agingBuckets[agingBucket].amount += outstandingAmount;
          totalOutstanding += outstandingAmount;
          
          // Update customer summary
          const customerId = row.customer_id;
          if (!customerSummaries[customerId]) {
            customerSummaries[customerId] = {
              customerId,
              customerName: row.customer_name,
              totalOutstanding: 0,
              agingBuckets: {
                'Current': 0,
                '1-30 days': 0,
                '31-60 days': 0,
                '61-90 days': 0,
                '91+ days': 0
              }
            };
          }
          
          customerSummaries[customerId].totalOutstanding += outstandingAmount;
          customerSummaries[customerId].agingBuckets[agingBucket] += outstandingAmount;
        }
        
        return {
          id: row.id,
          invoiceNumber: row.invoice_number,
          customerId: row.customer_id,
          customerName: row.customer_name,
          issueDate: row.issue_date,
          dueDate: row.due_date,
          amount: parseFloat(row.total_amount),
          outstandingAmount,
          currencyCode: row.currency,
          daysOverdue,
          agingBucket
        };
      });
      
      // Calculate percentages for aging buckets
      Object.keys(agingBuckets).forEach(bucket => {
        if (totalOutstanding > 0) {
          agingBuckets[bucket].percentage = (agingBuckets[bucket].amount / totalOutstanding * 100);
        }
      });
      
      const response = {
        totalOutstanding,
        currencyCode: currency || 'USD',
        agingBuckets,
        customerSummaries: Object.values(customerSummaries),
        invoices: invoices.filter(inv => inv.outstandingAmount > 0),
        paymentTrends: [
          {
            month: 'May 2025',
            avgDaysToPayment: 15,
            invoiceCount: 6
          }
        ]
      };
      
      console.log("Invoice aging response:", JSON.stringify(response, null, 2));
      
      res.json(response);
      
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error generating invoice aging report:', error);
    res.status(500).json({ error: 'Failed to generate invoice aging report' });
  }
});

/**
 * Create a write-off for an invoice
 */
router.post('/invoices/:id/write-off', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { amount, reason, glAccount } = req.body;
    
    if (!amount || !reason) {
      return res.status(400).json({ 
        error: 'Missing required fields. Please provide amount and reason.' 
      });
    }
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Create the write-off
    const writeOff = await writeOffService.writeOffInvoice(
      parseInt(id),
      parseFloat(amount),
      reason,
      req.user?.id,
      {
        glAccount
      }
    );
    
    // Return the created write-off
    res.status(201).json(writeOff);
  } catch (error: any) {
    console.error(`Error creating write-off for invoice ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to create invoice write-off',
      message: error.message
    });
  }
});

/**
 * Create a write-off for a payment
 */
router.post('/payments/:id/write-off', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { amount, reason, glAccount } = req.body;
    
    if (!amount || !reason) {
      return res.status(400).json({ 
        error: 'Missing required fields. Please provide amount and reason.' 
      });
    }
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Create the write-off
    const writeOff = await writeOffService.writeOffPayment(
      parseInt(id),
      parseFloat(amount),
      reason,
      req.user?.id,
      {
        glAccount
      }
    );
    
    // Return the created write-off
    res.status(201).json(writeOff);
  } catch (error: any) {
    console.error(`Error creating write-off for payment ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to create payment write-off',
      message: error.message
    });
  }
});

/**
 * Get write-offs for an invoice
 */
router.get('/invoices/:id/write-offs', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Get the write-offs
    const writeOffs = await writeOffService.getWriteOffsBySource('Invoice', parseInt(id));
    
    // Return the write-offs
    res.json(writeOffs);
  } catch (error: any) {
    console.error(`Error getting write-offs for invoice ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to get invoice write-offs',
      message: error.message
    });
  }
});

/**
 * Get write-offs for a payment
 */
router.get('/payments/:id/write-offs', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Get the write-offs
    const writeOffs = await writeOffService.getWriteOffsBySource('Payment', parseInt(id));
    
    // Return the write-offs
    res.json(writeOffs);
  } catch (error: any) {
    console.error(`Error getting write-offs for payment ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to get payment write-offs',
      message: error.message
    });
  }
});

/**
 * Get all write-offs with filtering options
 */
router.get('/write-offs', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { status, sourceType, createdBy, fromDate, toDate } = req.query;
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Prepare filters
    const filters: any = {};
    
    if (status && ['Pending', 'Approved', 'Rejected'].includes(status as string)) {
      filters.status = status;
    }
    
    if (sourceType && ['Invoice', 'Payment'].includes(sourceType as string)) {
      filters.sourceType = sourceType;
    }
    
    if (createdBy) {
      filters.createdBy = parseInt(createdBy as string);
    }
    
    if (fromDate) {
      filters.fromDate = new Date(fromDate as string);
    }
    
    if (toDate) {
      filters.toDate = new Date(toDate as string);
    }
    
    // Get the write-offs
    const writeOffs = await writeOffService.getAllWriteOffs(filters);
    
    // Return the write-offs
    res.json(writeOffs);
  } catch (error: any) {
    console.error('Error getting write-offs:', error);
    res.status(500).json({ 
      error: 'Failed to get write-offs',
      message: error.message
    });
  }
});

/**
 * Approve a pending write-off
 */
router.post('/write-offs/:id/approve', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Approve the write-off - this handles the response internally
    return await writeOffService.approveWriteOff(req, res);
  } catch (error: any) {
    console.error(`Error approving write-off ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to approve write-off',
      message: error.message
    });
  }
});

/**
 * Reject a pending write-off
 */
router.post('/write-offs/:id/reject', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    
    // Import the write-off service
    // Using writeOffService imported at the top of the file
    
    // Reject the write-off - this handles the response internally
    return await writeOffService.rejectWriteOff(req, res);
  } catch (error: any) {
    console.error(`Error rejecting write-off ${req.params.id}:`, error);
    res.status(500).json({ 
      error: 'Failed to reject write-off',
      message: error.message
    });
  }
});

/**
 * Create a new payment - simple endpoint that returns JSON
 */
router.post('/payments/create-new', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    console.log('Creating new payment (simple version):', req.body);
    
    const { 
      paymentDate, 
      sapPaymentNo,
      paymentType,
      amount, 
      currency = 'USD', 
      paymentMethod, 
      notes,
      isAdvancePayment = true,
      customerId,
      irmNo
    } = req.body;
    
    // Validate required fields
    if (!amount || !paymentDate || !customerId) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        details: 'Amount, payment date, and customer ID are required'
      });
    }
    
    // Basic parameter cleanup
    const cleanAmount = parseFloat(amount);
    const payDate = new Date(paymentDate);
    const customer = parseInt(customerId);
    
    if (isNaN(cleanAmount) || cleanAmount <= 0) {
      return res.status(400).json({ error: 'Invalid amount value' });
    }
    
    if (isNaN(customer)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }
    
    // Insert the payment record
    const insertQuery = `
      INSERT INTO payments (
        payment_date, 
        amount, 
        currency, 
        payment_method, 
        notes,
        is_advance_payment,
        customer_id,
        created_by,
        created_at,
        updated_at,
        unallocated_amount,
        allocated_amount,
        payment_type,
        irm_no,
        sap_payment_no
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING *
    `;
    
    const now = new Date();
    const createdBy = (req.user as any)?.id || 1;
    
    const result = await pool.query(insertQuery, [
      payDate,
      cleanAmount,
      currency,
      paymentMethod,
      notes,
      isAdvancePayment,
      customer,
      createdBy,
      now,
      now,
      cleanAmount, // Initially, unallocated amount equals the total amount
      0, // Initially, allocated amount is zero
      paymentType,
      irmNo,
      sapPaymentNo
    ]);
    
    // Get the newly created payment
    const newPayment = result.rows[0];
    
    // Update reference number to use payment ID
    const refNumber = `PAY-2526-${String(newPayment.id).padStart(3, '0')}`;
    await pool.query('UPDATE payments SET reference_number = $1 WHERE id = $2', [refNumber, newPayment.id]);
    
    // Return success with payment details
    return res.status(201).json({
      success: true,
      message: 'Payment created successfully',
      paymentId: newPayment.id,
      referenceNumber: refNumber
    });
    
  } catch (error) {
    console.error('Error creating payment:', error);
    return res.status(500).json({ 
      error: 'Failed to create payment',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * Get outstanding invoices for write-off selection
 */
router.get('/outstanding-invoices', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const query = `
      SELECT 
        i.id,
        i.invoice_number as "invoiceNumber",
        c.name as "customerName",
        i.total_amount as "totalAmount",
        COALESCE(i.outstanding_amount, i.total_amount) as "outstandingAmount",
        i.currency,
        i.status,
        i.due_date as "dueDate"
      FROM invoices i
      LEFT JOIN customers c ON i.customer_id = c.id
      WHERE 
        i.status IN ('Pending', 'Partially Paid') 
        AND COALESCE(i.outstanding_amount, i.total_amount) > 0
      ORDER BY i.due_date ASC, i.created_at DESC
    `;
    
    const result = await pool.query(query);
    
    res.json({
      success: true,
      invoices: result.rows
    });
  } catch (error) {
    console.error('Error fetching outstanding invoices:', error);
    res.status(500).json({ 
      error: 'Failed to fetch outstanding invoices',
      details: error.message 
    });
  }
});

/**
 * Create a new write-off
 */
router.post('/write-offs', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { invoiceId, amount, reason, description, currency, postingDate } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    if (!invoiceId || !amount || !reason) {
      return res.status(400).json({ error: 'Missing required fields: invoiceId, amount, reason' });
    }

    // Validate the invoice exists and has outstanding amount
    const invoiceQuery = `
      SELECT 
        i.id,
        i.invoice_number as "invoiceNumber",
        c.name as "customerName",
        i.total_amount as "totalAmount",
        COALESCE(i.outstanding_amount, i.total_amount) as "outstandingAmount",
        i.currency
      FROM invoices i
      LEFT JOIN customers c ON i.customer_id = c.id
      WHERE i.id = $1
    `;
    
    const invoiceResult = await pool.query(invoiceQuery, [invoiceId]);
    
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    const invoice = invoiceResult.rows[0];
    const writeOffAmount = parseFloat(amount);
    const outstandingAmount = parseFloat(invoice.outstandingAmount);
    
    if (writeOffAmount > outstandingAmount) {
      return res.status(400).json({ 
        error: `Write-off amount (${writeOffAmount}) cannot exceed outstanding amount (${outstandingAmount})` 
      });
    }

    // Create the write-off record
    const insertQuery = `
      INSERT INTO financial_writeoffs (
        invoice_id,
        amount,
        reason,
        notes,
        currency,
        status,
        created_by,
        date_created,
        created_at,
        updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
      RETURNING *
    `;
    
    const values = [
      invoiceId,
      writeOffAmount,
      reason,
      description || null,
      currency || invoice.currency,
      'Pending', // Default status is pending approval
      userId,
      postingDate || new Date().toISOString().split('T')[0] // Use posting date or default to today
    ];
    
    const result = await pool.query(insertQuery, values);
    const writeOff = result.rows[0];
    
    // Format the response
    const formattedWriteOff = {
      id: writeOff.id,
      invoiceId: writeOff.invoice_id,
      invoiceNumber: invoice.invoiceNumber,
      customerName: invoice.customerName,
      amount: writeOff.amount,
      originalInvoiceAmount: invoice.totalAmount,
      reason: writeOff.reason,
      notes: writeOff.notes,
      currency: writeOff.currency,
      status: writeOff.status,
      createdBy: {
        id: userId,
        name: req.user?.username || 'Unknown'
      },
      dateCreated: writeOff.created_at,
      approvedBy: null,
      approvalDate: null
    };
    
    res.status(201).json({
      success: true,
      message: 'Write-off created successfully and submitted for approval',
      writeOff: formattedWriteOff
    });
  } catch (error) {
    console.error('Error creating write-off:', error);
    res.status(500).json({ 
      error: 'Failed to create write-off',
      details: error.message 
    });
  }
});

/**
 * Create a new BRC
 */
router.post('/brc', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { invoiceId, brcNumber, brcDate, bankName, amountRealized, currency, notes } = req.body;
    
    // Insert directly into database
    const result = await pool.query(`
      INSERT INTO bank_realization_certificates 
      (related_invoice_id, brc_number, brc_date, bank_name, amount_realized, currency, notes, created_by, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
      RETURNING *
    `, [
      parseInt(invoiceId),
      brcNumber,
      brcDate,
      bankName,
      parseFloat(amountRealized),
      currency,
      notes,
      req.user?.id
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Error creating BRC:', error);
    res.status(500).json({ 
      error: 'Failed to create BRC',
      message: error.message
    });
  }
});

/**
 * Update an existing BRC
 */
router.put('/brc/:id', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { invoiceId, brcNumber, brcDate, bankName, amountRealized, currency, notes } = req.body;
    
    // Update directly in database
    const result = await pool.query(`
      UPDATE bank_realization_certificates 
      SET related_invoice_id = $1, brc_number = $2, brc_date = $3, bank_name = $4, 
          amount_realized = $5, currency = $6, notes = $7, updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `, [
      parseInt(invoiceId),
      brcNumber,
      brcDate,
      bankName,
      parseFloat(amountRealized),
      currency,
      notes,
      parseInt(id)
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'BRC not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error: any) {
    console.error('Error updating BRC:', error);
    res.status(500).json({ 
      error: 'Failed to update BRC',
      message: error.message
    });
  }
});

/**
 * Get BRC document
 */
router.get('/brc/:id/document', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const brcId = parseInt(req.params.id);
    
    if (isNaN(brcId)) {
      return res.status(400).json({ error: 'Invalid BRC ID' });
    }

    // Get BRC document path from database
    const query = `
      SELECT document_path, certificate_number 
      FROM finance_brc_certificates 
      WHERE id = $1
    `;
    
    const result = await pool.query(query, [brcId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'BRC not found' });
    }
    
    const brc = result.rows[0];
    
    if (!brc.document_path) {
      return res.status(404).json({ error: 'No document found for this BRC' });
    }

    // Import GCS client dynamically
    const { Storage } = require('@google-cloud/storage');
    
    // Initialize Google Cloud Storage
    let storage;
    try {
      if (process.env.GOOGLE_CLOUD_CREDENTIALS) {
        const credentials = JSON.parse(process.env.GOOGLE_CLOUD_CREDENTIALS);
        storage = new Storage({
          projectId: credentials.project_id,
          credentials: credentials
        });
      } else {
        storage = new Storage();
      }
    } catch (error) {
      console.error('Error initializing GCS client:', error);
      return res.status(500).json({ error: 'Storage service unavailable' });
    }

    const bucketName = 'thermopac_storage';
    const bucket = storage.bucket(bucketName);
    const file = bucket.file(brc.document_path);

    // Check if file exists
    const [exists] = await file.exists();
    if (!exists) {
      return res.status(404).json({ error: 'Document file not found in storage' });
    }

    // Get file metadata to set appropriate headers
    const [metadata] = await file.getMetadata();
    
    // Set appropriate headers
    res.setHeader('Content-Type', metadata.contentType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${brc.certificate_number}.pdf"`);
    
    // Stream the file directly to the response
    const stream = file.createReadStream();
    
    stream.on('error', (error) => {
      console.error('Error streaming file:', error);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Error reading document' });
      }
    });
    
    stream.pipe(res);
    
  } catch (error: any) {
    console.error('Error getting BRC document:', error);
    if (!res.headersSent) {
      res.status(500).json({ 
        error: 'Failed to retrieve BRC document',
        message: error.message
      });
    }
  }
});

/**
 * Get credit note details for an invoice (auto-generate number and get invoice details)
 */
router.get('/invoices/:id/credit-note-details', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const invoiceId = parseInt(req.params.id);
    
    if (isNaN(invoiceId)) {
      return res.status(400).json({ error: 'Invalid invoice ID' });
    }

    // Get invoice details including issue date for fiscal year calculation
    const invoiceQuery = `
      SELECT id, invoice_number, total_amount, status, issue_date, currency, due_date,
             credit_note_number, credit_note_date, credit_note_amount, credit_note_reason
      FROM invoices 
      WHERE id = $1
    `;
    
    const invoiceResult = await pool.query(invoiceQuery, [invoiceId]);
    
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const invoice = invoiceResult.rows[0];

    // Check if credit note already exists for this invoice
    if (invoice.credit_note_number) {
      return res.status(400).json({ error: 'Credit note already exists for this invoice' });
    }

    // Extract fiscal year from invoice issue date
    const issueDate = new Date(invoice.issue_date);
    const issueYear = issueDate.getFullYear();
    const issueMonth = issueDate.getMonth() + 1; // getMonth() is 0-based
    
    // Calculate fiscal year (April to March)
    let fiscalYear;
    if (issueMonth >= 4) {
      // April to December - current year to next year
      fiscalYear = `${issueYear.toString().slice(-2)}${(issueYear + 1).toString().slice(-2)}`;
    } else {
      // January to March - previous year to current year
      fiscalYear = `${(issueYear - 1).toString().slice(-2)}${issueYear.toString().slice(-2)}`;
    }

    // Get next credit note number for this fiscal year
    const creditNoteCountQuery = `
      SELECT COUNT(*) as count
      FROM invoices 
      WHERE credit_note_number LIKE $1
    `;
    
    const creditNoteCountResult = await pool.query(creditNoteCountQuery, [`CRN-${fiscalYear}-%`]);
    const nextNumber = parseInt(creditNoteCountResult.rows[0].count) + 1;
    const creditNoteNumber = `CRN-${fiscalYear}-${nextNumber.toString().padStart(3, '0')}`;

    res.json({
      success: true,
      invoice: {
        id: invoice.id,
        invoiceNumber: invoice.invoice_number,
        totalAmount: invoice.total_amount,
        currency: invoice.currency,
        status: invoice.status,
        issueDate: invoice.issue_date,
        dueDate: invoice.due_date
      },
      creditNoteNumber,
      fiscalYear,
      minDate: invoice.issue_date // Credit note date must be >= invoice date
    });

  } catch (error) {
    console.error('Error getting credit note details:', error);
    res.status(500).json({ error: 'Failed to get credit note details' });
  }
});

/**
 * Issue a credit note for an invoice
 */
router.post('/invoices/:id/credit-note', ensureAuthenticated, async (req: Request, res: Response) => {
  try {
    const invoiceId = parseInt(req.params.id);
    const { creditNoteNumber, creditNoteDate, creditNoteAmount, creditNoteReason } = req.body;
    const userId = req.user?.id;

    // Validate input
    if (!creditNoteNumber || !creditNoteDate || !creditNoteAmount || !creditNoteReason) {
      return res.status(400).json({ error: 'Credit note number, date, amount, and reason are required' });
    }

    // Validate that the invoice exists and get full details
    const invoiceQuery = `
      SELECT id, invoice_number, total_amount, status, issue_date
      FROM invoices 
      WHERE id = $1
    `;
    
    const invoiceResult = await pool.query(invoiceQuery, [invoiceId]);
    
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const invoice = invoiceResult.rows[0];

    // Check if credit note already exists for this invoice
    if (invoice.credit_note_number) {
      return res.status(400).json({ error: 'Credit note already exists for this invoice' });
    }

    // Validate credit note amount doesn't exceed invoice total
    const creditAmount = parseFloat(creditNoteAmount);
    const invoiceAmount = parseFloat(invoice.total_amount);
    
    if (creditAmount > invoiceAmount) {
      return res.status(400).json({ 
        error: `Credit note amount (${creditAmount}) cannot exceed invoice amount (${invoiceAmount})` 
      });
    }

    // Validate credit note date is not before invoice date
    const creditDate = new Date(creditNoteDate);
    const invoiceDate = new Date(invoice.issue_date);
    
    if (creditDate < invoiceDate) {
      return res.status(400).json({ 
        error: 'Credit note date cannot be before invoice date' 
      });
    }

    // Check if credit note number already exists
    const duplicateCheckQuery = `
      SELECT id FROM invoices WHERE credit_note_number = $1 AND id != $2
    `;
    const duplicateResult = await pool.query(duplicateCheckQuery, [creditNoteNumber, invoiceId]);
    
    if (duplicateResult.rows.length > 0) {
      return res.status(400).json({ 
        error: 'Credit note number already exists. Please refresh and try again.' 
      });
    }

    // Update the invoice with credit note details and change status to 'Credited'
    const updateQuery = `
      UPDATE invoices 
      SET 
        credit_note_number = $1,
        credit_note_date = $2,
        credit_note_amount = $3,
        credit_note_reason = $4,
        credited_by = $5,
        credited_at = NOW(),
        status = 'Credited',
        updated_at = NOW()
      WHERE id = $6
      RETURNING *
    `;

    const updateResult = await pool.query(updateQuery, [
      creditNoteNumber,
      creditNoteDate,
      creditNoteAmount,
      creditNoteReason,
      userId,
      invoiceId
    ]);

    const updatedInvoice = updateResult.rows[0];

    console.log(`Credit note ${creditNoteNumber} issued for invoice ${invoice.invoice_number} by user ${userId}`);

    res.json({
      success: true,
      message: 'Credit note issued successfully',
      invoice: updatedInvoice
    });

  } catch (error) {
    console.error('Error issuing credit note:', error);
    res.status(500).json({ error: 'Failed to issue credit note' });
  }
});

export default router;