"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceHealth = void 0;
class ServiceHealth {
    constructor() {
        this._state = 'STARTING';
        this._lastError = null;
        this._processedJobs = 0;
        this._failedJobs = 0;
    }
    get state() { return this._state; }
    get lastError() { return this._lastError; }
    get processedJobs() { return this._processedJobs; }
    get failedJobs() { return this._failedJobs; }
    transition(newState, error) {
        this._state = newState;
        if (error)
            this._lastError = error;
        else if (newState === 'IDLE')
            this._lastError = null;
    }
    recordSuccess() { this._processedJobs++; }
    recordFailure(reason) {
        this._failedJobs++;
        this._lastError = reason;
    }
    summary() {
        return {
            state: this._state,
            lastError: this._lastError,
            processedJobs: this._processedJobs,
            failedJobs: this._failedJobs,
        };
    }
}
exports.ServiceHealth = ServiceHealth;
