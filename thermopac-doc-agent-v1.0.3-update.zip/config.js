"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadConfig = loadConfig;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const DEFAULT_CONFIG_PATH = path.join(process.cwd(), 'config.json');
function loadConfig(configPath) {
    const filePath = configPath || DEFAULT_CONFIG_PATH;
    if (!fs.existsSync(filePath)) {
        throw new Error(`Config file not found: ${filePath}. Copy config.json.example to config.json and fill in values.`);
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const cfg = JSON.parse(raw);
    if (!cfg.agentCode)
        throw new Error('Config missing: agentCode');
    if (!cfg.erpBaseUrl)
        throw new Error('Config missing: erpBaseUrl');
    if (!cfg.apiKey)
        throw new Error('Config missing: apiKey');
    if (!cfg.allowedRootPath)
        throw new Error('Config missing: allowedRootPath');
    if (cfg.apiKey === 'CHANGE_ME_MIN_16_CHARS') {
        throw new Error('Config error: apiKey must be changed from the example value');
    }
    const rawEnv = cfg.environment;
    const environment = rawEnv === 'dev' ? 'dev' : 'prod';
    return {
        environment,
        agentCode: cfg.agentCode,
        erpBaseUrl: cfg.erpBaseUrl.replace(/\/$/, ''),
        apiKey: cfg.apiKey,
        allowedRootPath: cfg.allowedRootPath,
        pollIntervalSeconds: cfg.pollIntervalSeconds ?? 20,
        maxConcurrentJobs: cfg.maxConcurrentJobs ?? 1,
        logDir: cfg.logDir || 'C:\\ThermopacDocAgent\\logs',
        tempDir: cfg.tempDir || 'C:\\ThermopacDocAgent\\temp',
    };
}
