"use strict";
/**
 * api-client.ts
 *
 * All outbound HTTPS calls to the ERP cloud API.
 * Uses Node 20 native global fetch — no node-fetch dependency.
 * No inbound connections — agent is always the initiator.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendHeartbeat = sendHeartbeat;
exports.claimJob = claimJob;
exports.submitResult = submitResult;
async function post(config, endpoint, body) {
    const url = `${config.erpBaseUrl}/api/local-agent${endpoint}`;
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-agent-code': config.agentCode,
            'x-api-key': config.apiKey,
        },
        body: JSON.stringify(body),
    });
    if (!response.ok) {
        const text = await response.text().catch(() => '');
        throw new Error(`ERP API error ${response.status} ${endpoint}: ${text}`);
    }
    return response.json();
}
async function get(config, endpoint) {
    const url = `${config.erpBaseUrl}/api/local-agent${endpoint}`;
    const response = await fetch(url, {
        headers: {
            'x-agent-code': config.agentCode,
            'x-api-key': config.apiKey,
        },
    });
    if (!response.ok) {
        const text = await response.text().catch(() => '');
        throw new Error(`ERP API error ${response.status} ${endpoint}: ${text}`);
    }
    return response.json();
}
async function sendHeartbeat(config, payload) {
    const result = await post(config, '/heartbeat', payload);
    return { pendingJobs: result.pendingJobs ?? 0 };
}
async function claimJob(config) {
    const result = await post(config, '/jobs/claim', {});
    return result.job ?? null;
}
async function submitResult(config, payload) {
    await post(config, '/jobs/result', payload);
}
