"use strict";
/**
 * path-guard.ts
 *
 * Security rules:
 * - Reject traversal sequences (../ ..\)
 * - Reject absolute paths (C:\ D:\ \\Server\ etc.)
 * - Reject unresolved tokens ({...})
 * - Reject dangerous file extensions
 * - Resolve final path strictly under allowedRootPath
 * - Verify resolved path still starts with allowedRootPath
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRelativePath = validateRelativePath;
exports.validateExtension = validateExtension;
const path = __importStar(require("path"));
const DANGEROUS_EXTENSIONS = new Set([
    '.exe', '.bat', '.cmd', '.ps1', '.vbs', '.msi', '.dll',
    '.com', '.scr', '.pif', '.reg', '.js', '.jar', '.sh',
]);
const ALLOWED_EXTENSIONS = new Set([
    '.pdf', '.docx', '.xlsx', '.csv', '.txt',
    '.png', '.jpg', '.jpeg', '.zip', '.dwg', '.dxf',
]);
function validateRelativePath(relativePath, allowedRootPath) {
    if (!relativePath || relativePath.trim().length === 0) {
        return { ok: false, fullPath: '', error: 'Relative path is empty' };
    }
    // Block traversal sequences
    if (/\.\.[\\/]/.test(relativePath) || /[\\/]\.\./.test(relativePath) || relativePath === '..') {
        return { ok: false, fullPath: '', error: 'Path traversal sequence detected' };
    }
    // Block absolute paths
    if (/^[a-zA-Z]:[\\/]/.test(relativePath)) {
        return { ok: false, fullPath: '', error: 'Absolute drive paths are not allowed' };
    }
    if (/^\\\\/.test(relativePath)) {
        return { ok: false, fullPath: '', error: 'UNC paths in relative position are not allowed' };
    }
    if (/^\//.test(relativePath)) {
        return { ok: false, fullPath: '', error: 'Unix absolute paths are not allowed' };
    }
    // Block unresolved tokens
    if (/\{[^}]+\}/.test(relativePath)) {
        return { ok: false, fullPath: '', error: 'Unresolved token(s) detected in path' };
    }
    // Resolve full path
    const normalized = relativePath.replace(/\//g, path.sep).replace(/\\/g, path.sep);
    const fullPath = path.resolve(allowedRootPath, normalized);
    const resolvedRoot = path.resolve(allowedRootPath);
    // Ensure path stays within allowed root
    if (!fullPath.startsWith(resolvedRoot + path.sep) && fullPath !== resolvedRoot) {
        return { ok: false, fullPath: '', error: `Resolved path escapes allowedRootPath. Got: ${fullPath}` };
    }
    return { ok: true, fullPath };
}
function validateExtension(fileName) {
    const ext = path.extname(fileName).toLowerCase();
    if (DANGEROUS_EXTENSIONS.has(ext)) {
        return { ok: false, error: `Dangerous file extension rejected: ${ext}` };
    }
    if (!ALLOWED_EXTENSIONS.has(ext)) {
        return { ok: false, error: `File extension not in allowed list: ${ext}` };
    }
    return { ok: true };
}
