"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setLogDir = setLogDir;
exports.log = log;
exports.info = info;
exports.warn = warn;
exports.error = error;
exports.debug = debug;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const MAX_LOG_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB
const MAX_LOG_FILES = 5;
let logDir = 'C:\\ThermopacDocAgent\\logs';
function setLogDir(dir) {
    logDir = dir;
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }
}
function currentLogPath() {
    return path.join(logDir, 'agent.log');
}
function rotateLogs() {
    const base = currentLogPath();
    if (!fs.existsSync(base))
        return;
    const stat = fs.statSync(base);
    if (stat.size < MAX_LOG_SIZE_BYTES)
        return;
    for (let i = MAX_LOG_FILES - 1; i >= 1; i--) {
        const from = `${base}.${i}`;
        const to = `${base}.${i + 1}`;
        if (fs.existsSync(from))
            fs.renameSync(from, to);
    }
    fs.renameSync(base, `${base}.1`);
}
function log(level, message, meta) {
    const ts = new Date().toISOString();
    const metaStr = meta !== undefined ? ` | ${JSON.stringify(meta)}` : '';
    const line = `[${ts}] [${level}] ${message}${metaStr}`;
    console.log(line);
    try {
        rotateLogs();
        fs.appendFileSync(currentLogPath(), line + '\n', 'utf8');
    }
    catch {
        // log write failure is non-fatal
    }
}
function info(message, meta) { log('INFO', message, meta); }
function warn(message, meta) { log('WARN', message, meta); }
function error(message, meta) { log('ERROR', message, meta); }
function debug(message, meta) { log('DEBUG', message, meta); }
