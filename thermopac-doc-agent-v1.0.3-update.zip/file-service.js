"use strict";
/**
 * file-service.ts
 *
 * Safe file operations:
 * 1. Download file to .tmp using Node 20 native fetch
 * 2. Calculate SHA256
 * 3. Rename .tmp → final only after successful verify
 * 4. Auto-create parent folders
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadAndSave = downloadAndSave;
exports.createFolder = createFolder;
exports.fileExists = fileExists;
exports.folderExists = folderExists;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const hash_service_1 = require("./hash-service");
const logger_1 = require("./logger");
async function downloadAndSave(fileUrl, destFullPath, tempDir) {
    const tempPath = path.join(tempDir, `tmp_${Date.now()}_${path.basename(destFullPath)}`);
    if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
    }
    const parentDir = path.dirname(destFullPath);
    if (!fs.existsSync(parentDir)) {
        (0, logger_1.info)(`Auto-creating folder: ${parentDir}`);
        fs.mkdirSync(parentDir, { recursive: true });
    }
    try {
        (0, logger_1.info)(`Downloading: ${fileUrl} → ${tempPath}`);
        const response = await fetch(fileUrl);
        if (!response.ok) {
            return { ok: false, localPath: '', sha256: '', error: `HTTP ${response.status} fetching file` };
        }
        const buffer = Buffer.from(await response.arrayBuffer());
        fs.writeFileSync(tempPath, buffer);
        const sha256 = (0, hash_service_1.sha256OfFile)(tempPath);
        (0, logger_1.info)(`SHA256: ${sha256}`);
        fs.renameSync(tempPath, destFullPath);
        (0, logger_1.info)(`Saved: ${destFullPath}`);
        return { ok: true, localPath: destFullPath, sha256 };
    }
    catch (err_) {
        (0, logger_1.error)(`downloadAndSave failed`, err_);
        if (fs.existsSync(tempPath)) {
            try {
                fs.unlinkSync(tempPath);
            }
            catch { /* ignore */ }
        }
        return { ok: false, localPath: '', sha256: '', error: String(err_) };
    }
}
function createFolder(fullPath) {
    try {
        if (!fs.existsSync(fullPath)) {
            fs.mkdirSync(fullPath, { recursive: true });
            (0, logger_1.info)(`Folder created: ${fullPath}`);
        }
        else {
            (0, logger_1.info)(`Folder already exists: ${fullPath}`);
        }
        return { ok: true };
    }
    catch (err_) {
        return { ok: false, error: String(err_) };
    }
}
function fileExists(fullPath) {
    return fs.existsSync(fullPath) && fs.statSync(fullPath).isFile();
}
function folderExists(fullPath) {
    return fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory();
}
