"use strict";
/**
 * THERMOPAC Local Windows Document Agent
 * Version: 1.0.2
 *
 * Cloud ERP → document_agent_jobs → Local Windows Document Agent → \\Server\d\THERMOPAC
 *
 * Run:           node dist/index.js
 * Install svc:   node dist/index.js --install-service
 * Uninstall svc: node dist/index.js --uninstall-service
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const config_1 = require("./config");
const logger_1 = require("./logger");
const api_client_1 = require("./api-client");
const job_runner_1 = require("./job-runner");
const service_health_1 = require("./service-health");
const AGENT_VERSION = '1.0.3';
const MACHINE_NAME = os.hostname();
async function main() {
    const args = process.argv.slice(2);
    const config = (0, config_1.loadConfig)();
    (0, logger_1.setLogDir)(config.logDir);
    (0, logger_1.info)(`THERMOPAC Local Document Agent v${AGENT_VERSION} starting on ${MACHINE_NAME}`);
    (0, logger_1.info)(`Allowed root: ${config.allowedRootPath}`);
    (0, logger_1.info)(`ERP base URL: ${config.erpBaseUrl}`);
    if (args.includes('--install-service')) {
        await installWindowsService();
        return;
    }
    if (args.includes('--uninstall-service')) {
        await uninstallWindowsService();
        return;
    }
    const health = new service_health_1.ServiceHealth();
    let running = true;
    process.on('SIGTERM', () => { (0, logger_1.info)('SIGTERM received — stopping'); health.transition('STOPPING'); running = false; });
    process.on('SIGINT', () => { (0, logger_1.info)('SIGINT received — stopping'); health.transition('STOPPING'); running = false; });
    health.transition('CONNECTING');
    while (running) {
        try {
            const hb = await (0, api_client_1.sendHeartbeat)(config, {
                environment: config.environment,
                agentState: health.state,
                agentVersion: AGENT_VERSION,
                machineName: MACHINE_NAME,
                lastError: health.lastError ?? undefined,
            });
            if (health.state === 'CONNECTING' || health.state === 'RETRY_WAIT') {
                health.transition('IDLE');
                (0, logger_1.info)('Connected to ERP');
            }
            if (hb.pendingJobs > 0 && health.state !== 'PROCESSING') {
                health.transition('PROCESSING');
                const job = await (0, api_client_1.claimJob)(config);
                if (job) {
                    (0, logger_1.info)(`Claimed job #${job.id} (${job.jobType})`);
                    await (0, job_runner_1.runJob)(config, job, health);
                    health.transition('IDLE');
                }
                else {
                    health.transition('IDLE');
                }
            }
            else if (health.state !== 'PROCESSING') {
                health.transition('IDLE');
            }
        }
        catch (err_) {
            const msg = err_ instanceof Error ? err_.message : String(err_);
            (0, logger_1.error)(`Poll cycle error: ${msg}`);
            health.transition('RETRY_WAIT', msg);
            await (0, api_client_1.sendHeartbeat)(config, {
                environment: config.environment,
                agentState: 'RETRY_WAIT',
                agentVersion: AGENT_VERSION,
                machineName: MACHINE_NAME,
                lastError: msg,
            }).catch(() => { });
        }
        await sleep(config.pollIntervalSeconds * 1000);
    }
    (0, logger_1.info)('Agent stopped gracefully');
    process.exit(0);
}
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function installWindowsService() {
    (0, logger_1.info)('Installing Windows service: ThermopacLocalDocumentAgent');
    try {
        const nodeWindows = require('node-windows');
        const Service = nodeWindows.Service;
        const svc = new Service({
            name: 'ThermopacLocalDocumentAgent',
            description: 'THERMOPAC Local Document Agent — saves ERP files to local file server',
            script: path.join(process.cwd(), 'dist', 'index.js'),
            nodeOptions: [],
        });
        svc.on('install', () => {
            (0, logger_1.info)('Service installed. Starting...');
            svc.start();
        });
        svc.on('start', () => (0, logger_1.info)('Service started'));
        svc.on('error', (err) => (0, logger_1.error)('Service error', err));
        svc.install();
    }
    catch (err_) {
        (0, logger_1.error)('Failed to install service', err_);
        process.exit(1);
    }
}
async function uninstallWindowsService() {
    (0, logger_1.info)('Uninstalling Windows service: ThermopacLocalDocumentAgent');
    try {
        const nodeWindows = require('node-windows');
        const Service = nodeWindows.Service;
        const svc = new Service({
            name: 'ThermopacLocalDocumentAgent',
            script: path.join(process.cwd(), 'dist', 'index.js'),
        });
        svc.on('uninstall', () => (0, logger_1.info)('Service uninstalled'));
        svc.uninstall();
    }
    catch (err_) {
        (0, logger_1.error)('Failed to uninstall service', err_);
        process.exit(1);
    }
}
main().catch(err_ => {
    console.error('Fatal error:', err_);
    process.exit(1);
});
