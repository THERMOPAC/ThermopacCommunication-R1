"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sha256OfBuffer = sha256OfBuffer;
exports.sha256OfFile = sha256OfFile;
exports.verifyHash = verifyHash;
const crypto = __importStar(require("crypto"));
const fs = __importStar(require("fs"));
function sha256OfBuffer(buffer) {
    return crypto.createHash('sha256').update(buffer).digest('hex');
}
function sha256OfFile(filePath) {
    const buffer = fs.readFileSync(filePath);
    return sha256OfBuffer(buffer);
}
function verifyHash(filePath, expectedHash) {
    const actual = sha256OfFile(filePath);
    return actual.toLowerCase() === expectedHash.toLowerCase();
}
